import { useState, useEffect, useRef } from "react";

const NAV_LINKS = ["Features", "Modes", "Pricing", "About"];

const FEATURES = [
  { icon: "🎸", title: "Guitar Hero Highway", desc: "5-lane scrolling note highway with real-time scoring, combos, and streak multipliers.", color: "#22c55e" },
  { icon: "🥁", title: "Drum Machine + Sequencer", desc: "8-pad drum kit with a full step sequencer. Record patterns and loop them live.", color: "#ec4899" },
  { icon: "🎹", title: "Piano & Chord Library", desc: "Full playable keyboard with black keys, note history, and instant chord voicing.", color: "#3b82f6" },
  { icon: "🎤", title: "Karaoke + Mic Scoring", desc: "Sing along with scrolling lyrics. Your microphone is analyzed in real-time for score.", color: "#a855f7" },
  { icon: "🎚️", title: "Music Creation Studio", desc: "Build chord progressions, write lyrics, set BPM and genre, save your tracks.", color: "#f97316" },
  { icon: "✨", title: "AI Lyric Generator", desc: "Powered by Claude AI — generates original lyrics tuned to your song title, genre, and chords.", color: "#facc15" },
];

const MODES = [
  { id: "guitar", label: "Guitar Hero", icon: "🎸", color: "#22c55e", preview: ["●", "●", "○", "●", "○"] },
  { id: "drums", label: "Drum Kit", icon: "🥁", color: "#ec4899", preview: ["HH", "SN", "KK", "T1", "CR"] },
  { id: "piano", label: "Piano", icon: "🎹", color: "#3b82f6", preview: ["C", "D", "E", "F", "G"] },
  { id: "karaoke", label: "Karaoke", icon: "🎤", color: "#a855f7", preview: ["♪", "♫", "♪", "♬", "♪"] },
  { id: "studio", label: "Studio", icon: "🎚️", color: "#f97316", preview: ["C", "G", "Am", "F", "—"] },
];

const PLANS = [
  { name: "Starter", emoji: "🎵", price: "Free", color: "#22c55e", perks: ["Guitar Hero & Drums", "3 built-in songs", "Piano keyboard", "5 chord presets"] },
  { name: "Band Member", emoji: "🎸", price: "$4.99", period: "/mo", color: "#06b6d4", badge: "POPULAR", perks: ["All 5 instruments", "Karaoke + mic scoring", "AI lyrics (15/mo)", "Save 20 tracks"] },
  { name: "Rockstar Pro", emoji: "👑", price: "$9.99", period: "/mo", color: "#f97316", badge: "BEST", perks: ["Unlimited AI lyrics", "Unlimited saves", "Custom song builder", "VIP Discord + priority support"] },
];

const TESTIMONIALS = [
  { name: "DJ Nova", role: "Independent Artist", quote: "RockForge is the most fun I've had making music since Guitar Hero was in its prime. The AI lyrics blew my mind.", stars: 5 },
  { name: "Maya R.", role: "Music Teacher", quote: "I use it in my classes to teach kids chord progressions. The piano mode is perfect and the karaoke scoring keeps them engaged.", stars: 5 },
  { name: "Trent K.", role: "Bedroom Producer", quote: "The drum sequencer alone is worth it. Combined with the studio mode, I've already created 12 original tracks.", stars: 5 },
];

function StarRating({ count }) {
  return <span style={{ color: "#facc15", letterSpacing: 2 }}>{"★".repeat(count)}</span>;
}

function AnimatedCounter({ target, suffix = "" }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        let start = 0;
        const step = target / 60;
        const timer = setInterval(() => {
          start += step;
          if (start >= target) { setCount(target); clearInterval(timer); }
          else setCount(Math.floor(start));
        }, 16);
      }
    }, { threshold: 0.5 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [target]);
  return <span ref={ref}>{count.toLocaleString()}{suffix}</span>;
}

export default function RockForgeLanding() {
  const [activeMode, setActiveMode] = useState("guitar");
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const [notePos, setNotePos] = useState([]);

  useEffect(() => {
    const onScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Floating music notes animation
  useEffect(() => {
    const notes = ["♪", "♫", "♬", "🎵", "🎶"];
    const items = Array.from({ length: 12 }, (_, i) => ({
      id: i, note: notes[i % notes.length],
      x: Math.random() * 100, delay: Math.random() * 8,
      dur: 6 + Math.random() * 6, size: 12 + Math.random() * 14,
    }));
    setNotePos(items);
  }, []);

  const currentMode = MODES.find(m => m.id === activeMode);

  return (
    <div style={{ minHeight: "100vh", background: "#030308", color: "#fff", fontFamily: "'Trebuchet MS', sans-serif", overflowX: "hidden" }}>
      <style>{`
        @keyframes floatUp { 0%{transform:translateY(100vh) rotate(0deg);opacity:0} 10%{opacity:0.4} 90%{opacity:0.2} 100%{transform:translateY(-10vh) rotate(360deg);opacity:0} }
        @keyframes heroGlow { 0%,100%{text-shadow:0 0 40px #f9731688,0 0 80px #f9731644} 50%{text-shadow:0 0 80px #facc1588,0 0 120px #facc1544} }
        @keyframes fadeUp { from{opacity:0;transform:translateY(30px)} to{opacity:1;transform:translateY(0)} }
        @keyframes pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.04)} }
        @keyframes slideIn { from{opacity:0;transform:translateX(-20px)} to{opacity:1;transform:translateX(0)} }
        @keyframes shimmerBg { 0%{background-position:200% center} 100%{background-position:-200% center} }
        @keyframes borderSpin { 0%{transform:rotate(0deg)} 100%{transform:rotate(360deg)} }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: #1e1e3a; border-radius: 2px; }
        section { scroll-margin-top: 70px; }
      `}</style>

      {/* Floating notes */}
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0, overflow: "hidden" }}>
        {notePos.map(n => (
          <div key={n.id} style={{
            position: "absolute", left: `${n.x}%`, bottom: -40,
            fontSize: n.size, opacity: 0,
            animation: `floatUp ${n.dur}s ${n.delay}s linear infinite`,
            color: ["#f97316","#facc15","#22c55e","#3b82f6","#a855f7"][n.id % 5],
          }}>{n.note}</div>
        ))}
      </div>

      {/* ── NAV ── */}
      <nav style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
        background: scrollY > 40 ? "rgba(3,3,8,0.95)" : "transparent",
        backdropFilter: scrollY > 40 ? "blur(12px)" : "none",
        borderBottom: scrollY > 40 ? "1px solid #0f0f2a" : "none",
        transition: "all 0.3s", padding: "14px 24px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #06b6d4)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🧠</div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 900, letterSpacing: 1 }}>
              <span style={{ background: "linear-gradient(135deg, #a78bfa, #06b6d4)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>HumanLayer</span>
              <span style={{ background: "linear-gradient(135deg, #06b6d4, #22d3ee)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>AI</span>
              <span style={{ fontSize: 8, color: "#3d3d6a", marginLeft: 3 }}>LLC</span>
            </div>
            <div style={{ fontSize: 8, color: "#3d3d6a", letterSpacing: 3 }}>ROCKFORGE™</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
          {NAV_LINKS.map(l => (
            <a key={l} href={`#${l.toLowerCase()}`} style={{ color: "#555", fontSize: 12, textDecoration: "none", letterSpacing: 1, fontFamily: "monospace", transition: "color 0.2s" }}
              onMouseEnter={e => e.target.style.color = "#fff"}
              onMouseLeave={e => e.target.style.color = "#555"}>{l}</a>
          ))}
          <a href="#pricing" style={{
            padding: "8px 18px", borderRadius: 20,
            background: "linear-gradient(135deg, #f97316, #facc15)",
            color: "#000", fontSize: 11, fontWeight: 900, textDecoration: "none",
            letterSpacing: 1, fontFamily: "monospace",
          }}>GET STARTED</a>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: "100px 24px 60px", position: "relative", zIndex: 1 }}>
        {/* Background mesh */}
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse 80% 60% at 50% 40%, #1a0a2e22 0%, transparent 70%)", pointerEvents: "none" }} />
        <div style={{ position: "absolute", top: "20%", left: "10%", width: 300, height: 300, borderRadius: "50%", background: "radial-gradient(circle, #7c3aed0a, transparent)", pointerEvents: "none" }} />
        <div style={{ position: "absolute", top: "30%", right: "10%", width: 200, height: 200, borderRadius: "50%", background: "radial-gradient(circle, #f973160a, transparent)", pointerEvents: "none" }} />

        <div style={{ animation: "fadeUp 0.8s ease both" }}>
          <div style={{ display: "inline-block", padding: "5px 16px", borderRadius: 20, background: "#f9731611", border: "1px solid #f9731644", color: "#f97316", fontSize: 10, letterSpacing: 3, fontFamily: "monospace", marginBottom: 24 }}>
            🎸 BY HUMANLAYERAI LLC · MUSIC GAME STUDIO
          </div>

          <h1 style={{ fontSize: "clamp(42px, 8vw, 80px)", fontWeight: 900, lineHeight: 1.05, marginBottom: 24, letterSpacing: -1 }}>
            <span style={{ display: "block", animation: "heroGlow 3s ease-in-out infinite", background: "linear-gradient(135deg, #fff 0%, #e2e8f0 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Play. Create.</span>
            <span style={{ display: "block", background: "linear-gradient(135deg, #f97316, #facc15, #f97316)", backgroundSize: "200% auto", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", animation: "shimmerBg 3s linear infinite" }}>Perform.</span>
          </h1>

          <p style={{ fontSize: 16, color: "#6b7280", maxWidth: 520, margin: "0 auto 36px", lineHeight: 1.8 }}>
            The ultimate browser-based music game studio. Guitar Hero, drums, piano, karaoke, and an AI-powered creation suite — all in one.
          </p>

          <div style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap" }}>
            <a href="#modes" style={{
              padding: "16px 36px", borderRadius: 12,
              background: "linear-gradient(135deg, #f97316, #facc15)",
              color: "#000", fontSize: 15, fontWeight: 900, textDecoration: "none",
              letterSpacing: 2, fontFamily: "monospace",
              boxShadow: "0 8px 32px #f9731644",
              transition: "transform 0.2s, box-shadow 0.2s",
            }}
              onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 12px 40px #f9731666"; }}
              onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "0 8px 32px #f9731644"; }}>
              🎸 Play Free Now
            </a>
            <a href="#pricing" style={{
              padding: "16px 36px", borderRadius: 12,
              border: "1px solid #333", background: "transparent",
              color: "#888", fontSize: 15, fontWeight: 700, textDecoration: "none",
              letterSpacing: 1, fontFamily: "monospace", transition: "all 0.2s",
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = "#555"; e.currentTarget.style.color = "#fff"; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = "#333"; e.currentTarget.style.color = "#888"; }}>
              💎 View Plans
            </a>
          </div>
        </div>

        {/* Stats row */}
        <div style={{ display: "flex", gap: 40, marginTop: 64, flexWrap: "wrap", justifyContent: "center", animation: "fadeUp 0.8s 0.3s ease both", opacity: 0, animationFillMode: "forwards" }}>
          {[
            { label: "Instruments", value: 5, suffix: "" },
            { label: "Game Modes", value: 5, suffix: "" },
            { label: "AI Lyrics Generated", value: 1200, suffix: "+" },
            { label: "Tracks Created", value: 3400, suffix: "+" },
          ].map((s, i) => (
            <div key={i} style={{ textAlign: "center" }}>
              <div style={{ fontSize: 32, fontWeight: 900, color: "#fff", fontFamily: "monospace" }}>
                <AnimatedCounter target={s.value} suffix={s.suffix} />
              </div>
              <div style={{ fontSize: 10, color: "#444", letterSpacing: 2, fontFamily: "monospace", marginTop: 4 }}>{s.label.toUpperCase()}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section id="features" style={{ padding: "80px 24px", maxWidth: 900, margin: "0 auto", position: "relative", zIndex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: 56 }}>
          <div style={{ fontSize: 10, color: "#f97316", letterSpacing: 4, fontFamily: "monospace", marginBottom: 12 }}>WHAT'S INSIDE</div>
          <h2 style={{ fontSize: 36, fontWeight: 900, color: "#fff" }}>Everything a Musician Needs</h2>
          <p style={{ color: "#555", marginTop: 12, fontSize: 14 }}>Six powerful modes, one seamless experience.</p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 16 }}>
          {FEATURES.map((f, i) => (
            <div key={i} style={{
              padding: "24px 20px", borderRadius: 16,
              background: "#07071a", border: `1px solid ${f.color}22`,
              transition: "all 0.3s",
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = f.color + "66"; e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = `0 12px 32px ${f.color}22`; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = f.color + "22"; e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "none"; }}>
              <div style={{ fontSize: 32, marginBottom: 14 }}>{f.icon}</div>
              <div style={{ fontSize: 15, fontWeight: 800, color: "#fff", marginBottom: 8 }}>{f.title}</div>
              <div style={{ fontSize: 12, color: "#555", lineHeight: 1.7 }}>{f.desc}</div>
              <div style={{ marginTop: 14, height: 2, background: `linear-gradient(90deg, ${f.color}, transparent)`, borderRadius: 1 }} />
            </div>
          ))}
        </div>
      </section>

      {/* ── MODES PREVIEW ── */}
      <section id="modes" style={{ padding: "80px 24px", background: "linear-gradient(180deg, #030308, #07071a, #030308)", position: "relative", zIndex: 1 }}>
        <div style={{ maxWidth: 700, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <div style={{ fontSize: 10, color: "#a855f7", letterSpacing: 4, fontFamily: "monospace", marginBottom: 12 }}>INTERACTIVE PREVIEW</div>
            <h2 style={{ fontSize: 36, fontWeight: 900, color: "#fff" }}>Pick Your Mode</h2>
          </div>
          {/* Mode tabs */}
          <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap", marginBottom: 32 }}>
            {MODES.map(m => (
              <div key={m.id} onClick={() => setActiveMode(m.id)} style={{
                padding: "9px 18px", borderRadius: 20, cursor: "pointer",
                background: activeMode === m.id ? m.color : "#0d0d1a",
                border: `1px solid ${activeMode === m.id ? m.color : "#1e1e3a"}`,
                color: activeMode === m.id ? "#000" : "#555",
                fontSize: 12, fontWeight: activeMode === m.id ? 800 : 400,
                fontFamily: "monospace", transition: "all 0.2s",
                display: "flex", alignItems: "center", gap: 6,
              }}>
                <span>{m.icon}</span> {m.label}
              </div>
            ))}
          </div>
          {/* Mode preview card */}
          {currentMode && (
            <div style={{
              borderRadius: 20, overflow: "hidden",
              border: `1px solid ${currentMode.color}44`,
              background: "#07071a",
              boxShadow: `0 0 60px ${currentMode.color}22`,
              animation: "slideIn 0.3s ease",
            }}>
              <div style={{ height: 3, background: `linear-gradient(90deg, transparent, ${currentMode.color}, transparent)` }} />
              <div style={{ padding: "32px 28px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
                  <span style={{ fontSize: 36 }}>{currentMode.icon}</span>
                  <div>
                    <div style={{ fontSize: 20, fontWeight: 900, color: "#fff" }}>{currentMode.label} Mode</div>
                    <div style={{ fontSize: 11, color: currentMode.color, fontFamily: "monospace", letterSpacing: 1 }}>INTERACTIVE · BROWSER-BASED · NO DOWNLOAD</div>
                  </div>
                </div>
                {/* Visual preview */}
                <div style={{ display: "flex", gap: 10, justifyContent: "center", marginBottom: 24 }}>
                  {currentMode.preview.map((p, i) => (
                    <div key={i} style={{
                      width: 60, height: 60, borderRadius: 12,
                      background: `${currentMode.color}18`,
                      border: `2px solid ${currentMode.color}66`,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 16, fontWeight: 900, color: currentMode.color,
                      fontFamily: "monospace",
                      animation: `pulse 1.5s ${i * 0.15}s ease-in-out infinite`,
                    }}>{p}</div>
                  ))}
                </div>
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 12, color: "#555", marginBottom: 16 }}>
                    {activeMode === "guitar" && "Hit notes as they reach the bottom lane. Build streaks for score multipliers."}
                    {activeMode === "drums" && "Tap 8 pads live or record a step-sequencer pattern at any BPM."}
                    {activeMode === "piano" && "Play a full keyboard with black keys using your computer keyboard."}
                    {activeMode === "karaoke" && "Follow scrolling lyrics and let your mic score your singing performance."}
                    {activeMode === "studio" && "Build chord progressions, write lyrics, and generate AI songs."}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* ── PRICING ── */}
      <section id="pricing" style={{ padding: "80px 24px", maxWidth: 900, margin: "0 auto", position: "relative", zIndex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <div style={{ fontSize: 10, color: "#06b6d4", letterSpacing: 4, fontFamily: "monospace", marginBottom: 12 }}>MEMBERSHIP</div>
          <h2 style={{ fontSize: 36, fontWeight: 900, color: "#fff" }}>Simple, Transparent Pricing</h2>
          <p style={{ color: "#555", marginTop: 12, fontSize: 14 }}>Start free. Upgrade when you're ready. Cancel anytime.</p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
          {PLANS.map((plan, i) => (
            <div key={i} style={{
              borderRadius: 20, overflow: "hidden",
              border: `1px solid ${plan.color}44`,
              background: i === 1 ? "linear-gradient(135deg, #00101a, #001520)" : "#07071a",
              boxShadow: i === 1 ? `0 0 40px ${plan.color}22` : "none",
              transform: i === 1 ? "scale(1.03)" : "scale(1)",
              position: "relative",
            }}>
              {plan.badge && (
                <div style={{ position: "absolute", top: 14, right: 14, padding: "3px 10px", borderRadius: 10, background: plan.color, color: "#000", fontSize: 8, fontWeight: 900, letterSpacing: 2, fontFamily: "monospace" }}>{plan.badge}</div>
              )}
              <div style={{ height: 3, background: `linear-gradient(90deg, transparent, ${plan.color}, transparent)` }} />
              <div style={{ padding: "28px 22px" }}>
                <div style={{ fontSize: 30, marginBottom: 8 }}>{plan.emoji}</div>
                <div style={{ fontSize: 17, fontWeight: 900, color: "#fff", marginBottom: 4 }}>{plan.name}</div>
                <div style={{ display: "flex", alignItems: "baseline", gap: 2, marginBottom: 20 }}>
                  <span style={{ fontSize: 32, fontWeight: 900, color: plan.color }}>{plan.price}</span>
                  {plan.period && <span style={{ color: "#555", fontSize: 12 }}>{plan.period}</span>}
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 24 }}>
                  {plan.perks.map((p, j) => (
                    <div key={j} style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                      <span style={{ color: plan.color, fontSize: 12, marginTop: 1 }}>✓</span>
                      <span style={{ fontSize: 12, color: "#8888aa", lineHeight: 1.5 }}>{p}</span>
                    </div>
                  ))}
                </div>
                <a href="#" style={{
                  display: "block", textAlign: "center", padding: "12px 0", borderRadius: 10,
                  background: plan.price === "Free" ? "transparent" : `linear-gradient(135deg, ${plan.color}, ${plan.color}cc)`,
                  border: plan.price === "Free" ? `1px solid ${plan.color}44` : "none",
                  color: plan.price === "Free" ? plan.color : "#fff",
                  fontSize: 12, fontWeight: 800, textDecoration: "none",
                  fontFamily: "monospace", letterSpacing: 1, transition: "all 0.2s",
                }}
                  onMouseEnter={e => e.currentTarget.style.transform = "translateY(-1px)"}
                  onMouseLeave={e => e.currentTarget.style.transform = "none"}>
                  {plan.price === "Free" ? "Play Free" : "Subscribe Now"}
                </a>
              </div>
            </div>
          ))}
        </div>
        <div style={{ textAlign: "center", marginTop: 24, fontSize: 11, color: "#333", fontFamily: "monospace" }}>
          🔒 Secure payments via Stripe · Cancel anytime · HumanLayerAI LLC
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section style={{ padding: "80px 24px", background: "linear-gradient(180deg, #030308, #07071a)", position: "relative", zIndex: 1 }}>
        <div style={{ maxWidth: 800, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <div style={{ fontSize: 10, color: "#facc15", letterSpacing: 4, fontFamily: "monospace", marginBottom: 12 }}>COMMUNITY LOVE</div>
            <h2 style={{ fontSize: 36, fontWeight: 900, color: "#fff" }}>Players Are Talking</h2>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
            {TESTIMONIALS.map((t, i) => (
              <div key={i} style={{ padding: "24px 20px", borderRadius: 16, background: "#07071a", border: "1px solid #1e1e3a" }}>
                <StarRating count={t.stars} />
                <p style={{ fontSize: 12, color: "#8888aa", lineHeight: 1.8, margin: "12px 0 16px", fontStyle: "italic" }}>"{t.quote}"</p>
                <div style={{ fontSize: 12, fontWeight: 700, color: "#fff" }}>{t.name}</div>
                <div style={{ fontSize: 10, color: "#444", fontFamily: "monospace" }}>{t.role}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── ABOUT ── */}
      <section id="about" style={{ padding: "80px 24px", maxWidth: 700, margin: "0 auto", position: "relative", zIndex: 1, textAlign: "center" }}>
        <div style={{ fontSize: 10, color: "#7c3aed", letterSpacing: 4, fontFamily: "monospace", marginBottom: 12 }}>ABOUT US</div>
        <h2 style={{ fontSize: 32, fontWeight: 900, color: "#fff", marginBottom: 20 }}>Built by HumanLayerAI LLC</h2>
        <div style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 72, height: 72, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #06b6d4)", fontSize: 34, marginBottom: 24, boxShadow: "0 0 40px #7c3aed44" }}>🧠</div>
        <p style={{ fontSize: 14, color: "#6b7280", lineHeight: 1.9, marginBottom: 20 }}>
          HumanLayerAI LLC is a technology and media company focused on building intelligent, human-centered digital experiences. RockForge™ is our flagship music gaming platform — combining the joy of performance games with the power of AI creativity tools.
        </p>
        <p style={{ fontSize: 14, color: "#555", lineHeight: 1.9, marginBottom: 32 }}>
          We believe music should be accessible, fun, and endlessly creative — for beginners and professionals alike.
        </p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <a href="mailto:HumanLayerAI.ops@gmail.com" style={{
            padding: "12px 24px", borderRadius: 10,
            background: "linear-gradient(135deg, #7c3aed, #a855f7)",
            color: "#fff", fontSize: 12, fontWeight: 700, textDecoration: "none",
            fontFamily: "monospace", letterSpacing: 1,
          }}>📧 Contact Us</a>
          <a href="#pricing" style={{
            padding: "12px 24px", borderRadius: 10,
            border: "1px solid #333", background: "transparent",
            color: "#888", fontSize: 12, fontWeight: 700, textDecoration: "none",
            fontFamily: "monospace", letterSpacing: 1, transition: "all 0.2s",
          }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "#555"; e.currentTarget.style.color = "#fff"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "#333"; e.currentTarget.style.color = "#888"; }}>
            💎 Join Now
          </a>
        </div>
      </section>

      {/* ── CTA BANNER ── */}
      <section style={{ padding: "60px 24px", position: "relative", zIndex: 1 }}>
        <div style={{
          maxWidth: 700, margin: "0 auto", borderRadius: 24, padding: "48px 32px", textAlign: "center",
          background: "linear-gradient(135deg, #0f0520, #07071a, #0f0520)",
          border: "1px solid #7c3aed44",
          boxShadow: "0 0 80px #7c3aed22",
          position: "relative", overflow: "hidden",
        }}>
          <div style={{ position: "absolute", top: -40, left: "50%", transform: "translateX(-50%)", width: 300, height: 150, background: "radial-gradient(ellipse, #7c3aed11, transparent)", pointerEvents: "none" }} />
          <div style={{ fontSize: 42, marginBottom: 16 }}>🚀</div>
          <h2 style={{ fontSize: 28, fontWeight: 900, color: "#fff", marginBottom: 12 }}>Ready to Rock?</h2>
          <p style={{ fontSize: 13, color: "#555", marginBottom: 28, lineHeight: 1.8 }}>Join thousands of players already creating and performing on RockForge. Start free — no credit card required.</p>
          <a href="#modes" style={{
            display: "inline-block", padding: "16px 40px", borderRadius: 12,
            background: "linear-gradient(135deg, #f97316, #facc15)",
            color: "#000", fontSize: 15, fontWeight: 900, textDecoration: "none",
            letterSpacing: 2, fontFamily: "monospace",
            boxShadow: "0 8px 32px #f9731644",
          }}>🎸 START PLAYING FREE</a>
          <div style={{ marginTop: 16, fontSize: 10, color: "#333", fontFamily: "monospace" }}>No download · Works in any browser · HumanLayerAI LLC</div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{ borderTop: "1px solid #0f0f1a", padding: "40px 24px 24px", position: "relative", zIndex: 1 }}>
        <div style={{ maxWidth: 900, margin: "0 auto", display: "flex", flexWrap: "wrap", gap: 32, justifyContent: "space-between", marginBottom: 32 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <div style={{ width: 28, height: 28, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #06b6d4)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13 }}>🧠</div>
              <span style={{ fontWeight: 900, fontSize: 14, background: "linear-gradient(135deg, #a78bfa, #06b6d4)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>HumanLayerAI LLC</span>
            </div>
            <div style={{ fontSize: 11, color: "#333", lineHeight: 1.8, fontFamily: "monospace" }}>
              <div>RockForge™ Music Game Platform</div>
              <div>Technology & Media Division</div>
              <div style={{ marginTop: 6 }}>
                <a href="mailto:HumanLayerAI.ops@gmail.com" style={{ color: "#555", textDecoration: "none" }}>HumanLayerAI.ops@gmail.com</a>
              </div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 48, flexWrap: "wrap" }}>
            {[
              { title: "Product", links: ["Guitar Hero", "Drum Machine", "Piano Mode", "Karaoke", "Studio"] },
              { title: "Company", links: ["About", "Pricing", "Contact", "Privacy", "Terms"] },
            ].map((col, i) => (
              <div key={i}>
                <div style={{ fontSize: 9, color: "#333", letterSpacing: 3, fontFamily: "monospace", marginBottom: 12 }}>{col.title.toUpperCase()}</div>
                {col.links.map(l => (
                  <div key={l} style={{ fontSize: 12, color: "#444", marginBottom: 6, cursor: "pointer", transition: "color 0.2s" }}
                    onMouseEnter={e => e.target.style.color = "#888"}
                    onMouseLeave={e => e.target.style.color = "#444"}>{l}</div>
                ))}
              </div>
            ))}
          </div>
        </div>
        <div style={{ borderTop: "1px solid #0a0a18", paddingTop: 20, display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
          <div style={{ fontSize: 10, color: "#222", fontFamily: "monospace" }}>© {new Date().getFullYear()} HumanLayerAI LLC — All Rights Reserved · RockForge™</div>
          <div style={{ fontSize: 10, color: "#222", fontFamily: "monospace" }}>🔒 Payments by Stripe · CEO & Founder · HumanLayerAI LLC</div>
        </div>
      </footer>
    </div>
  );
}
