import { useState } from "react";

const PRESS_SECTIONS = [
  { id: "overview", label: "📋 Overview", icon: "📋" },
  { id: "company", label: "🧠 Company", icon: "🧠" },
  { id: "product", label: "🎸 Product", icon: "🎸" },
  { id: "stats", label: "📊 Stats", icon: "📊" },
  { id: "quotes", label: "💬 Quotes", icon: "💬" },
  { id: "assets", label: "🖼️ Assets", icon: "🖼️" },
  { id: "contact", label: "📧 Contact", icon: "📧" },
];

const BOILERPLATE = `HumanLayerAI LLC is a technology and media company specializing in AI-powered digital experiences. Founded with the mission of making human creativity more powerful through intelligent tools, HumanLayerAI LLC builds products that sit at the intersection of entertainment, artificial intelligence, and music. RockForge™ is the company's flagship product — a browser-based music game studio that combines performance gaming with AI-powered creation tools.`;

const PRODUCT_DESCRIPTION = `RockForge is a browser-based music game studio that combines five distinct instruments and game modes into a single, unified experience. Players can hit notes on a Guitar Hero-style highway, program beats on an 8-pad drum machine with step sequencer, play a full piano keyboard with chord library, sing karaoke with real-time microphone scoring, and create original music in a built-in studio complete with an AI lyric generator powered by Claude.

RockForge requires no download or installation and runs in any modern web browser. The platform offers three membership tiers: a free Starter plan, a Band Member plan at $4.99 per month, and a Rockstar Pro plan at $9.99 per month. All payments are processed securely through Stripe.`;

const KEY_FACTS = [
  { label: "Company Name", value: "HumanLayerAI LLC" },
  { label: "Product Name", value: "RockForge™" },
  { label: "Product Type", value: "Browser-based Music Game Studio" },
  { label: "Platform", value: "Web — any modern browser, no download" },
  { label: "Launch Date", value: new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }) },
  { label: "Pricing", value: "Free / $4.99 mo / $9.99 mo" },
  { label: "Payment Processor", value: "Stripe" },
  { label: "Website", value: "rockforge.io" },
  { label: "Press Contact", value: "HumanLayerAI.ops@gmail.com" },
  { label: "Business Structure", value: "LLC (Limited Liability Company)" },
  { label: "Industry", value: "Gaming · Music Technology · AI" },
];

const GAME_MODES = [
  { name: "Guitar Hero Mode", icon: "🎸", desc: "A 5-lane scrolling note highway inspired by rhythm games. Players press keyboard keys or tap on-screen buttons to hit colored notes as they reach the hit zone. Scoring rewards accuracy and combo streaks, with multipliers rewarding sustained performance.", tech: "Web Audio API, requestAnimationFrame, CSS transforms" },
  { name: "Drum Machine", icon: "🥁", desc: "An 8-pad drum kit featuring Hi-Hat, Snare, Kick, two Toms, Crash, Ride, and Cowbell. Each pad generates synthesized drum sounds via the Web Audio API. A built-in 8-step sequencer allows users to record and loop drum patterns at any BPM.", tech: "Web Audio API oscillators, buffer synthesis, setInterval" },
  { name: "Piano Keyboard", icon: "🎹", desc: "A full playable piano keyboard spanning one octave plus with black keys. Notes map to computer keyboard keys. Includes a chord library with 6 common chord voicings (C, G, Am, F, D, Em) and a note history display.", tech: "Web Audio API oscillators, triangle waveform synthesis" },
  { name: "Karaoke Mode", icon: "🎤", desc: "Three built-in songs with scrolling lyrics. Optionally activates the user's microphone via the MediaDevices API and analyzes audio frequency in real-time using an AnalyserNode, translating vocal volume into a live score.", tech: "MediaDevices API, Web Audio AnalyserNode, FFT analysis" },
  { name: "Music Creation Studio", icon: "🎚️", desc: "A full-featured music creation environment where users set song title, artist, BPM, and genre. Users build chord progressions by clicking from the chord library, write lyrics manually, or invoke the AI lyric generator. Tracks can be saved locally.", tech: "Anthropic Claude API, React state management" },
  { name: "AI Lyric Generator", icon: "✨", desc: "Powered by Anthropic's Claude AI. Users specify song title, genre (Rock, Pop, Metal, Jazz, Blues, Country, Hip-Hop, EDM), BPM, and chord progression. The AI generates four genre-appropriate original song lyrics tailored to these inputs.", tech: "Anthropic Claude claude-sonnet model, REST API" },
];

const MEMBERSHIP_TIERS = [
  { name: "Starter", price: "Free", features: ["Guitar Hero & Drums (basic)", "Piano keyboard", "3 built-in songs", "5 chord presets"], color: "#22c55e" },
  { name: "Band Member", price: "$4.99/month", features: ["All 5 instruments", "Karaoke + mic scoring", "AI lyric generator (15/mo)", "Save up to 20 tracks", "Full chord library"], color: "#06b6d4", badge: "Most Popular" },
  { name: "Rockstar Pro", price: "$9.99/month", features: ["Unlimited AI lyrics", "Unlimited track saves", "Custom song builder", "Early access to new modes", "VIP Discord + priority support"], color: "#f97316", badge: "Best Value" },
];

const EXEC_QUOTES = [
  {
    quote: "We built RockForge because we believe music gaming should be accessible to everyone — no console, no download, no barrier to entry. Just open a tab and start playing.",
    attribution: "CEO & Founder, HumanLayerAI LLC",
    context: "On the vision for RockForge"
  },
  {
    quote: "The combination of traditional rhythm gaming with AI-powered music creation is genuinely new. Players aren't just hitting notes — they're composing, performing, and sharing original music.",
    attribution: "CEO & Founder, HumanLayerAI LLC",
    context: "On what makes RockForge unique"
  },
  {
    quote: "HumanLayerAI LLC exists to prove that AI makes human creativity more powerful, not less. RockForge is our first proof of that — every song the AI helps create starts with a human idea.",
    attribution: "CEO & Founder, HumanLayerAI LLC",
    context: "On AI and human creativity"
  },
];

const SUGGESTED_ANGLES = [
  { headline: "Browser-Based Guitar Hero Meets AI Music Studio in New Platform", pub: "Best for: Gaming publications, tech blogs" },
  { headline: "HumanLayerAI LLC Launches RockForge: The Music Game That Creates Music", pub: "Best for: Music tech publications" },
  { headline: "AI Writes Your Songs While You Play: Inside RockForge", pub: "Best for: AI/Tech publications" },
  { headline: "Startup Builds Guitar Hero + Rock Band + AI Music Studio Into a Single Browser Tab", pub: "Best for: Startup/Business press" },
  { headline: "No Download Required: RockForge Brings Rhythm Gaming to the Browser", pub: "Best for: Consumer tech publications" },
  { headline: "From Karaoke to Chord Progressions: RockForge Is the Music App That Does Everything", pub: "Best for: Lifestyle, entertainment media" },
];

const BRAND_COLORS = [
  { name: "Primary Orange", hex: "#F97316", use: "CTAs, highlights" },
  { name: "Primary Yellow", hex: "#FACC15", use: "Accents, scoring" },
  { name: "Brand Violet", hex: "#7C3AED", use: "HumanLayerAI brand" },
  { name: "Brand Cyan", hex: "#06B6D4", use: "Band Member tier" },
  { name: "Guitar Green", hex: "#22C55E", use: "Free tier, Guitar mode" },
  { name: "Karaoke Purple", hex: "#A855F7", use: "Karaoke mode" },
  { name: "Dark Base", hex: "#050508", use: "Background" },
];

export default function PressKit() {
  const [activeSection, setActiveSection] = useState("overview");
  const [copied, setCopied] = useState(null);

  const copyText = (text, id) => {
    navigator.clipboard?.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const CopyBtn = ({ text, id, label = "Copy" }) => (
    <button onClick={() => copyText(text, id)} style={{
      padding: "5px 12px", borderRadius: 8, border: "1px solid #1e1e3a",
      background: copied === id ? "#10b98122" : "transparent",
      color: copied === id ? "#10b981" : "#555",
      fontSize: 10, cursor: "pointer", fontFamily: "monospace", transition: "all 0.2s",
    }}>{copied === id ? "✓ Copied" : label}</button>
  );

  const renderSection = () => {
    switch (activeSection) {
      case "overview": return (
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          {/* Hero */}
          <div style={{ background: "linear-gradient(135deg, #0f0520, #07071a)", border: "1px solid #7c3aed44", borderRadius: 16, padding: "32px 28px", textAlign: "center", position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: "linear-gradient(90deg, transparent, #7c3aed, #f97316, #7c3aed, transparent)" }} />
            <div style={{ fontSize: 48, marginBottom: 12 }}>🎸</div>
            <div style={{ fontSize: 28, fontWeight: 900, color: "#fff", marginBottom: 6 }}>RockForge™</div>
            <div style={{ fontSize: 13, color: "#a78bfa", marginBottom: 16, letterSpacing: 1 }}>by HumanLayerAI LLC</div>
            <div style={{ fontSize: 13, color: "#8888aa", lineHeight: 1.8, maxWidth: 500, margin: "0 auto 20px" }}>
              The browser-based music game studio combining Guitar Hero, drums, piano, karaoke, and AI music creation in a single platform.
            </div>
            <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
              {["🎸 Guitar Hero", "🥁 Drum Machine", "🎹 Piano", "🎤 Karaoke", "✨ AI Studio"].map((f, i) => (
                <span key={i} style={{ padding: "4px 12px", borderRadius: 20, background: "#1e1e3a", color: "#8888aa", fontSize: 11 }}>{f}</span>
              ))}
            </div>
          </div>

          {/* Key facts table */}
          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, overflow: "hidden" }}>
            <div style={{ padding: "16px 20px", borderBottom: "1px solid #1e1e3a", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3 }}>KEY FACTS AT A GLANCE</div>
              <CopyBtn text={KEY_FACTS.map(f => `${f.label}: ${f.value}`).join("\n")} id="keyfacts" label="Copy All" />
            </div>
            <div>
              {KEY_FACTS.map((fact, i) => (
                <div key={i} style={{ display: "flex", padding: "12px 20px", borderBottom: i < KEY_FACTS.length - 1 ? "1px solid #0f0f1a" : "none", gap: 20 }}>
                  <div style={{ width: 140, fontSize: 11, color: "#3d3d6a", flexShrink: 0 }}>{fact.label}</div>
                  <div style={{ fontSize: 12, color: "#c4c4d4", fontWeight: 600, flex: 1 }}>{fact.value}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Suggested angles */}
          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "20px" }}>
            <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3, marginBottom: 16 }}>📰 SUGGESTED STORY ANGLES</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {SUGGESTED_ANGLES.map((a, i) => (
                <div key={i} style={{ padding: "12px 16px", background: "#07071a", borderRadius: 10, border: "1px solid #12122a", display: "flex", gap: 12, alignItems: "flex-start" }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: "#fff", marginBottom: 4 }}>"{a.headline}"</div>
                    <div style={{ fontSize: 10, color: "#3d3d6a" }}>{a.pub}</div>
                  </div>
                  <CopyBtn text={a.headline} id={`angle${i}`} />
                </div>
              ))}
            </div>
          </div>
        </div>
      );

      case "company": return (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "24px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
              <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3 }}>COMPANY BOILERPLATE</div>
              <CopyBtn text={BOILERPLATE} id="boilerplate" label="Copy Text" />
            </div>
            <div style={{ display: "flex", gap: 16, marginBottom: 20 }}>
              <div style={{ width: 56, height: 56, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #06b6d4)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, flexShrink: 0 }}>🧠</div>
              <div>
                <div style={{ fontSize: 18, fontWeight: 900, color: "#fff", marginBottom: 2 }}>HumanLayerAI LLC</div>
                <div style={{ fontSize: 11, color: "#7c3aed", letterSpacing: 1 }}>Technology & Media Company</div>
              </div>
            </div>
            <p style={{ fontSize: 13, color: "#8888aa", lineHeight: 1.9 }}>{BOILERPLATE}</p>
          </div>

          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "24px" }}>
            <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3, marginBottom: 16 }}>LEADERSHIP</div>
            <div style={{ padding: "20px", background: "#07071a", borderRadius: 12, border: "1px solid #1e1e3a" }}>
              <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 12 }}>
                <div style={{ width: 52, height: 52, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #f97316)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>👑</div>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 800, color: "#fff" }}>CEO & Founder</div>
                  <div style={{ fontSize: 11, color: "#7c3aed" }}>HumanLayerAI LLC</div>
                </div>
              </div>
              <div style={{ fontSize: 12, color: "#8888aa", lineHeight: 1.8 }}>
                The CEO and founder of HumanLayerAI LLC leads product vision and strategy for the company's music gaming and AI technology division. RockForge represents the company's flagship product and first public launch.
              </div>
              <div style={{ marginTop: 12, fontSize: 11, color: "#3d3d6a" }}>📧 HumanLayerAI.ops@gmail.com</div>
            </div>
          </div>

          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "24px" }}>
            <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3, marginBottom: 16 }}>BRAND COLORS</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 10 }}>
              {BRAND_COLORS.map((c, i) => (
                <div key={i} onClick={() => copyText(c.hex, `color${i}`)} style={{ padding: "12px", borderRadius: 10, background: "#07071a", border: "1px solid #12122a", cursor: "pointer", transition: "all 0.2s" }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = c.hex}
                  onMouseLeave={e => e.currentTarget.style.borderColor = "#12122a"}>
                  <div style={{ width: "100%", height: 32, borderRadius: 6, background: c.hex, marginBottom: 8, boxShadow: `0 0 12px ${c.hex}44` }} />
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#fff" }}>{c.name}</div>
                  <div style={{ fontSize: 10, color: "#555", fontFamily: "monospace" }}>{copied === `color${i}` ? "✓ Copied!" : c.hex}</div>
                  <div style={{ fontSize: 9, color: "#3d3d6a", marginTop: 2 }}>{c.use}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      );

      case "product": return (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "24px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3 }}>PRODUCT DESCRIPTION</div>
              <CopyBtn text={PRODUCT_DESCRIPTION} id="proddesc" label="Copy" />
            </div>
            <p style={{ fontSize: 13, color: "#8888aa", lineHeight: 1.9 }}>{PRODUCT_DESCRIPTION}</p>
          </div>

          {GAME_MODES.map((mode, i) => (
            <div key={i} style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 14, padding: "20px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                  <span style={{ fontSize: 24 }}>{mode.icon}</span>
                  <div style={{ fontSize: 14, fontWeight: 800, color: "#fff" }}>{mode.name}</div>
                </div>
                <CopyBtn text={mode.desc} id={`mode${i}`} />
              </div>
              <p style={{ fontSize: 12, color: "#8888aa", lineHeight: 1.8, marginBottom: 8 }}>{mode.desc}</p>
              <div style={{ fontSize: 10, color: "#3d3d6a", fontFamily: "monospace" }}>Tech: {mode.tech}</div>
            </div>
          ))}

          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "24px" }}>
            <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3, marginBottom: 16 }}>MEMBERSHIP TIERS</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 12 }}>
              {MEMBERSHIP_TIERS.map((tier, i) => (
                <div key={i} style={{ padding: "16px", borderRadius: 12, background: "#07071a", border: `1px solid ${tier.color}33` }}>
                  {tier.badge && <div style={{ fontSize: 9, color: tier.color, letterSpacing: 2, marginBottom: 6 }}>{tier.badge.toUpperCase()}</div>}
                  <div style={{ fontSize: 14, fontWeight: 800, color: "#fff" }}>{tier.name}</div>
                  <div style={{ fontSize: 18, fontWeight: 900, color: tier.color, margin: "6px 0 10px" }}>{tier.price}</div>
                  {tier.features.map((f, j) => (
                    <div key={j} style={{ fontSize: 11, color: "#8888aa", marginBottom: 4, display: "flex", gap: 6 }}>
                      <span style={{ color: tier.color }}>✓</span> {f}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      );

      case "stats": return (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12 }}>
            {[
              { label: "Game Modes", value: "5", icon: "🎮", color: "#f97316" },
              { label: "Instruments", value: "5", icon: "🎸", color: "#22c55e" },
              { label: "Pricing Tiers", value: "3", icon: "💎", color: "#a855f7" },
              { label: "Browser Support", value: "100%", icon: "🌐", color: "#06b6d4" },
              { label: "Download Required", value: "None", icon: "✅", color: "#10b981" },
              { label: "AI Model", value: "Claude", icon: "✨", color: "#facc15" },
            ].map((s, i) => (
              <div key={i} style={{ padding: "20px 16px", background: "#0f0f1f", border: `1px solid ${s.color}22`, borderRadius: 14, textAlign: "center" }}>
                <div style={{ fontSize: 28, marginBottom: 8 }}>{s.icon}</div>
                <div style={{ fontSize: 26, fontWeight: 900, color: s.color, fontFamily: "monospace" }}>{s.value}</div>
                <div style={{ fontSize: 10, color: "#3d3d6a", marginTop: 4, letterSpacing: 1 }}>{s.label.toUpperCase()}</div>
              </div>
            ))}
          </div>

          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "24px" }}>
            <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3, marginBottom: 16 }}>TECHNICAL SPECIFICATIONS</div>
            {[
              ["Platform", "Web browser (Chrome, Firefox, Safari, Edge)"],
              ["Technology Stack", "React, Web Audio API, MediaDevices API"],
              ["AI Integration", "Anthropic Claude (claude-sonnet model)"],
              ["Payment Processing", "Stripe"],
              ["Hosting", "Vercel (recommended)"],
              ["Download Required", "None"],
              ["Account Required", "No (for free tier)"],
              ["Mobile Support", "Yes (touch-optimized)"],
              ["Keyboard Support", "Full keyboard mapping for all instruments"],
            ].map(([k, v], i) => (
              <div key={i} style={{ display: "flex", gap: 20, padding: "10px 0", borderBottom: "1px solid #0f0f1a" }}>
                <div style={{ width: 160, fontSize: 11, color: "#3d3d6a", flexShrink: 0 }}>{k}</div>
                <div style={{ fontSize: 12, color: "#c4c4d4" }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      );

      case "quotes": return (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ fontSize: 11, color: "#3d3d6a", padding: "0 4px" }}>All quotes are approved for use in press coverage and articles. Attribution: CEO & Founder, HumanLayerAI LLC.</div>
          {EXEC_QUOTES.map((q, i) => (
            <div key={i} style={{ background: "#0f0f1f", border: "1px solid #7c3aed33", borderRadius: 16, padding: "24px", position: "relative" }}>
              <div style={{ height: 2, background: "linear-gradient(90deg, #7c3aed, transparent)", borderRadius: 1, marginBottom: 16 }} />
              <div style={{ fontSize: 9, color: "#7c3aed", letterSpacing: 2, marginBottom: 12 }}>{q.context.toUpperCase()}</div>
              <blockquote style={{ fontSize: 15, color: "#e2e8f0", lineHeight: 1.8, fontStyle: "italic", margin: "0 0 16px", borderLeft: "3px solid #7c3aed", paddingLeft: 16 }}>
                "{q.quote}"
              </blockquote>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ fontSize: 11, color: "#555" }}>— {q.attribution}</div>
                <CopyBtn text={`"${q.quote}" — ${q.attribution}`} id={`quote${i}`} label="Copy Quote" />
              </div>
            </div>
          ))}
        </div>
      );

      case "assets": return (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "24px" }}>
            <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3, marginBottom: 16 }}>LOGO REPRESENTATIONS</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12 }}>
              {[
                { bg: "#030308", fg: "light", label: "Dark Background" },
                { bg: "#ffffff", fg: "dark", label: "Light Background" },
                { bg: "linear-gradient(135deg, #7c3aed, #06b6d4)", fg: "light", label: "Gradient Background" },
              ].map((variant, i) => (
                <div key={i} style={{ borderRadius: 12, overflow: "hidden", border: "1px solid #1e1e3a" }}>
                  <div style={{ height: 100, background: variant.bg, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6 }}>
                    <div style={{ width: 40, height: 40, borderRadius: "50%", background: variant.fg === "light" ? "rgba(255,255,255,0.2)" : "rgba(0,0,0,0.1)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>🧠</div>
                    <div style={{ fontSize: 14, fontWeight: 900, color: variant.fg === "light" ? "#fff" : "#111" }}>HumanLayerAI</div>
                    <div style={{ fontSize: 8, color: variant.fg === "light" ? "rgba(255,255,255,0.5)" : "rgba(0,0,0,0.4)", letterSpacing: 3 }}>ROCKFORGE™</div>
                  </div>
                  <div style={{ padding: "8px 12px", background: "#07071a" }}>
                    <div style={{ fontSize: 10, color: "#555" }}>{variant.label}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "24px" }}>
            <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3, marginBottom: 16 }}>USAGE GUIDELINES</div>
            {[
              { rule: "✅ Do", items: ["Use the full company name: HumanLayerAI LLC", "Include the ™ symbol with RockForge", "Use approved quotes with full attribution", "Link to rockforge.io when mentioning the product"] },
              { rule: "❌ Don't", items: ["Modify or distort the logo", "Use unofficial screenshots as product images", "Attribute quotes to a named individual", "Claim endorsement without written permission"] },
            ].map((g, i) => (
              <div key={i} style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: i === 0 ? "#10b981" : "#ef4444", marginBottom: 8 }}>{g.rule}</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {g.items.map((item, j) => (
                    <div key={j} style={{ fontSize: 12, color: "#8888aa", paddingLeft: 16 }}>{item}</div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      );

      case "contact": return (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ background: "linear-gradient(135deg, #0f0520, #07071a)", border: "1px solid #7c3aed44", borderRadius: 16, padding: "32px 28px", textAlign: "center" }}>
            <div style={{ fontSize: 36, marginBottom: 12 }}>📧</div>
            <div style={{ fontSize: 20, fontWeight: 900, color: "#fff", marginBottom: 6 }}>Press & Media Inquiries</div>
            <div style={{ fontSize: 13, color: "#8888aa", marginBottom: 20 }}>For interviews, product demos, review copies, and press partnerships</div>
            <a href="mailto:HumanLayerAI.ops@gmail.com" style={{ display: "inline-block", padding: "14px 28px", borderRadius: 12, background: "linear-gradient(135deg, #7c3aed, #a855f7)", color: "#fff", fontWeight: 800, textDecoration: "none", fontSize: 14, letterSpacing: 1 }}>HumanLayerAI.ops@gmail.com</a>
          </div>

          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "24px" }}>
            <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3, marginBottom: 16 }}>RESPONSE COMMITMENT</div>
            {[
              { type: "Press Inquiries", time: "Within 24 hours", color: "#22c55e" },
              { type: "Interview Requests", time: "Within 48 hours", color: "#06b6d4" },
              { type: "Review Copy Requests", time: "Within 24 hours", color: "#a855f7" },
              { type: "Partnership Inquiries", time: "Within 72 hours", color: "#f97316" },
            ].map((r, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: i < 3 ? "1px solid #0f0f1a" : "none" }}>
                <div style={{ fontSize: 12, color: "#c4c4d4" }}>{r.type}</div>
                <div style={{ fontSize: 11, color: r.color, fontFamily: "monospace" }}>{r.time}</div>
              </div>
            ))}
          </div>

          <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "24px" }}>
            <div style={{ fontSize: 10, color: "#3d3d6a", letterSpacing: 3, marginBottom: 16 }}>QUICK LINKS</div>
            {[
              { label: "🌐 Product Website", url: "rockforge.io", value: "https://rockforge.io" },
              { label: "💎 Pricing Page", url: "rockforge.io/pricing", value: "https://rockforge.io/pricing" },
              { label: "📧 Press Email", url: "HumanLayerAI.ops@gmail.com", value: "HumanLayerAI.ops@gmail.com" },
              { label: "🏢 Company", url: "HumanLayerAI LLC", value: "HumanLayerAI LLC" },
            ].map((link, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: i < 3 ? "1px solid #0f0f1a" : "none" }}>
                <div>
                  <div style={{ fontSize: 12, color: "#c4c4d4" }}>{link.label}</div>
                  <div style={{ fontSize: 10, color: "#6366f1", fontFamily: "monospace" }}>{link.url}</div>
                </div>
                <CopyBtn text={link.value} id={`link${i}`} />
              </div>
            ))}
          </div>
        </div>
      );

      default: return null;
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#09090f", color: "#fff", fontFamily: "'Courier New', monospace" }}>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 3px; }
        ::-webkit-scrollbar-thumb { background: #1e1e3a; }
      `}</style>

      {/* Header */}
      <div style={{ background: "linear-gradient(180deg, #0f0f1f, #09090f)", borderBottom: "1px solid #12122a", padding: "20px 20px 0" }}>
        <div style={{ maxWidth: 800, margin: "0 auto" }}>
          <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 4, marginBottom: 8 }}>HUMANLAYERAI LLC · OFFICIAL</div>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20 }}>
            <div style={{ width: 48, height: 48, borderRadius: 12, background: "linear-gradient(135deg, #7c3aed, #f97316)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>🎸</div>
            <div>
              <h1 style={{ fontSize: 22, fontWeight: 900, color: "#fff", margin: 0 }}>RockForge™ Press Kit</h1>
              <div style={{ fontSize: 10, color: "#3d3d6a", marginTop: 2 }}>Official media resources for journalists, bloggers & influencers</div>
            </div>
          </div>

          {/* Section tabs */}
          <div style={{ display: "flex", gap: 0, overflowX: "auto" }}>
            {PRESS_SECTIONS.map(s => (
              <div key={s.id} onClick={() => setActiveSection(s.id)} style={{
                padding: "10px 16px", cursor: "pointer", whiteSpace: "nowrap", fontSize: 11,
                borderBottom: activeSection === s.id ? "2px solid #7c3aed" : "2px solid transparent",
                color: activeSection === s.id ? "#a78bfa" : "#3d3d6a",
                fontWeight: activeSection === s.id ? 700 : 400, transition: "all 0.2s",
              }}>{s.label}</div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 800, margin: "0 auto", padding: "24px 20px 48px" }}>
        {renderSection()}
      </div>
    </div>
  );
}
