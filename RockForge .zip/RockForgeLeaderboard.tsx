import { useState, useEffect, useRef } from "react";

const MODES_LIST = ["Guitar Hero", "Drums", "Piano", "Karaoke", "Studio"];
const RANK_COLORS = ["#facc15", "#94a3b8", "#cd7f32", "#6366f1", "#22c55e"];
const RANK_LABELS = ["👑", "🥈", "🥉", "4th", "5th"];
const RANK_GLOWS  = ["#facc1566", "#94a3b833", "#cd7f3233", "#6366f133", "#22c55e33"];

const DEMO_SCORES = [
  { name: "NeonRider",   score: 98450, mode: "Guitar Hero", streak: 142, date: "2025-05-30", avatar: "🎸" },
  { name: "BeatQueen",   score: 87200, mode: "Drums",       streak: 98,  date: "2025-05-30", avatar: "🥁" },
  { name: "KeyMaster",   score: 76800, mode: "Piano",       streak: 115, date: "2025-05-29", avatar: "🎹" },
  { name: "VoiceOfGod",  score: 65300, mode: "Karaoke",     streak: 76,  date: "2025-05-29", avatar: "🎤" },
  { name: "StudioKing",  score: 54100, mode: "Studio",      streak: 60,  date: "2025-05-28", avatar: "🎚️" },
  { name: "RiffLord",    score: 49800, mode: "Guitar Hero", streak: 55,  date: "2025-05-28", avatar: "🎸" },
  { name: "DrumBot9k",   score: 43200, mode: "Drums",       streak: 44,  date: "2025-05-27", avatar: "🥁" },
  { name: "HarmonyX",   score: 38700, mode: "Piano",       streak: 39,  date: "2025-05-27", avatar: "🎹" },
  { name: "SingStarAce", score: 31400, mode: "Karaoke",     streak: 31,  date: "2025-05-26", avatar: "🎤" },
  { name: "BeatSmith",   score: 27900, mode: "Studio",      streak: 28,  date: "2025-05-26", avatar: "🎚️" },
];

function getRankStyle(idx) {
  return { color: RANK_COLORS[idx] || "#444", glow: RANK_GLOWS[idx] || "transparent", label: RANK_LABELS[idx] || `${idx + 1}` };
}

function ScoreBar({ score, max }) {
  const pct = Math.max(4, (score / max) * 100);
  return (
    <div style={{ height: 4, background: "#0d0d1a", borderRadius: 2, overflow: "hidden", marginTop: 4 }}>
      <div style={{ height: "100%", width: `${pct}%`, background: "linear-gradient(90deg, #6366f1, #a855f7)", borderRadius: 2, transition: "width 1s ease" }} />
    </div>
  );
}

export default function RockForgeLeaderboard() {
  const [scores, setScores] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [filterMode, setFilterMode] = useState("All");
  const [sortBy, setSortBy] = useState("score");
  const [showSubmit, setShowSubmit] = useState(false);
  const [form, setForm] = useState({ name: "", score: "", mode: "Guitar Hero", streak: "" });
  const [submitted, setSubmitted] = useState(false);
  const [flash, setFlash] = useState(null);
  const [tab, setTab] = useState("global"); // global | personal
  const [personalBest, setPersonalBest] = useState(null);
  const [animReady, setAnimReady] = useState(false);
  const storageKey = "rockforge_leaderboard_v1";

  // Load scores from storage or use demo data
  useEffect(() => {
    const load = async () => {
      try {
        const stored = await window.storage?.get(storageKey);
        if (stored?.value) {
          const parsed = JSON.parse(stored.value);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setScores(parsed);
            return;
          }
        }
      } catch {}
      setScores(DEMO_SCORES);
    };
    load();
    setTimeout(() => setAnimReady(true), 100);
  }, []);

  // Save to storage whenever scores change
  useEffect(() => {
    if (scores.length === 0) return;
    try { window.storage?.set(storageKey, JSON.stringify(scores)); } catch {}
  }, [scores]);

  // Filter + sort
  useEffect(() => {
    let list = [...scores];
    if (filterMode !== "All") list = list.filter(s => s.mode === filterMode);
    if (sortBy === "score") list.sort((a, b) => b.score - a.score);
    else if (sortBy === "streak") list.sort((a, b) => b.streak - a.streak);
    else if (sortBy === "recent") list.sort((a, b) => new Date(b.date) - new Date(a.date));
    setFiltered(list);
  }, [scores, filterMode, sortBy]);

  const topScore = filtered[0]?.score || 1;

  const handleSubmit = () => {
    if (!form.name.trim() || !form.score || isNaN(+form.score)) return;
    const entry = {
      name: form.name.trim(),
      score: parseInt(form.score),
      mode: form.mode,
      streak: parseInt(form.streak) || 0,
      date: new Date().toISOString().split("T")[0],
      avatar: { "Guitar Hero": "🎸", Drums: "🥁", Piano: "🎹", Karaoke: "🎤", Studio: "🎚️" }[form.mode] || "🎵",
      isNew: true,
    };
    setScores(prev => [entry, ...prev].slice(0, 50));
    setPersonalBest(entry);
    setFlash(entry.name);
    setSubmitted(true);
    setShowSubmit(false);
    setForm({ name: "", score: "", mode: "Guitar Hero", streak: "" });
    setTimeout(() => setFlash(null), 3000);
    setTimeout(() => setSubmitted(false), 5000);
  };

  const stats = {
    total: scores.length,
    topScore: Math.max(...scores.map(s => s.score)).toLocaleString(),
    topStreak: Math.max(...scores.map(s => s.streak)),
    modes: [...new Set(scores.map(s => s.mode))].length,
  };

  return (
    <div style={{ minHeight: "100vh", background: "#030308", color: "#fff", fontFamily: "'Courier New', monospace" }}>
      <style>{`
        @keyframes fadeUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
        @keyframes flashNew { 0%{background:#facc1533} 50%{background:#facc1511} 100%{background:transparent} }
        @keyframes crownBounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-4px)} }
        @keyframes rankIn { from{opacity:0;transform:translateX(-12px)} to{opacity:1;transform:translateX(0)} }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.6} }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 3px; }
        ::-webkit-scrollbar-thumb { background: #1e1e3a; }
      `}</style>

      {/* Header */}
      <div style={{ background: "linear-gradient(180deg, #07071a, #030308)", borderBottom: "1px solid #0f0f2a", padding: "20px 20px 0" }}>
        <div style={{ maxWidth: 700, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 20 }}>
            <div>
              <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 4, marginBottom: 8 }}>HUMANLAYERAI LLC · ROCKFORGE™</div>
              <h1 style={{ fontSize: 28, fontWeight: 900, margin: 0, background: "linear-gradient(135deg, #facc15, #f97316)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                🏆 Global Leaderboard
              </h1>
              <div style={{ fontSize: 10, color: "#3d3d6a", marginTop: 4, letterSpacing: 1 }}>Top scores across all RockForge game modes</div>
            </div>
            <button onClick={() => setShowSubmit(true)} style={{
              padding: "12px 20px", borderRadius: 10, border: "none",
              background: "linear-gradient(135deg, #f97316, #facc15)",
              color: "#000", fontSize: 12, fontWeight: 900, cursor: "pointer",
              fontFamily: "monospace", letterSpacing: 1,
            }}>+ Submit Score</button>
          </div>

          {/* Stats strip */}
          <div style={{ display: "flex", gap: 0, overflowX: "auto" }}>
            {[
              { label: "PLAYERS", value: stats.total },
              { label: "TOP SCORE", value: stats.topScore },
              { label: "TOP STREAK", value: `×${stats.topStreak}` },
              { label: "MODES", value: stats.modes },
            ].map((s, i) => (
              <div key={i} style={{ flex: 1, minWidth: 80, padding: "12px 16px", textAlign: "center", borderBottom: "2px solid transparent" }}>
                <div style={{ fontSize: 18, fontWeight: 900, color: "#fff" }}>{s.value}</div>
                <div style={{ fontSize: 8, color: "#3d3d6a", letterSpacing: 2, marginTop: 2 }}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Tabs */}
          <div style={{ display: "flex", gap: 0, marginTop: 4 }}>
            {["global", "personal"].map(t => (
              <div key={t} onClick={() => setTab(t)} style={{
                padding: "10px 20px", cursor: "pointer", fontSize: 10, letterSpacing: 2,
                borderBottom: tab === t ? "2px solid #facc15" : "2px solid transparent",
                color: tab === t ? "#facc15" : "#3d3d6a", fontWeight: tab === t ? 800 : 400,
                transition: "all 0.2s",
              }}>{t.toUpperCase()}</div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 700, margin: "0 auto", padding: "20px" }}>

        {/* Submitted flash */}
        {submitted && (
          <div style={{ marginBottom: 16, padding: "12px 16px", borderRadius: 10, background: "#10b98122", border: "1px solid #10b98166", color: "#10b981", fontSize: 12, animation: "fadeUp 0.3s ease", display: "flex", alignItems: "center", gap: 8 }}>
            🎉 Score submitted! You're on the leaderboard, <strong>{personalBest?.name}</strong>!
          </div>
        )}

        {tab === "global" && (
          <>
            {/* Filters */}
            <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {["All", ...MODES_LIST].map(m => (
                  <div key={m} onClick={() => setFilterMode(m)} style={{
                    padding: "5px 12px", borderRadius: 20, cursor: "pointer", fontSize: 10,
                    background: filterMode === m ? "#facc15" : "#0d0d1a",
                    color: filterMode === m ? "#000" : "#555",
                    border: `1px solid ${filterMode === m ? "#facc15" : "#1e1e3a"}`,
                    fontWeight: filterMode === m ? 700 : 400, transition: "all 0.2s",
                  }}>{m}</div>
                ))}
              </div>
              <select value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ background: "#0d0d1a", border: "1px solid #1e1e3a", borderRadius: 8, padding: "5px 10px", color: "#888", fontSize: 10, fontFamily: "monospace", cursor: "pointer" }}>
                <option value="score">Sort: Score</option>
                <option value="streak">Sort: Streak</option>
                <option value="recent">Sort: Recent</option>
              </select>
            </div>

            {/* Top 3 podium */}
            {filtered.length >= 3 && (
              <div style={{ display: "flex", gap: 8, marginBottom: 20, alignItems: "flex-end", justifyContent: "center" }}>
                {[filtered[1], filtered[0], filtered[2]].map((entry, podiumIdx) => {
                  const actualRank = podiumIdx === 0 ? 1 : podiumIdx === 1 ? 0 : 2;
                  const heights = [100, 130, 90];
                  const r = getRankStyle(actualRank);
                  return (
                    <div key={entry.name} style={{
                      flex: 1, maxWidth: 180, display: "flex", flexDirection: "column", alignItems: "center",
                    }}>
                      <div style={{ fontSize: actualRank === 0 ? 28 : 20, animation: actualRank === 0 ? "crownBounce 1.5s ease-in-out infinite" : "none", marginBottom: 4 }}>{entry.avatar}</div>
                      <div style={{ fontSize: 10, color: "#fff", fontWeight: 700, marginBottom: 4, textAlign: "center" }}>{entry.name}</div>
                      <div style={{ fontSize: 9, color: r.color, marginBottom: 6, fontFamily: "monospace" }}>{entry.score.toLocaleString()}</div>
                      <div style={{
                        width: "100%", height: heights[podiumIdx],
                        background: `linear-gradient(180deg, ${r.color}22, #0d0d1a)`,
                        border: `1px solid ${r.color}44`,
                        borderRadius: "8px 8px 0 0",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: actualRank === 0 ? 28 : 20,
                        boxShadow: actualRank === 0 ? `0 0 24px ${r.glow}` : "none",
                      }}>{r.label}</div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Full table */}
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {filtered.map((entry, idx) => {
                const r = getRankStyle(idx);
                const isFlashing = flash === entry.name;
                return (
                  <div key={`${entry.name}-${idx}`} style={{
                    display: "flex", alignItems: "center", gap: 12, padding: "12px 16px",
                    borderRadius: 12, background: isFlashing ? "#facc1511" : "#07071a",
                    border: `1px solid ${idx < 3 ? r.color + "33" : "#0f0f2a"}`,
                    boxShadow: idx < 3 ? `0 0 16px ${r.glow}` : "none",
                    animation: animReady ? `fadeUp 0.3s ${Math.min(idx * 0.04, 0.4)}s ease both` : "none",
                    transition: "background 0.5s",
                  }}>
                    {/* Rank */}
                    <div style={{ width: 32, textAlign: "center", fontSize: idx < 3 ? 18 : 12, color: r.color, fontWeight: 900, flexShrink: 0 }}>{r.label}</div>

                    {/* Avatar */}
                    <div style={{ fontSize: 22, flexShrink: 0 }}>{entry.avatar}</div>

                    {/* Info */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span style={{ fontSize: 13, fontWeight: 700, color: "#fff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{entry.name}</span>
                        {entry.isNew && <span style={{ fontSize: 8, background: "#10b981", color: "#000", padding: "1px 5px", borderRadius: 6, fontWeight: 900 }}>NEW</span>}
                      </div>
                      <div style={{ fontSize: 9, color: "#3d3d6a", marginTop: 2 }}>{entry.mode} · {entry.date}</div>
                      <ScoreBar score={entry.score} max={topScore} />
                    </div>

                    {/* Score */}
                    <div style={{ textAlign: "right", flexShrink: 0 }}>
                      <div style={{ fontSize: 15, fontWeight: 900, color: r.color, fontFamily: "monospace" }}>{entry.score.toLocaleString()}</div>
                      <div style={{ fontSize: 9, color: "#3d3d6a" }}>×{entry.streak} streak</div>
                    </div>
                  </div>
                );
              })}
              {filtered.length === 0 && (
                <div style={{ textAlign: "center", padding: "40px 0", color: "#3d3d6a", fontSize: 12 }}>No scores for this mode yet. Be the first!</div>
              )}
            </div>
          </>
        )}

        {tab === "personal" && (
          <div style={{ textAlign: "center", padding: "40px 20px" }}>
            {personalBest ? (
              <div style={{ background: "#07071a", border: "1px solid #facc1544", borderRadius: 16, padding: 32 }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>🏆</div>
                <div style={{ fontSize: 14, color: "#facc15", fontWeight: 900, marginBottom: 4 }}>Your Personal Best</div>
                <div style={{ fontSize: 32, fontWeight: 900, color: "#fff", fontFamily: "monospace" }}>{personalBest.score.toLocaleString()}</div>
                <div style={{ fontSize: 11, color: "#555", marginTop: 6 }}>{personalBest.mode} · Streak ×{personalBest.streak}</div>
                <button onClick={() => setShowSubmit(true)} style={{ marginTop: 20, padding: "10px 24px", borderRadius: 10, border: "none", background: "linear-gradient(135deg, #f97316, #facc15)", color: "#000", fontWeight: 900, cursor: "pointer", fontFamily: "monospace", fontSize: 12 }}>Beat It!</button>
              </div>
            ) : (
              <div>
                <div style={{ fontSize: 40, marginBottom: 16 }}>🎮</div>
                <div style={{ color: "#555", fontSize: 13, marginBottom: 20 }}>No personal score yet. Play a game and submit your score!</div>
                <button onClick={() => setShowSubmit(true)} style={{ padding: "12px 28px", borderRadius: 10, border: "none", background: "linear-gradient(135deg, #6366f1, #a855f7)", color: "#fff", fontWeight: 900, cursor: "pointer", fontFamily: "monospace", fontSize: 13 }}>+ Submit My Score</button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Submit Score Modal */}
      {showSubmit && (
        <div style={{ position: "fixed", inset: 0, background: "#000000cc", zIndex: 999, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div style={{ background: "#0d0d1a", border: "1px solid #facc1544", borderRadius: 20, padding: 32, maxWidth: 380, width: "100%", boxShadow: "0 0 60px #facc1522" }}>
            <div style={{ fontSize: 28, marginBottom: 8, textAlign: "center" }}>🏆</div>
            <div style={{ fontSize: 18, fontWeight: 900, color: "#facc15", textAlign: "center", marginBottom: 4 }}>Submit Your Score</div>
            <div style={{ fontSize: 11, color: "#555", textAlign: "center", marginBottom: 24 }}>Enter your details to appear on the global leaderboard</div>

            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {[
                { label: "PLAYER NAME", key: "name", type: "text", placeholder: "e.g. NeonRider" },
                { label: "SCORE", key: "score", type: "number", placeholder: "e.g. 45200" },
                { label: "BEST STREAK", key: "streak", type: "number", placeholder: "e.g. 32" },
              ].map(field => (
                <div key={field.key}>
                  <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 2, marginBottom: 5 }}>{field.label}</div>
                  <input type={field.type} value={form[field.key]} onChange={e => setForm(f => ({ ...f, [field.key]: e.target.value }))}
                    placeholder={field.placeholder} style={{
                      width: "100%", background: "#07071a", border: "1px solid #1e1e3a",
                      borderRadius: 8, padding: "10px 12px", color: "#fff",
                      fontFamily: "monospace", fontSize: 13,
                    }} />
                </div>
              ))}
              <div>
                <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 2, marginBottom: 5 }}>GAME MODE</div>
                <select value={form.mode} onChange={e => setForm(f => ({ ...f, mode: e.target.value }))} style={{ width: "100%", background: "#07071a", border: "1px solid #1e1e3a", borderRadius: 8, padding: "10px 12px", color: "#fff", fontFamily: "monospace", fontSize: 13 }}>
                  {MODES_LIST.map(m => <option key={m}>{m}</option>)}
                </select>
              </div>
            </div>

            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              <button onClick={() => setShowSubmit(false)} style={{ flex: 1, padding: "12px 0", borderRadius: 10, border: "1px solid #1e1e3a", background: "transparent", color: "#555", cursor: "pointer", fontFamily: "monospace" }}>Cancel</button>
              <button onClick={handleSubmit} style={{ flex: 2, padding: "12px 0", borderRadius: 10, border: "none", background: "linear-gradient(135deg, #facc15, #f97316)", color: "#000", fontWeight: 900, cursor: "pointer", fontFamily: "monospace", fontSize: 13, letterSpacing: 1 }}>
                🏆 Submit Score
              </button>
            </div>
            <div style={{ fontSize: 9, color: "#222", textAlign: "center", marginTop: 12 }}>HumanLayerAI LLC · RockForge™</div>
          </div>
        </div>
      )}
    </div>
  );
}
