
import { useState, useEffect, useRef, useCallback } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────
const MODES = { HOME: "home", GUITAR: "guitar", DRUMS: "drums", PIANO: "piano", KARAOKE: "karaoke", STUDIO: "studio", PRICING: "pricing" };

const GUITAR_KEYS = [
  { key: "a", label: "A", color: "#22c55e", glow: "#4ade80" },
  { key: "s", label: "S", color: "#ef4444", glow: "#f87171" },
  { key: "d", label: "D", color: "#facc15", glow: "#fde047" },
  { key: "f", label: "F", color: "#3b82f6", glow: "#60a5fa" },
  { key: "j", label: "J", color: "#f97316", glow: "#fb923c" },
];

const DRUM_PADS = [
  { key: "q", label: "HH", name: "Hi-Hat", color: "#a855f7", freq: 800, type: "noise", dur: 0.05 },
  { key: "w", label: "SN", name: "Snare", color: "#ec4899", freq: 200, type: "noise", dur: 0.15 },
  { key: "e", label: "KK", name: "Kick", color: "#ef4444", freq: 60, type: "sine", dur: 0.3 },
  { key: "r", label: "T1", name: "Tom 1", color: "#f97316", freq: 180, type: "triangle", dur: 0.2 },
  { key: "u", label: "T2", name: "Tom 2", color: "#eab308", freq: 120, type: "triangle", dur: 0.25 },
  { key: "i", label: "CR", name: "Crash", color: "#22c55e", freq: 600, type: "noise", dur: 0.4 },
  { key: "o", label: "RD", name: "Ride", color: "#06b6d4", freq: 700, type: "noise", dur: 0.3 },
  { key: "p", label: "CW", name: "Cowbell", color: "#f59e0b", freq: 562, type: "square", dur: 0.15 },
];

const PIANO_KEYS_DEF = [
  { note: "C4", freq: 261.63, key: "a", black: false },
  { note: "C#4", freq: 277.18, key: "w", black: true },
  { note: "D4", freq: 293.66, key: "s", black: false },
  { note: "D#4", freq: 311.13, key: "e", black: true },
  { note: "E4", freq: 329.63, key: "d", black: false },
  { note: "F4", freq: 349.23, key: "f", black: false },
  { note: "F#4", freq: 369.99, key: "t", black: true },
  { note: "G4", freq: 392.00, key: "g", black: false },
  { note: "G#4", freq: 415.30, key: "y", black: true },
  { note: "A4", freq: 440.00, key: "h", black: false },
  { note: "A#4", freq: 466.16, key: "u", black: true },
  { note: "B4", freq: 493.88, key: "j", black: false },
  { note: "C5", freq: 523.25, key: "k", black: false },
];

const SAMPLE_SONGS = [
  { title: "Neon Cascade", artist: "RockForge AI", bpm: 120, notes: [0,2,1,3,4,2,0,1,3,2,4,1,0,3,2,4], lyrics: ["🎸 Feel the neon light", "Burning through the night", "Every chord alive", "Watch the music thrive"] },
  { title: "Thunder Road", artist: "RockForge AI", bpm: 140, notes: [3,3,1,1,2,4,0,0,2,3,1,4,2,0,3,1], lyrics: ["⚡ Thunder down the road", "Heavy load to hold", "Music breaks the chain", "Feel the sweet refrain"] },
  { title: "Solar Storm", artist: "RockForge AI", bpm: 100, notes: [0,1,2,1,0,3,4,3,2,1,4,0,3,2,1,0], lyrics: ["🌟 Solar storm arise", "Blazing through the skies", "Notes become the sun", "Play until you're done"] },
];

const CHORD_LIBRARY = [
  { name: "C Major", notes: [261.63, 329.63, 392.00], symbol: "C" },
  { name: "G Major", notes: [392.00, 493.88, 587.33], symbol: "G" },
  { name: "A Minor", notes: [440.00, 523.25, 659.25], symbol: "Am" },
  { name: "F Major", notes: [349.23, 440.00, 523.25], symbol: "F" },
  { name: "D Major", notes: [293.66, 369.99, 440.00], symbol: "D" },
  { name: "E Minor", notes: [329.63, 392.00, 493.88], symbol: "Em" },
];

// ─── Audio Engine ─────────────────────────────────────────────────────────────
function useAudioEngine() {
  const ctxRef = useRef(null);
  const getCtx = () => {
    if (!ctxRef.current) ctxRef.current = new (window.AudioContext || window.webkitAudioContext)();
    if (ctxRef.current.state === "suspended") ctxRef.current.resume();
    return ctxRef.current;
  };

  const playTone = useCallback((freq, type = "sawtooth", duration = 0.5, gain = 0.3) => {
    const ctx = getCtx();
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass"; filter.frequency.value = 3000;
    osc.connect(filter); filter.connect(gainNode); gainNode.connect(ctx.destination);
    osc.type = type; osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gainNode.gain.setValueAtTime(gain, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.start(); osc.stop(ctx.currentTime + duration);
  }, []);

  const playDrum = useCallback((pad) => {
    const ctx = getCtx();
    if (pad.type === "noise") {
      const bufSize = ctx.sampleRate * pad.dur;
      const buf = ctx.createBuffer(1, bufSize, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < bufSize; i++) data[i] = Math.random() * 2 - 1;
      const src = ctx.createBufferSource();
      const gainNode = ctx.createGain();
      const filter = ctx.createBiquadFilter();
      filter.type = "bandpass"; filter.frequency.value = pad.freq; filter.Q.value = 0.5;
      src.buffer = buf; src.connect(filter); filter.connect(gainNode); gainNode.connect(ctx.destination);
      gainNode.gain.setValueAtTime(0.4, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + pad.dur);
      src.start();
    } else {
      playTone(pad.freq, pad.type, pad.dur, 0.4);
    }
  }, [playTone]);

  const playChord = useCallback((notes) => {
    notes.forEach(freq => playTone(freq, "triangle", 0.8, 0.15));
  }, [playTone]);

  return { playTone, playDrum, playChord };
}

// ─── Guitar Hero Component ────────────────────────────────────────────────────
function GuitarMode({ audio }) {
  const [song] = useState(SAMPLE_SONGS[0]);
  const [notes, setNotes] = useState([]);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [activeKeys, setActiveKeys] = useState({});
  const [playing, setPlaying] = useState(false);
  const [hits, setHits] = useState([]);
  const intervalRef = useRef(null);
  const noteIdRef = useRef(0);
  const pendingNotes = useRef([]);

  const spawnNote = useCallback(() => {
    const lane = song.notes[noteIdRef.current % song.notes.length];
    const id = noteIdRef.current++;
    const note = { id, lane, y: 0, spawned: Date.now() };
    setNotes(prev => [...prev, note]);
    pendingNotes.current.push(note);
  }, [song]);

  useEffect(() => {
    if (!playing) return;
    intervalRef.current = setInterval(spawnNote, (60000 / song.bpm) / 2);
    const moveInterval = setInterval(() => {
      setNotes(prev => prev.map(n => ({ ...n, y: n.y + 2 })).filter(n => {
        if (n.y > 110) {
          pendingNotes.current = pendingNotes.current.filter(p => p.id !== n.id);
          setStreak(0);
          return false;
        }
        return true;
      }));
    }, 16);
    return () => { clearInterval(intervalRef.current); clearInterval(moveInterval); };
  }, [playing, spawnNote, song.bpm]);

  useEffect(() => {
    const handler = (e) => {
      const laneIdx = GUITAR_KEYS.findIndex(k => k.key === e.key.toLowerCase());
      if (laneIdx === -1) return;
      setActiveKeys(prev => ({ ...prev, [laneIdx]: true }));
      // Check hit
      const hit = pendingNotes.current.find(n => n.lane === laneIdx && notes.find(nn => nn.id === n.id && nn.y > 75 && nn.y < 100));
      if (hit) {
        audio.playTone(GUITAR_KEYS[laneIdx].freq || 440, "sawtooth", 0.4);
        setScore(s => s + (10 * Math.max(1, Math.floor(streak / 5))));
        setStreak(s => s + 1);
        setHits(prev => [...prev, { id: Date.now(), lane: laneIdx, x: laneIdx * 20 + 10 }]);
        setTimeout(() => setHits(prev => prev.slice(1)), 500);
        setNotes(prev => prev.filter(n => n.id !== hit.id));
        pendingNotes.current = pendingNotes.current.filter(p => p.id !== hit.id);
      } else {
        setStreak(0);
      }
      setTimeout(() => setActiveKeys(prev => ({ ...prev, [laneIdx]: false })), 150);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [notes, streak, audio]);

  const freqs = [330, 392, 440, 523, 587];

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
      <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 13, color: "#888", fontFamily: "monospace" }}>SCORE</div>
          <div style={{ fontSize: 32, fontWeight: 900, color: "#facc15", fontFamily: "monospace" }}>{score.toString().padStart(6,"0")}</div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 13, color: "#888", fontFamily: "monospace" }}>STREAK</div>
          <div style={{ fontSize: 32, fontWeight: 900, color: streak > 10 ? "#f97316" : "#fff", fontFamily: "monospace" }}>×{streak}</div>
        </div>
        <button onClick={() => setPlaying(p => !p)} style={{ padding: "12px 28px", borderRadius: 8, border: "none", background: playing ? "#ef4444" : "#22c55e", color: "#fff", fontWeight: 800, fontSize: 16, cursor: "pointer", fontFamily: "monospace", letterSpacing: 2 }}>
          {playing ? "⏹ STOP" : "▶ PLAY"}
        </button>
      </div>

      {/* Highway */}
      <div style={{ position: "relative", width: 380, height: 420, background: "linear-gradient(180deg, #0a0a1a 0%, #111133 60%, #1a1a44 100%)", borderRadius: 12, overflow: "hidden", border: "2px solid #333" }}>
        {/* Lane lines */}
        {[1,2,3,4].map(i => (
          <div key={i} style={{ position: "absolute", left: `${i * 20}%`, top: 0, bottom: 0, width: 1, background: "rgba(255,255,255,0.07)" }} />
        ))}
        {/* Perspective lines */}
        {[...Array(15)].map((_, i) => (
          <div key={i} style={{ position: "absolute", left: 0, right: 0, top: `${i * 7}%`, height: 1, background: `rgba(100,100,255,${0.03 + i*0.005})` }} />
        ))}

        {/* Notes */}
        {notes.map(note => (
          <div key={note.id} style={{
            position: "absolute", left: `${note.lane * 20 + 2}%`, top: `${note.y}%`,
            width: "16%", height: 28, borderRadius: 6,
            background: GUITAR_KEYS[note.lane].color,
            boxShadow: `0 0 12px ${GUITAR_KEYS[note.lane].glow}`,
            transform: "perspective(400px) rotateX(20deg)",
            transition: "none",
          }} />
        ))}

        {/* Hit effects */}
        {hits.map(hit => (
          <div key={hit.id} style={{
            position: "absolute", left: `${hit.lane * 20}%`, top: "79%",
            width: "20%", height: 40,
            background: `radial-gradient(circle, ${GUITAR_KEYS[hit.lane].glow}88 0%, transparent 70%)`,
            animation: "hitFlash 0.5s ease-out forwards",
            pointerEvents: "none",
          }} />
        ))}

        {/* Hit zone */}
        <div style={{ position: "absolute", left: 0, right: 0, bottom: "18%", height: 3, background: "rgba(255,255,255,0.3)", boxShadow: "0 0 8px rgba(255,255,255,0.5)" }} />

        {/* Fret buttons */}
        <div style={{ position: "absolute", bottom: "10%", left: 0, right: 0, display: "flex", justifyContent: "space-around", padding: "0 8px" }}>
          {GUITAR_KEYS.map((k, i) => (
            <div key={k.key} onClick={() => {
              audio.playTone(freqs[i], "sawtooth", 0.4);
              setActiveKeys(prev => ({ ...prev, [i]: true }));
              setTimeout(() => setActiveKeys(prev => ({ ...prev, [i]: false })), 150);
            }} style={{
              width: 56, height: 56, borderRadius: "50%",
              background: activeKeys[i] ? k.glow : k.color,
              boxShadow: activeKeys[i] ? `0 0 24px ${k.glow}, 0 0 48px ${k.glow}44` : `0 0 8px ${k.color}88`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 12, fontWeight: 900, color: "#000", cursor: "pointer",
              transform: activeKeys[i] ? "scale(1.15)" : "scale(1)",
              transition: "all 0.1s", userSelect: "none",
              border: `3px solid ${activeKeys[i] ? "#fff" : k.glow}`,
            }}>{k.label}</div>
          ))}
        </div>
      </div>
      <div style={{ color: "#666", fontSize: 12, fontFamily: "monospace" }}>Press A S D F J keys or tap buttons • Hit notes in the zone</div>
    </div>
  );
}

// ─── Drum Machine ─────────────────────────────────────────────────────────────
function DrumMode({ audio }) {
  const [activePads, setActivePads] = useState({});
  const [recording, setRecording] = useState(false);
  const [pattern, setPattern] = useState(Array(8).fill(null).map(() => Array(8).fill(false)));
  const [bpmStep, setBpmStep] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [bpm, setBpm] = useState(120);
  const intervalRef = useRef(null);

  const hitPad = useCallback((pad, idx) => {
    audio.playDrum(pad);
    setActivePads(prev => ({ ...prev, [idx]: true }));
    setTimeout(() => setActivePads(prev => ({ ...prev, [idx]: false })), 120);
    if (recording) {
      setPattern(prev => {
        const p = prev.map(r => [...r]);
        p[idx][bpmStep] = !p[idx][bpmStep];
        return p;
      });
    }
  }, [audio, recording, bpmStep]);

  useEffect(() => {
    const handler = (e) => {
      const idx = DRUM_PADS.findIndex(p => p.key === e.key.toLowerCase());
      if (idx !== -1) hitPad(DRUM_PADS[idx], idx);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [hitPad]);

  useEffect(() => {
    if (!playing) { clearInterval(intervalRef.current); return; }
    intervalRef.current = setInterval(() => {
      setBpmStep(s => {
        const next = (s + 1) % 8;
        pattern.forEach((row, i) => { if (row[next]) { audio.playDrum(DRUM_PADS[i]); } });
        return next;
      });
    }, (60000 / bpm) / 2);
    return () => clearInterval(intervalRef.current);
  }, [playing, bpm, pattern, audio]);

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20 }}>
      {/* Pads */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10 }}>
        {DRUM_PADS.map((pad, idx) => (
          <div key={pad.key} onClick={() => hitPad(pad, idx)} style={{
            width: 90, height: 90, borderRadius: 12,
            background: activePads[idx] ? pad.color : `${pad.color}33`,
            border: `2px solid ${pad.color}`,
            boxShadow: activePads[idx] ? `0 0 30px ${pad.color}, inset 0 0 20px ${pad.color}44` : `0 0 6px ${pad.color}44`,
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            cursor: "pointer", userSelect: "none",
            transform: activePads[idx] ? "scale(0.93)" : "scale(1)",
            transition: "all 0.08s",
          }}>
            <div style={{ fontSize: 22, fontWeight: 900, color: activePads[idx] ? "#000" : pad.color, fontFamily: "monospace" }}>{pad.label}</div>
            <div style={{ fontSize: 9, color: activePads[idx] ? "#000" : "#888", fontFamily: "monospace" }}>[{pad.key.toUpperCase()}]</div>
            <div style={{ fontSize: 9, color: activePads[idx] ? "#000" : "#666", marginTop: 2 }}>{pad.name}</div>
          </div>
        ))}
      </div>

      {/* Sequencer */}
      <div style={{ background: "#111", borderRadius: 12, padding: 16, width: "100%", maxWidth: 560 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <span style={{ color: "#888", fontFamily: "monospace", fontSize: 12 }}>SEQUENCER</span>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <span style={{ color: "#666", fontSize: 11, fontFamily: "monospace" }}>BPM</span>
            <input type="range" min={60} max={200} value={bpm} onChange={e => setBpm(+e.target.value)} style={{ width: 80 }} />
            <span style={{ color: "#facc15", fontFamily: "monospace", fontSize: 12 }}>{bpm}</span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          <button onClick={() => setPlaying(p => !p)} style={{ flex: 1, padding: "8px 0", borderRadius: 6, border: "none", background: playing ? "#ef4444" : "#22c55e", color: "#fff", fontWeight: 800, cursor: "pointer", fontFamily: "monospace" }}>
            {playing ? "⏹ STOP" : "▶ PLAY"}
          </button>
          <button onClick={() => setRecording(r => !r)} style={{ flex: 1, padding: "8px 0", borderRadius: 6, border: "none", background: recording ? "#ec4899" : "#333", color: "#fff", fontWeight: 800, cursor: "pointer", fontFamily: "monospace" }}>
            {recording ? "⏺ REC ON" : "⏺ RECORD"}
          </button>
          <button onClick={() => setPattern(Array(8).fill(null).map(() => Array(8).fill(false)))} style={{ flex: 1, padding: "8px 0", borderRadius: 6, border: "none", background: "#333", color: "#fff", fontWeight: 800, cursor: "pointer", fontFamily: "monospace" }}>
            🗑 CLEAR
          </button>
        </div>
        {pattern.map((row, padIdx) => (
          <div key={padIdx} style={{ display: "flex", gap: 4, marginBottom: 4, alignItems: "center" }}>
            <div style={{ width: 28, fontSize: 9, color: DRUM_PADS[padIdx].color, fontFamily: "monospace", textAlign: "right" }}>{DRUM_PADS[padIdx].label}</div>
            {row.map((active, stepIdx) => (
              <div key={stepIdx} onClick={() => setPattern(prev => { const p = prev.map(r => [...r]); p[padIdx][stepIdx] = !p[padIdx][stepIdx]; return p; })} style={{
                flex: 1, height: 22, borderRadius: 4,
                background: bpmStep === stepIdx && playing ? (active ? DRUM_PADS[padIdx].color : "#334") : active ? DRUM_PADS[padIdx].color : "#1e1e2e",
                border: `1px solid ${active ? DRUM_PADS[padIdx].color : "#333"}`,
                cursor: "pointer",
                boxShadow: bpmStep === stepIdx && playing ? `0 0 8px ${DRUM_PADS[padIdx].color}` : "none",
                transition: "background 0.05s",
              }} />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Piano Mode ───────────────────────────────────────────────────────────────
function PianoMode({ audio }) {
  const [activeKeys, setActiveKeys] = useState({});
  const [chord, setChord] = useState(null);
  const [history, setHistory] = useState([]);

  const playNote = useCallback((pk) => {
    audio.playTone(pk.freq, "triangle", 0.8, 0.2);
    setActiveKeys(prev => ({ ...prev, [pk.note]: true }));
    setHistory(prev => [pk.note, ...prev].slice(0, 8));
    setTimeout(() => setActiveKeys(prev => ({ ...prev, [pk.note]: false })), 400);
  }, [audio]);

  useEffect(() => {
    const handler = (e) => {
      const pk = PIANO_KEYS_DEF.find(k => k.key === e.key.toLowerCase());
      if (pk) playNote(pk);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [playNote]);

  const whites = PIANO_KEYS_DEF.filter(k => !k.black);
  const ww = 52;

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20 }}>
      {/* Piano keyboard */}
      <div style={{ position: "relative", height: 160, background: "#111", borderRadius: 12, padding: 12, boxShadow: "0 8px 32px #000" }}>
        <div style={{ position: "relative", display: "flex" }}>
          {/* White keys */}
          {whites.map((pk, i) => (
            <div key={pk.note} onClick={() => playNote(pk)} style={{
              width: ww, height: 130, background: activeKeys[pk.note] ? "#dbeafe" : "#f8fafc",
              border: "1px solid #ccc", borderRadius: "0 0 6px 6px", cursor: "pointer",
              display: "flex", flexDirection: "column", justifyContent: "flex-end", alignItems: "center", paddingBottom: 6,
              boxShadow: activeKeys[pk.note] ? "inset 0 -4px 8px #3b82f6, 0 0 16px #3b82f688" : "inset 0 -4px 8px rgba(0,0,0,0.2)",
              transition: "all 0.1s", userSelect: "none",
            }}>
              <div style={{ fontSize: 9, color: "#999", fontFamily: "monospace" }}>{pk.key.toUpperCase()}</div>
            </div>
          ))}
          {/* Black keys */}
          {PIANO_KEYS_DEF.filter(k => k.black).map(pk => {
            const whiteIdx = whites.findIndex((w, i) => PIANO_KEYS_DEF.indexOf(w) === PIANO_KEYS_DEF.indexOf(pk) - 1);
            const left = (whiteIdx + 1) * ww - 18;
            return (
              <div key={pk.note} onClick={() => playNote(pk)} style={{
                position: "absolute", left, top: 0, width: 36, height: 85,
                background: activeKeys[pk.note] ? "#1d4ed8" : "#1a1a2e",
                borderRadius: "0 0 5px 5px", cursor: "pointer", zIndex: 2,
                boxShadow: activeKeys[pk.note] ? "0 0 20px #60a5fa" : "0 4px 8px #000",
                display: "flex", flexDirection: "column", justifyContent: "flex-end", alignItems: "center", paddingBottom: 4,
                transition: "all 0.1s", userSelect: "none",
              }}>
                <div style={{ fontSize: 8, color: activeKeys[pk.note] ? "#fff" : "#555", fontFamily: "monospace" }}>{pk.key.toUpperCase()}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Note history */}
      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
        {history.map((n, i) => (
          <div key={i} style={{ padding: "4px 10px", borderRadius: 20, background: `hsl(${i*40}, 70%, 50%)22`, border: `1px solid hsl(${i*40}, 70%, 50%)`, color: `hsl(${i*40}, 80%, 70%)`, fontSize: 11, fontFamily: "monospace", opacity: 1 - i * 0.1 }}>{n}</div>
        ))}
      </div>

      {/* Chord library */}
      <div style={{ background: "#111", borderRadius: 12, padding: 16, width: "100%", maxWidth: 500 }}>
        <div style={{ color: "#888", fontFamily: "monospace", fontSize: 12, marginBottom: 10 }}>CHORD LIBRARY</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
          {CHORD_LIBRARY.map((c, i) => (
            <div key={i} onClick={() => { audio.playChord(c.notes); setChord(c.name); setTimeout(() => setChord(null), 1500); }} style={{
              padding: "12px 8px", borderRadius: 8, textAlign: "center", cursor: "pointer",
              background: chord === c.name ? "#1d4ed8" : "#1e1e2e",
              border: `1px solid ${chord === c.name ? "#3b82f6" : "#333"}`,
              boxShadow: chord === c.name ? "0 0 20px #3b82f688" : "none",
              transition: "all 0.2s",
            }}>
              <div style={{ fontSize: 20, fontWeight: 900, color: chord === c.name ? "#fff" : "#60a5fa", fontFamily: "monospace" }}>{c.symbol}</div>
              <div style={{ fontSize: 9, color: "#666" }}>{c.name}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Karaoke Mode ─────────────────────────────────────────────────────────────
function KaraokeMode({ audio }) {
  const [songIdx, setSongIdx] = useState(0);
  const [lineIdx, setLineIdx] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [listening, setListening] = useState(false);
  const [volume, setVolume] = useState(0);
  const [score, setScore] = useState(0);
  const analyserRef = useRef(null);
  const micStreamRef = useRef(null);
  const animFrameRef = useRef(null);
  const intervalRef = useRef(null);

  const song = SAMPLE_SONGS[songIdx];

  const startMic = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;
      const ctx = new AudioContext();
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser(); analyser.fftSize = 256;
      src.connect(analyser);
      analyserRef.current = analyser;
      setListening(true);
      const tick = () => {
        const data = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(data);
        const avg = data.reduce((a, b) => a + b) / data.length;
        setVolume(avg);
        if (avg > 20) setScore(s => s + 1);
        animFrameRef.current = requestAnimationFrame(tick);
      };
      tick();
    } catch { setListening(false); }
  };

  const stopMic = () => {
    micStreamRef.current?.getTracks().forEach(t => t.stop());
    cancelAnimationFrame(animFrameRef.current);
    setListening(false); setVolume(0);
  };

  useEffect(() => {
    if (!playing) { clearInterval(intervalRef.current); setLineIdx(0); return; }
    intervalRef.current = setInterval(() => {
      setLineIdx(i => {
        if (i >= song.lyrics.length - 1) { setPlaying(false); return 0; }
        audio.playTone([261.63,329.63,392,440,523][Math.floor(Math.random()*5)], "sine", 0.5, 0.1);
        return i + 1;
      });
    }, 2500);
    return () => clearInterval(intervalRef.current);
  }, [playing, song, audio]);

  useEffect(() => () => { stopMic(); clearInterval(intervalRef.current); }, []);

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20 }}>
      {/* Song selector */}
      <div style={{ display: "flex", gap: 8 }}>
        {SAMPLE_SONGS.map((s, i) => (
          <div key={i} onClick={() => { setSongIdx(i); setPlaying(false); setLineIdx(0); }} style={{
            padding: "8px 16px", borderRadius: 20, cursor: "pointer",
            background: songIdx === i ? "#a855f7" : "#1e1e2e",
            border: `1px solid ${songIdx === i ? "#a855f7" : "#333"}`,
            color: songIdx === i ? "#fff" : "#888", fontSize: 12, fontFamily: "monospace",
          }}>{s.title}</div>
        ))}
      </div>

      {/* Main display */}
      <div style={{ width: "100%", maxWidth: 560, background: "linear-gradient(135deg, #0d0d1a, #1a0d2e)", borderRadius: 16, padding: 32, textAlign: "center", border: "1px solid #2d1b69", boxShadow: "0 0 40px #a855f722" }}>
        <div style={{ fontSize: 13, color: "#a855f7", fontFamily: "monospace", marginBottom: 4 }}>{song.artist}</div>
        <div style={{ fontSize: 22, fontWeight: 900, color: "#fff", marginBottom: 24, fontFamily: "'Trebuchet MS', sans-serif" }}>{song.title}</div>

        {/* Lyrics display */}
        <div style={{ minHeight: 80, display: "flex", alignItems: "center", justifyContent: "center" }}>
          {playing ? (
            <div style={{ fontSize: 28, fontWeight: 700, color: "#f0abfc", textShadow: "0 0 20px #a855f7", animation: "pulse 0.5s ease-in-out infinite alternate", fontFamily: "'Trebuchet MS', sans-serif", textAlign: "center", lineHeight: 1.4 }}>
              {song.lyrics[lineIdx]}
            </div>
          ) : (
            <div style={{ color: "#555", fontSize: 16 }}>Press PLAY to start singing!</div>
          )}
        </div>

        {/* Mic visualizer */}
        {listening && (
          <div style={{ margin: "16px 0", display: "flex", alignItems: "flex-end", justifyContent: "center", gap: 3, height: 40 }}>
            {Array.from({ length: 20 }, (_, i) => (
              <div key={i} style={{
                width: 6, borderRadius: 3,
                height: Math.max(4, (volume / 128) * 40 * (0.5 + Math.random() * 0.5)),
                background: `hsl(${280 + i * 4}, 80%, 60%)`,
                transition: "height 0.05s",
              }} />
            ))}
          </div>
        )}

        {/* Score */}
        <div style={{ fontSize: 24, fontWeight: 900, color: "#facc15", fontFamily: "monospace", marginBottom: 16 }}>
          ⭐ {score} pts
        </div>

        {/* Controls */}
        <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
          <button onClick={() => { setPlaying(p => !p); if (playing) setLineIdx(0); }} style={{ padding: "12px 24px", borderRadius: 8, border: "none", background: playing ? "#ef4444" : "#a855f7", color: "#fff", fontWeight: 800, cursor: "pointer", fontSize: 15, fontFamily: "monospace" }}>
            {playing ? "⏹ STOP" : "▶ SING!"}
          </button>
          <button onClick={() => listening ? stopMic() : startMic()} style={{ padding: "12px 24px", borderRadius: 8, border: "none", background: listening ? "#ec4899" : "#333", color: "#fff", fontWeight: 800, cursor: "pointer", fontSize: 15, fontFamily: "monospace" }}>
            {listening ? "🎤 ON" : "🎤 MIC"}
          </button>
          <button onClick={() => setScore(0)} style={{ padding: "12px 24px", borderRadius: 8, border: "none", background: "#333", color: "#fff", fontWeight: 800, cursor: "pointer", fontSize: 15, fontFamily: "monospace" }}>
            🔄
          </button>
        </div>
      </div>

      {/* Lyrics scroll */}
      <div style={{ display: "flex", flexDirection: "column", gap: 4, width: "100%", maxWidth: 560 }}>
        {song.lyrics.map((line, i) => (
          <div key={i} style={{ padding: "8px 16px", borderRadius: 8, background: lineIdx === i && playing ? "#2d1b6988" : "transparent", color: lineIdx === i && playing ? "#f0abfc" : "#555", fontSize: 14, fontFamily: "monospace", transition: "all 0.3s", borderLeft: lineIdx === i && playing ? "3px solid #a855f7" : "3px solid transparent" }}>{line}</div>
        ))}
      </div>
    </div>
  );
}

// ─── Music Studio ─────────────────────────────────────────────────────────────
function StudioMode({ audio }) {
  const [title, setTitle] = useState("My Track");
  const [artist, setArtist] = useState("Me");
  const [bpm, setBpm] = useState(120);
  const [lyrics, setLyrics] = useState("");
  const [chords, setChords] = useState([]);
  const [selectedChord, setSelectedChord] = useState(null);
  const [genre, setGenre] = useState("Rock");
  const [generating, setGenerating] = useState(false);
  const [aiLyrics, setAiLyrics] = useState("");
  const [saved, setSaved] = useState([]);

  const addChord = (chord) => {
    if (chords.length < 8) { setChords(prev => [...prev, chord]); audio.playChord(chord.notes); }
  };

  const playProgression = async () => {
    for (let i = 0; i < chords.length; i++) {
      await new Promise(r => setTimeout(r, 600));
      audio.playChord(chords[i].notes);
    }
  };

  const generateLyrics = async () => {
    setGenerating(true);
    const prompt = `Write 4 lines of ${genre} song lyrics for a song called "${title}" with chords ${chords.map(c => c.symbol).join(" - ") || "C G Am F"} at ${bpm} BPM. Keep it fun and energetic. Return only the 4 lines, one per line.`;
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000, messages: [{ role: "user", content: prompt }] })
      });
      const data = await res.json();
      setAiLyrics(data.content?.[0]?.text || "✨ Something beautiful\nComes alive tonight\nEvery chord we play\nMakes everything right");
    } catch {
      setAiLyrics("✨ Something beautiful\nComes alive tonight\nEvery chord we play\nMakes everything right");
    }
    setGenerating(false);
  };

  const saveTrack = () => {
    const track = { title, artist, bpm, genre, chords: chords.map(c => c.symbol), lyrics: aiLyrics || lyrics };
    setSaved(prev => [track, ...prev].slice(0, 5));
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16, maxWidth: 600 }}>
      {/* Track info */}
      <div style={{ background: "#111", borderRadius: 12, padding: 16 }}>
        <div style={{ color: "#888", fontFamily: "monospace", fontSize: 11, marginBottom: 10 }}>🎵 TRACK INFO</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <div>
            <div style={{ fontSize: 10, color: "#666", marginBottom: 4, fontFamily: "monospace" }}>TITLE</div>
            <input value={title} onChange={e => setTitle(e.target.value)} style={{ width: "100%", background: "#1e1e2e", border: "1px solid #333", borderRadius: 6, padding: "8px 10px", color: "#fff", fontFamily: "monospace", fontSize: 13, boxSizing: "border-box" }} />
          </div>
          <div>
            <div style={{ fontSize: 10, color: "#666", marginBottom: 4, fontFamily: "monospace" }}>ARTIST</div>
            <input value={artist} onChange={e => setArtist(e.target.value)} style={{ width: "100%", background: "#1e1e2e", border: "1px solid #333", borderRadius: 6, padding: "8px 10px", color: "#fff", fontFamily: "monospace", fontSize: 13, boxSizing: "border-box" }} />
          </div>
          <div>
            <div style={{ fontSize: 10, color: "#666", marginBottom: 4, fontFamily: "monospace" }}>BPM: {bpm}</div>
            <input type="range" min={60} max={200} value={bpm} onChange={e => setBpm(+e.target.value)} style={{ width: "100%" }} />
          </div>
          <div>
            <div style={{ fontSize: 10, color: "#666", marginBottom: 4, fontFamily: "monospace" }}>GENRE</div>
            <select value={genre} onChange={e => setGenre(e.target.value)} style={{ width: "100%", background: "#1e1e2e", border: "1px solid #333", borderRadius: 6, padding: "8px 10px", color: "#fff", fontFamily: "monospace", fontSize: 13, boxSizing: "border-box" }}>
              {["Rock", "Pop", "Metal", "Jazz", "Blues", "Country", "Hip-Hop", "EDM"].map(g => <option key={g}>{g}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Chord builder */}
      <div style={{ background: "#111", borderRadius: 12, padding: 16 }}>
        <div style={{ color: "#888", fontFamily: "monospace", fontSize: 11, marginBottom: 10 }}>🎸 CHORD PROGRESSION</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 10 }}>
          {CHORD_LIBRARY.map((c, i) => (
            <div key={i} onClick={() => addChord(c)} style={{ padding: "6px 14px", borderRadius: 20, cursor: "pointer", background: "#1e1e2e", border: "1px solid #3b82f6", color: "#60a5fa", fontFamily: "monospace", fontSize: 12, transition: "all 0.15s", userSelect: "none" }}
              onMouseEnter={e => e.target.style.background = "#1d4ed8"}
              onMouseLeave={e => e.target.style.background = "#1e1e2e"}>
              {c.symbol}
            </div>
          ))}
        </div>
        {/* Built progression */}
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", minHeight: 40, background: "#0a0a0f", borderRadius: 8, padding: 8 }}>
          {chords.length === 0 && <span style={{ color: "#444", fontSize: 12, fontFamily: "monospace" }}>Tap chords above to build progression...</span>}
          {chords.map((c, i) => (
            <div key={i} onClick={() => setChords(prev => prev.filter((_, j) => j !== i))} style={{ padding: "6px 12px", borderRadius: 8, background: "#1d4ed8", color: "#fff", fontFamily: "monospace", fontSize: 14, fontWeight: 700, cursor: "pointer" }}>{c.symbol}</div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
          <button onClick={playProgression} disabled={chords.length === 0} style={{ flex: 1, padding: "8px 0", borderRadius: 6, border: "none", background: chords.length ? "#3b82f6" : "#333", color: "#fff", fontWeight: 700, cursor: "pointer", fontFamily: "monospace" }}>▶ Play Progression</button>
          <button onClick={() => setChords([])} style={{ padding: "8px 16px", borderRadius: 6, border: "none", background: "#333", color: "#fff", cursor: "pointer", fontFamily: "monospace" }}>🗑</button>
        </div>
      </div>

      {/* AI Lyrics */}
      <div style={{ background: "#111", borderRadius: 12, padding: 16 }}>
        <div style={{ color: "#888", fontFamily: "monospace", fontSize: 11, marginBottom: 10 }}>✨ LYRICS</div>
        <textarea value={lyrics} onChange={e => setLyrics(e.target.value)} placeholder="Write your own lyrics here..." style={{ width: "100%", height: 80, background: "#1e1e2e", border: "1px solid #333", borderRadius: 6, padding: 10, color: "#fff", fontFamily: "monospace", fontSize: 12, resize: "none", boxSizing: "border-box" }} />
        <button onClick={generateLyrics} disabled={generating} style={{ width: "100%", marginTop: 8, padding: "10px 0", borderRadius: 6, border: "none", background: generating ? "#333" : "linear-gradient(135deg, #7c3aed, #a855f7)", color: "#fff", fontWeight: 800, cursor: "pointer", fontFamily: "monospace", fontSize: 14 }}>
          {generating ? "⏳ Generating..." : "✨ AI Generate Lyrics"}
        </button>
        {aiLyrics && (
          <div style={{ marginTop: 10, padding: 12, background: "#0d0d1a", borderRadius: 8, border: "1px solid #4c1d95" }}>
            <div style={{ fontSize: 10, color: "#7c3aed", fontFamily: "monospace", marginBottom: 6 }}>AI GENERATED</div>
            <pre style={{ color: "#e9d5ff", fontFamily: "'Trebuchet MS', sans-serif", fontSize: 13, margin: 0, whiteSpace: "pre-wrap" }}>{aiLyrics}</pre>
          </div>
        )}
      </div>

      {/* Save */}
      <button onClick={saveTrack} style={{ padding: "14px 0", borderRadius: 10, border: "none", background: "linear-gradient(135deg, #f97316, #facc15)", color: "#000", fontWeight: 900, cursor: "pointer", fontSize: 16, fontFamily: "monospace", letterSpacing: 2 }}>
        💾 SAVE TRACK
      </button>

      {/* Saved tracks */}
      {saved.length > 0 && (
        <div style={{ background: "#111", borderRadius: 12, padding: 16 }}>
          <div style={{ color: "#888", fontFamily: "monospace", fontSize: 11, marginBottom: 10 }}>📀 SAVED TRACKS</div>
          {saved.map((t, i) => (
            <div key={i} style={{ padding: "8px 12px", borderRadius: 8, background: "#1e1e2e", marginBottom: 6, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ color: "#fff", fontFamily: "monospace", fontSize: 13, fontWeight: 700 }}>{t.title}</div>
                <div style={{ color: "#666", fontSize: 11, fontFamily: "monospace" }}>{t.artist} • {t.genre} • {t.bpm} BPM • {t.chords.join("-") || "No chords"}</div>
              </div>
              <div style={{ color: "#facc15", fontSize: 11, fontFamily: "monospace" }}>✓ Saved</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Home Screen ──────────────────────────────────────────────────────────────
function HomeScreen({ onSelect }) {
  const items = [
    { mode: MODES.GUITAR, icon: "🎸", label: "Guitar Hero", desc: "Hit notes on 5-lane highway", color: "#22c55e" },
    { mode: MODES.DRUMS, icon: "🥁", label: "Drum Machine", desc: "8-pad drums + sequencer", color: "#ec4899" },
    { mode: MODES.PIANO, icon: "🎹", label: "Piano & Chords", desc: "Full keyboard + chord library", color: "#3b82f6" },
    { mode: MODES.KARAOKE, icon: "🎤", label: "Karaoke", desc: "Sing along with mic scoring", color: "#a855f7" },
    { mode: MODES.STUDIO, icon: "🎚️", label: "Music Studio", desc: "Create, compose & AI lyrics", color: "#f97316" },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20, padding: "20px 0" }}>
      {/* Membership CTA banner */}
      <div onClick={() => onSelect(MODES.PRICING)} style={{
        width: "100%", maxWidth: 500, borderRadius: 14, padding: "14px 20px",
        background: "linear-gradient(135deg, #1a0d2e, #0d1a2e)",
        border: "1px solid #7c3aed66",
        boxShadow: "0 0 30px #7c3aed22",
        cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "space-between",
        transition: "all 0.2s",
      }}
        onMouseEnter={e => { e.currentTarget.style.borderColor = "#a78bfa"; e.currentTarget.style.boxShadow = "0 0 40px #7c3aed44"; }}
        onMouseLeave={e => { e.currentTarget.style.borderColor = "#7c3aed66"; e.currentTarget.style.boxShadow = "0 0 30px #7c3aed22"; }}>
        <div>
          <div style={{ fontSize: 11, color: "#a78bfa", fontFamily: "monospace", letterSpacing: 2, marginBottom: 2 }}>✨ MEMBERSHIP PLANS</div>
          <div style={{ fontSize: 13, color: "#e2e8f0", fontWeight: 700 }}>Unlock the full RockForge experience</div>
          <div style={{ fontSize: 10, color: "#555", marginTop: 2 }}>Free · Band Member · Rockstar Pro</div>
        </div>
        <div style={{ fontSize: 22, marginLeft: 12 }}>💎</div>
      </div>

      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 11, letterSpacing: 6, color: "#555", fontFamily: "monospace", marginBottom: 8 }}>CHOOSE YOUR INSTRUMENT</div>
        <div style={{ fontSize: 12, color: "#444", fontFamily: "monospace" }}>Keyboard shortcuts work in every mode</div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12, width: "100%", maxWidth: 500 }}>
        {items.map(item => (
          <div key={item.mode} onClick={() => onSelect(item.mode)} style={{
            background: "#111",
            border: `1px solid ${item.color}44`,
            borderRadius: 14, padding: "20px 16px",
            cursor: "pointer", textAlign: "center",
            transition: "all 0.2s",
            boxShadow: `0 0 0px ${item.color}00`,
          }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = item.color; e.currentTarget.style.boxShadow = `0 0 20px ${item.color}33`; e.currentTarget.style.transform = "translateY(-2px)"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = `${item.color}44`; e.currentTarget.style.boxShadow = "none"; e.currentTarget.style.transform = "none"; }}>
            <div style={{ fontSize: 36, marginBottom: 8 }}>{item.icon}</div>
            <div style={{ color: item.color, fontWeight: 800, fontFamily: "monospace", fontSize: 13, marginBottom: 4 }}>{item.label}</div>
            <div style={{ color: "#555", fontSize: 10, fontFamily: "monospace" }}>{item.desc}</div>
          </div>
        ))}
        <div onClick={() => onSelect(MODES.PRICING)} style={{ background: "linear-gradient(135deg, #0d0d18, #120d1f)", border: "1px solid #7c3aed44", borderRadius: 14, padding: "20px 16px", cursor: "pointer", textAlign: "center", gridColumn: "span 1", transition: "all 0.2s" }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = "#a78bfa"; e.currentTarget.style.transform = "translateY(-2px)"; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = "#7c3aed44"; e.currentTarget.style.transform = "none"; }}>
          <div style={{ fontSize: 36, marginBottom: 8 }}>💎</div>
          <div style={{ color: "#a78bfa", fontFamily: "monospace", fontSize: 11, fontWeight: 700 }}>Membership Plans</div>
          <div style={{ color: "#444", fontSize: 9, marginTop: 2, fontFamily: "monospace" }}>View pricing</div>
        </div>
      </div>
    </div>
  );
}

// ─── Pricing / Membership Page ────────────────────────────────────────────────
function PricingMode({ onSelect }) {
  const [billing, setBilling] = useState("monthly"); // "monthly" | "yearly"
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [showConfirm, setShowConfirm] = useState(false);

  // 🔑 STRIPE PAYMENT LINKS — paste your Stripe links here when ready
  const STRIPE_LINKS = {
    band_monthly: "https://buy.stripe.com/YOUR_BAND_MONTHLY_LINK",
    band_yearly:  "https://buy.stripe.com/YOUR_BAND_YEARLY_LINK",
    rockstar_monthly: "https://buy.stripe.com/YOUR_ROCKSTAR_MONTHLY_LINK",
    rockstar_yearly:  "https://buy.stripe.com/YOUR_ROCKSTAR_YEARLY_LINK",
  };

  const plans = [
    {
      id: "starter",
      name: "Starter",
      emoji: "🎵",
      tagline: "Perfect to get started",
      monthlyPrice: 0,
      yearlyPrice: 0,
      color: "#22c55e",
      glow: "#22c55e",
      badge: null,
      stripeKey: null,
      features: [
        { text: "Guitar Hero mode", included: true },
        { text: "Drum Machine (basic)", included: true },
        { text: "3 built-in songs", included: true },
        { text: "Piano keyboard", included: true },
        { text: "5 chord presets", included: true },
        { text: "Karaoke mode", included: false },
        { text: "AI Lyric Generator", included: false },
        { text: "Save & export tracks", included: false },
        { text: "Unlimited songs", included: false },
        { text: "Priority support", included: false },
      ],
    },
    {
      id: "band",
      name: "Band Member",
      emoji: "🎸",
      tagline: "Most popular · Best value",
      monthlyPrice: 4.99,
      yearlyPrice: 3.99,
      color: "#06b6d4",
      glow: "#06b6d4",
      badge: "MOST POPULAR",
      stripeKey: "band",
      features: [
        { text: "Everything in Starter", included: true },
        { text: "All 5 instruments", included: true },
        { text: "Karaoke + mic scoring", included: true },
        { text: "AI Lyric Generator (15/mo)", included: true },
        { text: "Save up to 20 tracks", included: true },
        { text: "Full chord library", included: true },
        { text: "8-step drum sequencer", included: true },
        { text: "Unlimited songs", included: false },
        { text: "Custom song builder", included: false },
        { text: "Priority support", included: false },
      ],
    },
    {
      id: "rockstar",
      name: "Rockstar Pro",
      emoji: "👑",
      tagline: "For serious creators",
      monthlyPrice: 9.99,
      yearlyPrice: 7.99,
      color: "#f97316",
      glow: "#facc15",
      badge: "BEST",
      stripeKey: "rockstar",
      features: [
        { text: "Everything in Band Member", included: true },
        { text: "Unlimited AI lyrics", included: true },
        { text: "Unlimited track saves", included: true },
        { text: "Custom song builder", included: true },
        { text: "Advanced drum sequencer", included: true },
        { text: "No ads — ever", included: true },
        { text: "Early access to new modes", included: true },
        { text: "Priority email support", included: true },
        { text: "HumanLayerAI Discord VIP", included: true },
        { text: "Cancel anytime", included: true },
      ],
    },
  ];

  const getPrice = (plan) => billing === "yearly" ? plan.yearlyPrice : plan.monthlyPrice;
  const getSaving = (plan) => plan.monthlyPrice > 0 ? Math.round((1 - plan.yearlyPrice / plan.monthlyPrice) * 100) : 0;

  const handleSubscribe = (plan) => {
    if (plan.id === "starter") return;
    setSelectedPlan(plan);
    setShowConfirm(true);
  };

  const goToStripe = (plan) => {
    const key = `${plan.stripeKey}_${billing}`;
    const link = STRIPE_LINKS[key];
    if (link && !link.includes("YOUR_")) {
      window.open(link, "_blank");
    } else {
      alert("💳 Stripe not connected yet.\n\nTo activate payments:\n1. Go to stripe.com and create an account\n2. Create a payment link for this plan\n3. Paste it into STRIPE_LINKS in the code\n\nContact: HumanLayerAI.ops@gmail.com");
    }
    setShowConfirm(false);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 0, paddingBottom: 40 }}>

      {/* Hero heading */}
      <div style={{ textAlign: "center", marginBottom: 32 }}>
        <div style={{ fontSize: 10, letterSpacing: 6, color: "#7c3aed", fontFamily: "monospace", marginBottom: 10 }}>HUMANLAYERAI LLC</div>
        <div style={{ fontSize: 30, fontWeight: 900, lineHeight: 1.1, marginBottom: 8 }}>
          <span style={{ background: "linear-gradient(135deg, #fff, #a78bfa)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Choose Your</span>
          <br />
          <span style={{ background: "linear-gradient(135deg, #f97316, #facc15)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Membership Plan</span>
        </div>
        <div style={{ color: "#555", fontSize: 12, maxWidth: 360, margin: "0 auto", lineHeight: 1.6 }}>
          Unlock the full power of RockForge — create, perform, and earn your place on the leaderboard.
        </div>
      </div>

      {/* Billing toggle */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 32, background: "#0d0d18", borderRadius: 50, padding: "6px 8px", border: "1px solid #1e1e3a" }}>
        <div onClick={() => setBilling("monthly")} style={{ padding: "7px 20px", borderRadius: 50, cursor: "pointer", background: billing === "monthly" ? "#1e1e3a" : "transparent", color: billing === "monthly" ? "#fff" : "#555", fontSize: 12, fontFamily: "monospace", transition: "all 0.2s", fontWeight: billing === "monthly" ? 700 : 400 }}>Monthly</div>
        <div onClick={() => setBilling("yearly")} style={{ padding: "7px 20px", borderRadius: 50, cursor: "pointer", background: billing === "yearly" ? "#1e1e3a" : "transparent", color: billing === "yearly" ? "#fff" : "#555", fontSize: 12, fontFamily: "monospace", transition: "all 0.2s", display: "flex", alignItems: "center", gap: 6, fontWeight: billing === "yearly" ? 700 : 400 }}>
          Yearly
          <span style={{ background: "#22c55e22", color: "#22c55e", fontSize: 9, padding: "2px 6px", borderRadius: 10, border: "1px solid #22c55e44", fontWeight: 700 }}>SAVE 20%</span>
        </div>
      </div>

      {/* Plan cards */}
      <div style={{ display: "flex", flexDirection: "column", gap: 16, width: "100%", maxWidth: 480 }}>
        {plans.map((plan) => {
          const price = getPrice(plan);
          const saving = getSaving(plan);
          const isPopular = plan.id === "band";
          const isBest = plan.id === "rockstar";

          return (
            <div key={plan.id} style={{
              borderRadius: 18, overflow: "hidden",
              border: `1px solid ${isPopular ? "#06b6d466" : isBest ? "#f9731666" : "#1e1e3a"}`,
              background: isBest
                ? "linear-gradient(135deg, #0f0a00, #1a0f00)"
                : isPopular
                ? "linear-gradient(135deg, #00101a, #001520)"
                : "#0d0d18",
              boxShadow: isBest ? "0 0 40px #f9731622" : isPopular ? "0 0 30px #06b6d422" : "none",
              position: "relative",
              transform: isPopular ? "scale(1.02)" : "scale(1)",
              transition: "all 0.3s",
            }}>

              {/* Badge */}
              {plan.badge && (
                <div style={{
                  position: "absolute", top: 14, right: 16,
                  padding: "3px 10px", borderRadius: 20,
                  background: isBest ? "linear-gradient(135deg, #f97316, #facc15)" : "#06b6d4",
                  color: "#000", fontSize: 9, fontWeight: 900, letterSpacing: 2, fontFamily: "monospace",
                }}>{plan.badge}</div>
              )}

              {/* Top accent line */}
              <div style={{ height: 3, background: `linear-gradient(90deg, transparent, ${plan.color}, transparent)` }} />

              <div style={{ padding: "24px 24px 20px" }}>
                {/* Plan header */}
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 16 }}>
                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                      <span style={{ fontSize: 24 }}>{plan.emoji}</span>
                      <span style={{ fontSize: 18, fontWeight: 900, color: "#fff" }}>{plan.name}</span>
                    </div>
                    <div style={{ fontSize: 11, color: "#555", fontStyle: "italic" }}>{plan.tagline}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    {price === 0 ? (
                      <div style={{ fontSize: 28, fontWeight: 900, color: "#22c55e" }}>FREE</div>
                    ) : (
                      <>
                        <div style={{ display: "flex", alignItems: "baseline", gap: 2, justifyContent: "flex-end" }}>
                          <span style={{ fontSize: 13, color: "#888", marginTop: 4 }}>$</span>
                          <span style={{ fontSize: 32, fontWeight: 900, color: plan.color, lineHeight: 1 }}>{price.toFixed(2)}</span>
                        </div>
                        <div style={{ fontSize: 10, color: "#555" }}>/ {billing === "yearly" ? "mo, billed yearly" : "month"}</div>
                        {billing === "yearly" && saving > 0 && (
                          <div style={{ fontSize: 9, color: "#22c55e", marginTop: 2 }}>Save {saving}% vs monthly</div>
                        )}
                      </>
                    )}
                  </div>
                </div>

                {/* Features list */}
                <div style={{ display: "flex", flexDirection: "column", gap: 7, marginBottom: 20 }}>
                  {plan.features.map((f, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <div style={{
                        width: 16, height: 16, borderRadius: "50%", flexShrink: 0,
                        background: f.included ? `${plan.color}22` : "#1a1a2e",
                        border: `1px solid ${f.included ? plan.color : "#2d2d4a"}`,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 9,
                      }}>{f.included ? "✓" : "✕"}</div>
                      <span style={{ fontSize: 12, color: f.included ? "#c4c4d4" : "#3a3a5a" }}>{f.text}</span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                {plan.id === "starter" ? (
                  <div style={{
                    width: "100%", padding: "13px 0", borderRadius: 10, textAlign: "center",
                    border: "1px solid #22c55e44", color: "#22c55e", fontSize: 13, fontWeight: 700,
                    fontFamily: "monospace", letterSpacing: 1,
                  }}>✓ Current Free Plan</div>
                ) : (
                  <button onClick={() => handleSubscribe(plan)} style={{
                    width: "100%", padding: "14px 0", borderRadius: 10, border: "none",
                    background: isBest
                      ? "linear-gradient(135deg, #f97316, #facc15)"
                      : "linear-gradient(135deg, #0369a1, #06b6d4)",
                    color: isBest ? "#000" : "#fff",
                    fontSize: 14, fontWeight: 900, cursor: "pointer",
                    fontFamily: "monospace", letterSpacing: 2,
                    boxShadow: isBest ? "0 4px 20px #f9731644" : "0 4px 20px #06b6d444",
                    transition: "all 0.2s",
                  }}
                    onMouseEnter={e => e.currentTarget.style.transform = "translateY(-1px)"}
                    onMouseLeave={e => e.currentTarget.style.transform = "none"}>
                    {plan.emoji} Subscribe Now
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Trust badges */}
      <div style={{ marginTop: 32, display: "flex", flexWrap: "wrap", gap: 10, justifyContent: "center" }}>
        {["🔒 Secure Checkout via Stripe", "↩️ Cancel Anytime", "📧 HumanLayerAI.ops@gmail.com", "🏢 HumanLayerAI LLC"].map((b, i) => (
          <div key={i} style={{ padding: "5px 14px", borderRadius: 20, background: "#0d0d18", border: "1px solid #1e1e3a", color: "#555", fontSize: 10, fontFamily: "monospace" }}>{b}</div>
        ))}
      </div>

      {/* FAQ strip */}
      <div style={{ marginTop: 24, width: "100%", maxWidth: 480, background: "#0d0d18", borderRadius: 14, padding: 20, border: "1px solid #1e1e3a" }}>
        <div style={{ fontSize: 10, color: "#555", letterSpacing: 3, fontFamily: "monospace", marginBottom: 14 }}>FREQUENTLY ASKED</div>
        {[
          ["Can I cancel anytime?", "Yes — cancel with one click, no questions asked. You keep access until the billing period ends."],
          ["Is my payment secure?", "100%. All payments are processed by Stripe, the same platform used by Amazon, Google & Shopify."],
          ["Can I upgrade later?", "Absolutely. Start free and upgrade whenever you're ready. Charges are prorated."],
        ].map(([q, a], i) => (
          <div key={i} style={{ marginBottom: 14, paddingBottom: 14, borderBottom: i < 2 ? "1px solid #1e1e3a" : "none" }}>
            <div style={{ color: "#c4c4d4", fontSize: 12, fontWeight: 700, marginBottom: 4 }}>{q}</div>
            <div style={{ color: "#555", fontSize: 11, lineHeight: 1.6 }}>{a}</div>
          </div>
        ))}
      </div>

      {/* Confirmation modal */}
      {showConfirm && selectedPlan && (
        <div style={{ position: "fixed", inset: 0, background: "#000000cc", zIndex: 999, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div style={{ background: "#0d0d18", border: `1px solid ${selectedPlan.color}66`, borderRadius: 20, padding: 32, maxWidth: 380, width: "100%", textAlign: "center", boxShadow: `0 0 60px ${selectedPlan.color}33` }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>{selectedPlan.emoji}</div>
            <div style={{ fontSize: 20, fontWeight: 900, color: "#fff", marginBottom: 6 }}>{selectedPlan.name}</div>
            <div style={{ fontSize: 28, fontWeight: 900, color: selectedPlan.color, marginBottom: 4 }}>
              ${getPrice(selectedPlan).toFixed(2)}<span style={{ fontSize: 14, color: "#555" }}>/{billing === "yearly" ? "mo" : "month"}</span>
            </div>
            {billing === "yearly" && <div style={{ fontSize: 11, color: "#22c55e", marginBottom: 16 }}>Billed annually · Save {getSaving(selectedPlan)}%</div>}
            <div style={{ fontSize: 12, color: "#555", marginBottom: 24, lineHeight: 1.6 }}>
              You'll be redirected to Stripe's secure checkout page to complete your subscription.
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setShowConfirm(false)} style={{ flex: 1, padding: "12px 0", borderRadius: 10, border: "1px solid #333", background: "transparent", color: "#888", cursor: "pointer", fontFamily: "monospace", fontSize: 13 }}>Cancel</button>
              <button onClick={() => goToStripe(selectedPlan)} style={{ flex: 2, padding: "12px 0", borderRadius: 10, border: "none", background: `linear-gradient(135deg, ${selectedPlan.color}, ${selectedPlan.glow})`, color: "#000", fontWeight: 900, cursor: "pointer", fontFamily: "monospace", fontSize: 13, letterSpacing: 1 }}>
                🔒 Go to Checkout
              </button>
            </div>
            <div style={{ fontSize: 9, color: "#333", marginTop: 12 }}>Powered by Stripe · HumanLayerAI LLC</div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Brand Footer ─────────────────────────────────────────────────────────────
function BrandFooter() {
  const [hovered, setHovered] = useState(null);
  return (
    <footer style={{
      marginTop: 60,
      borderTop: "1px solid #0f0f1a",
      background: "linear-gradient(180deg, #050508 0%, #07070f 50%, #0a0814 100%)",
      position: "relative", overflow: "hidden",
    }}>
      {/* Decorative top accent line */}
      <div style={{ height: 2, background: "linear-gradient(90deg, transparent, #7c3aed, #06b6d4, #7c3aed, transparent)" }} />

      {/* Radial glow backdrop */}
      <div style={{ position: "absolute", top: 0, left: "50%", transform: "translateX(-50%)", width: 600, height: 300, background: "radial-gradient(ellipse at top, #7c3aed0a 0%, transparent 70%)", pointerEvents: "none" }} />

      <div style={{ maxWidth: 680, margin: "0 auto", padding: "48px 24px 32px" }}>

        {/* Company hero block */}
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          {/* Logo mark */}
          <div style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 72, height: 72, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed22, #06b6d422)", border: "1px solid #7c3aed44", marginBottom: 16, position: "relative" }}>
            <div style={{ position: "absolute", inset: -1, borderRadius: "50%", background: "conic-gradient(from 0deg, #7c3aed, #06b6d4, #ec4899, #7c3aed)", padding: 1, WebkitMask: "radial-gradient(farthest-side, transparent calc(100% - 1px), #fff 0)", mask: "radial-gradient(farthest-side, transparent calc(100% - 1px), #fff 0)", animation: "spinRing 6s linear infinite" }} />
            <span style={{ fontSize: 28 }}>🧠</span>
          </div>

          {/* Company name */}
          <div style={{ fontSize: 32, fontWeight: 900, letterSpacing: 2, lineHeight: 1, marginBottom: 4 }}>
            <span style={{ background: "linear-gradient(135deg, #a78bfa, #06b6d4)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>HumanLayer</span>
            <span style={{ background: "linear-gradient(135deg, #06b6d4, #22d3ee)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>AI</span>
          </div>
          <div style={{ fontSize: 10, letterSpacing: 6, color: "#4a4a6a", fontFamily: "monospace", marginBottom: 20 }}>L I M I T E D &nbsp; L I A B I L I T Y &nbsp; C O M P A N Y</div>

          {/* Divider ornament */}
          <div style={{ display: "flex", alignItems: "center", gap: 12, justifyContent: "center", marginBottom: 20 }}>
            <div style={{ flex: 1, maxWidth: 80, height: 1, background: "linear-gradient(90deg, transparent, #7c3aed44)" }} />
            <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#7c3aed", boxShadow: "0 0 8px #7c3aed" }} />
            <div style={{ width: 4, height: 4, borderRadius: "50%", background: "#06b6d4", boxShadow: "0 0 6px #06b6d4" }} />
            <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#7c3aed", boxShadow: "0 0 8px #7c3aed" }} />
            <div style={{ flex: 1, maxWidth: 80, height: 1, background: "linear-gradient(90deg, #7c3aed44, transparent)" }} />
          </div>

          {/* Tagline */}
          <div style={{ fontSize: 13, color: "#6b7280", fontStyle: "italic", letterSpacing: 1, maxWidth: 380, margin: "0 auto" }}>
            "Where Human Creativity Meets Intelligent Innovation"
          </div>
        </div>

        {/* Three-column info */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 20, marginBottom: 40 }}>

          {/* Company */}
          <div style={{ background: "#0d0d18", border: "1px solid #1a1a2e", borderRadius: 12, padding: "20px 16px" }}>
            <div style={{ fontSize: 9, letterSpacing: 4, color: "#7c3aed", fontFamily: "monospace", marginBottom: 12 }}>COMPANY</div>
            <div style={{ color: "#e2e8f0", fontSize: 13, fontWeight: 700, marginBottom: 6 }}>HumanLayerAI LLC</div>
            <div style={{ color: "#4a5568", fontSize: 11, lineHeight: 1.7 }}>
              <div>Registered LLC</div>
              <div>Technology & Media</div>
              <div>Music Gaming Division</div>
            </div>
          </div>

          {/* Leadership */}
          <div style={{ background: "linear-gradient(135deg, #0d0d18, #0f0d1f)", border: "1px solid #2d1b6933", borderRadius: 12, padding: "20px 16px", position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", top: -10, right: -10, width: 60, height: 60, borderRadius: "50%", background: "radial-gradient(circle, #7c3aed11, transparent)" }} />
            <div style={{ fontSize: 9, letterSpacing: 4, color: "#a78bfa", fontFamily: "monospace", marginBottom: 12 }}>LEADERSHIP</div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #06b6d4)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, flexShrink: 0 }}>👑</div>
              <div>
                <div style={{ color: "#c4b5fd", fontSize: 11, fontWeight: 800, letterSpacing: 1 }}>CEO & OWNER</div>
                <div style={{ color: "#6d28d9", fontSize: 9, letterSpacing: 2 }}>FOUNDER</div>
              </div>
            </div>
            <div style={{ color: "#7c3aed", fontSize: 9, marginTop: 4 }}>HumanLayerAI LLC</div>
          </div>

          {/* Contact */}
          <div style={{ background: "#0d0d18", border: "1px solid #1a1a2e", borderRadius: 12, padding: "20px 16px" }}>
            <div style={{ fontSize: 9, letterSpacing: 4, color: "#06b6d4", fontFamily: "monospace", marginBottom: 12 }}>CONTACT</div>
            <a href="mailto:HumanLayerAI.ops@gmail.com"
              onMouseEnter={() => setHovered("email")}
              onMouseLeave={() => setHovered(null)}
              style={{
                display: "flex", alignItems: "flex-start", gap: 6, textDecoration: "none",
                padding: "8px", borderRadius: 8, margin: "-8px",
                background: hovered === "email" ? "#06b6d411" : "transparent",
                border: hovered === "email" ? "1px solid #06b6d422" : "1px solid transparent",
                transition: "all 0.2s",
              }}>
              <span style={{ fontSize: 14, marginTop: 1 }}>📧</span>
              <div>
                <div style={{ color: "#94a3b8", fontSize: 9, letterSpacing: 1, marginBottom: 2 }}>OPERATIONS</div>
                <div style={{ color: hovered === "email" ? "#22d3ee" : "#06b6d4", fontSize: 10, wordBreak: "break-all", fontFamily: "monospace", transition: "color 0.2s" }}>HumanLayerAI<br />.ops@gmail.com</div>
              </div>
            </a>
          </div>
        </div>

        {/* Product badge strip */}
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", marginBottom: 32 }}>
          {["🎸 RockForge Studio", "🎮 Music Gaming", "🧠 AI-Powered", "🎵 Sound Engine", "✨ Lyric Generator", "🎤 Karaoke Engine"].map((badge, i) => (
            <div key={i} style={{
              padding: "5px 12px", borderRadius: 20,
              background: "#0d0d18", border: "1px solid #1e1e3a",
              color: "#4a5568", fontSize: 10, fontFamily: "monospace",
              letterSpacing: 0.5,
            }}>{badge}</div>
          ))}
        </div>

        {/* Bottom bar */}
        <div style={{ borderTop: "1px solid #0f0f1a", paddingTop: 20, display: "flex", flexDirection: "column", alignItems: "center", gap: 6, textAlign: "center" }}>
          <div style={{ fontSize: 10, color: "#2d2d4a", fontFamily: "monospace", letterSpacing: 2 }}>
            © {new Date().getFullYear()} HUMANLAYERAI LLC — ALL RIGHTS RESERVED
          </div>
          <div style={{ fontSize: 9, color: "#1e1e2e", letterSpacing: 1 }}>
            Powered by HumanLayerAI · RockForge™ Music Game Platform
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function RockForge() {
  const [mode, setMode] = useState(MODES.HOME);
  const audio = useAudioEngine();

  const modeLabels = { [MODES.HOME]: "HOME", [MODES.GUITAR]: "🎸 GUITAR HERO", [MODES.DRUMS]: "🥁 DRUMS", [MODES.PIANO]: "🎹 PIANO", [MODES.KARAOKE]: "🎤 KARAOKE", [MODES.STUDIO]: "🎚️ STUDIO", [MODES.PRICING]: "💎 MEMBERSHIP" };

  return (
    <div style={{ minHeight: "100vh", background: "#050508", color: "#fff", fontFamily: "monospace" }}>
      <style>{`
        @keyframes hitFlash { 0%{opacity:1;transform:scaleY(1)} 100%{opacity:0;transform:scaleY(2)} }
        @keyframes pulse { from{opacity:0.85} to{opacity:1} }
        @keyframes titleGlow { 0%,100%{text-shadow:0 0 20px #f97316,0 0 40px #f9731666} 50%{text-shadow:0 0 40px #facc15,0 0 80px #facc1566} }
        @keyframes spinRing { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        @keyframes brandPulse { 0%,100%{opacity:0.7} 50%{opacity:1} }
        * { box-sizing: border-box; }
        input[type=range] { accent-color: #f97316; }
        ::-webkit-scrollbar { width: 4px; } ::-webkit-scrollbar-track { background: #111; } ::-webkit-scrollbar-thumb { background: #333; border-radius: 2px; }
      `}</style>

      {/* Header */}
      <div style={{ background: "linear-gradient(90deg, #07070f, #0a0814, #07070f)", borderBottom: "1px solid #12122a", padding: "12px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 100, boxShadow: "0 4px 24px #00000099" }}>
        {/* Left: Brand */}
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ position: "relative" }}>
            <div style={{ width: 38, height: 38, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #06b6d4)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, boxShadow: "0 0 16px #7c3aed55" }}>🧠</div>
          </div>
          <div>
            <div style={{ display: "flex", alignItems: "baseline", gap: 0 }}>
              <span style={{ fontSize: 16, fontWeight: 900, letterSpacing: 1, background: "linear-gradient(135deg, #a78bfa, #06b6d4)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>HumanLayer</span>
              <span style={{ fontSize: 16, fontWeight: 900, background: "linear-gradient(135deg, #06b6d4, #22d3ee)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>AI</span>
              <span style={{ fontSize: 9, color: "#4a4a6a", marginLeft: 4, letterSpacing: 1, alignSelf: "flex-end", paddingBottom: 1 }}>LLC</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{ fontSize: 14, animation: "titleGlow 2s ease-in-out infinite" }}>🎸</div>
              <span style={{ fontSize: 8, color: "#3d3d5c", letterSpacing: 3 }}>ROCKFORGE STUDIO</span>
            </div>
          </div>
        </div>

        {/* Right: Mode pill + nav */}
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          {mode !== MODES.HOME && (
            <button onClick={() => setMode(MODES.HOME)} style={{ padding: "5px 12px", borderRadius: 20, border: "1px solid #1e1e3a", background: "transparent", color: "#555", cursor: "pointer", fontSize: 10, fontFamily: "monospace" }}>← HOME</button>
          )}
          {mode !== MODES.PRICING && (
            <button onClick={() => setMode(MODES.PRICING)} style={{ padding: "5px 12px", borderRadius: 20, border: "1px solid #f9731644", background: "#f9731611", color: "#f97316", cursor: "pointer", fontSize: 10, fontFamily: "monospace", fontWeight: 700 }}>💎 Plans</button>
          )}
          <div style={{ padding: "5px 12px", borderRadius: 20, border: "1px solid #7c3aed44", background: "#7c3aed11", color: "#a78bfa", fontSize: 10, letterSpacing: 1 }}>{modeLabels[mode]}</div>
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: "24px 16px", maxWidth: 640, margin: "0 auto" }}>
        {mode === MODES.HOME && <HomeScreen onSelect={setMode} />}
        {mode === MODES.GUITAR && <GuitarMode audio={audio} />}
        {mode === MODES.DRUMS && <DrumMode audio={audio} />}
        {mode === MODES.PIANO && <PianoMode audio={audio} />}
        {mode === MODES.KARAOKE && <KaraokeMode audio={audio} />}
        {mode === MODES.STUDIO && <StudioMode audio={audio} />}
        {mode === MODES.PRICING && <PricingMode onSelect={setMode} />}
      </div>

      <BrandFooter />
    </div>
  );
}
