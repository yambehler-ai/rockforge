import { useState, useEffect } from "react";

const STEPS = [
  {
    id: 1,
    phase: "CREATE ACCOUNT",
    icon: "🏦",
    color: "#6366f1",
    glow: "#6366f155",
    title: "Create Your Stripe Account",
    url: "stripe.com",
    time: "~5 minutes",
    substeps: [
      { icon: "🌐", text: "Go to", highlight: "stripe.com", after: "in your browser" },
      { icon: "📝", text: "Click", highlight: "\"Start now\"", after: "— it's free to sign up" },
      { icon: "📧", text: "Enter your", highlight: "business email", after: "(use HumanLayerAI.ops@gmail.com)" },
      { icon: "🔐", text: "Create a", highlight: "strong password", after: "and verify your email" },
      { icon: "🏢", text: "Select account type:", highlight: "\"Business\"", after: "→ choose LLC" },
    ],
    tip: "Use your ops email to keep everything under HumanLayerAI LLC, not a personal account.",
    tipColor: "#6366f1",
  },
  {
    id: 2,
    phase: "VERIFY BUSINESS",
    icon: "✅",
    color: "#0ea5e9",
    glow: "#0ea5e955",
    title: "Verify HumanLayerAI LLC",
    url: "dashboard.stripe.com/account",
    time: "~10 minutes",
    substeps: [
      { icon: "🏛️", text: "Under Settings → go to", highlight: "\"Business details\"", after: "" },
      { icon: "📋", text: "Enter your", highlight: "LLC name:", after: "\"HumanLayerAI LLC\"" },
      { icon: "🌍", text: "Enter your", highlight: "business address", after: "and country" },
      { icon: "💼", text: "Industry:", highlight: "\"Software / Gaming\"", after: "or Entertainment" },
      { icon: "🏦", text: "Add your", highlight: "bank account", after: "to receive payouts" },
    ],
    tip: "Stripe holds funds for 7 days the first time, then pays out daily automatically to your bank.",
    tipColor: "#0ea5e9",
  },
  {
    id: 3,
    phase: "CREATE PRODUCTS",
    icon: "📦",
    color: "#f59e0b",
    glow: "#f59e0b55",
    title: "Create Your 4 Payment Links",
    url: "dashboard.stripe.com/payment-links",
    time: "~8 minutes",
    substeps: [
      { icon: "➕", text: "Go to", highlight: "Products → + Add product", after: "in the Stripe dashboard" },
      { icon: "🎸", text: "Create:", highlight: "\"Band Member Monthly\"", after: "→ $4.99 / month recurring" },
      { icon: "🎸", text: "Create:", highlight: "\"Band Member Yearly\"", after: "→ $47.88 / year ($3.99/mo)" },
      { icon: "👑", text: "Create:", highlight: "\"Rockstar Pro Monthly\"", after: "→ $9.99 / month recurring" },
      { icon: "👑", text: "Create:", highlight: "\"Rockstar Pro Yearly\"", after: "→ $95.88 / year ($7.99/mo)" },
    ],
    tip: "Set each product as \"Recurring\" (not one-time) so Stripe automatically charges customers every month or year.",
    tipColor: "#f59e0b",
  },
  {
    id: 4,
    phase: "COPY LINKS",
    icon: "🔗",
    color: "#10b981",
    glow: "#10b98155",
    title: "Copy Your Payment Links",
    url: "dashboard.stripe.com/payment-links",
    time: "~2 minutes",
    substeps: [
      { icon: "🖱️", text: "In Stripe dashboard click", highlight: "\"Payment Links\"", after: "in the left sidebar" },
      { icon: "📋", text: "Click", highlight: "\"Copy link\"", after: "next to Band Member Monthly" },
      { icon: "📋", text: "Click", highlight: "\"Copy link\"", after: "next to Band Member Yearly" },
      { icon: "📋", text: "Click", highlight: "\"Copy link\"", after: "next to Rockstar Pro Monthly" },
      { icon: "📋", text: "Click", highlight: "\"Copy link\"", after: "next to Rockstar Pro Yearly" },
    ],
    tip: "Each link looks like: buy.stripe.com/abc123xyz — copy all 4 and keep them handy for the next step.",
    tipColor: "#10b981",
  },
  {
    id: 5,
    phase: "PASTE INTO APP",
    icon: "⚡",
    color: "#f97316",
    glow: "#f9731655",
    title: "Paste Links into RockForge",
    url: "Your RockForge.jsx code",
    time: "~2 minutes",
    substeps: [
      { icon: "📂", text: "Open", highlight: "RockForge.jsx", after: "in your code editor" },
      { icon: "🔍", text: "Find the section called", highlight: "STRIPE_LINKS", after: "(search Ctrl+F)" },
      { icon: "✏️", text: "Replace", highlight: "YOUR_BAND_MONTHLY_LINK", after: "with your copied link" },
      { icon: "✏️", text: "Replace", highlight: "YOUR_BAND_YEARLY_LINK", after: "with your copied link" },
      { icon: "✏️", text: "Replace both", highlight: "ROCKSTAR links", after: "with your copied links" },
    ],
    tip: "After pasting, save the file and redeploy. The Subscribe buttons will now route customers directly to Stripe checkout.",
    tipColor: "#f97316",
    codeSnippet: true,
  },
  {
    id: 6,
    phase: "GO LIVE",
    icon: "🚀",
    color: "#a855f7",
    glow: "#a855f755",
    title: "Test & Go Live",
    url: "dashboard.stripe.com/test",
    time: "~5 minutes",
    substeps: [
      { icon: "🧪", text: "In Stripe, toggle to", highlight: "\"Test mode\"", after: "first (top-right switch)" },
      { icon: "💳", text: "Use test card:", highlight: "4242 4242 4242 4242", after: "any future date, any CVC" },
      { icon: "✅", text: "Confirm you see", highlight: "payment succeed", after: "in Stripe dashboard" },
      { icon: "🔴", text: "Toggle to", highlight: "\"Live mode\"", after: "— real payments are now active!" },
      { icon: "💰", text: "Monitor earnings in", highlight: "Stripe Dashboard", after: "→ Payments section" },
    ],
    tip: "Stripe takes 2.9% + 30¢ per transaction. On $4.99 Band Member you keep ~$4.54. On $9.99 Rockstar you keep ~$9.40.",
    tipColor: "#a855f7",
  },
];

const CODE_SNIPPET = `// In RockForge.jsx — find STRIPE_LINKS and replace:

const STRIPE_LINKS = {
  band_monthly:     "https://buy.stripe.com/PASTE_HERE",
  band_yearly:      "https://buy.stripe.com/PASTE_HERE",
  rockstar_monthly: "https://buy.stripe.com/PASTE_HERE",
  rockstar_yearly:  "https://buy.stripe.com/PASTE_HERE",
};`;

const FLOW_NODES = [
  { label: "Customer\nClicks Subscribe", icon: "👤", color: "#6366f1" },
  { label: "RockForge\nOpens Stripe Link", icon: "🎸", color: "#0ea5e9" },
  { label: "Stripe Secure\nCheckout Page", icon: "🔒", color: "#f59e0b" },
  { label: "Card Charged\nSuccessfully", icon: "💳", color: "#10b981" },
  { label: "Payout to Your\nBank Account", icon: "🏦", color: "#a855f7" },
];

export default function StripeGuide() {
  const [activeStep, setActiveStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState(new Set());
  const [showCode, setShowCode] = useState(false);
  const [copied, setCopied] = useState(false);
  const [flowActive, setFlowActive] = useState(false);
  const [flowStep, setFlowStep] = useState(-1);
  const [animIn, setAnimIn] = useState(true);

  const step = STEPS[activeStep];

  useEffect(() => {
    setAnimIn(false);
    const t = setTimeout(() => setAnimIn(true), 50);
    return () => clearTimeout(t);
  }, [activeStep]);

  useEffect(() => {
    if (!flowActive) { setFlowStep(-1); return; }
    setFlowStep(0);
    const interval = setInterval(() => {
      setFlowStep(s => {
        if (s >= FLOW_NODES.length - 1) { setFlowActive(false); return -1; }
        return s + 1;
      });
    }, 700);
    return () => clearInterval(interval);
  }, [flowActive]);

  const markDone = () => {
    setCompletedSteps(prev => new Set([...prev, activeStep]));
    if (activeStep < STEPS.length - 1) setActiveStep(activeStep + 1);
  };

  const copyCode = () => {
    navigator.clipboard?.writeText(CODE_SNIPPET);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const progress = (completedSteps.size / STEPS.length) * 100;

  return (
    <div style={{
      minHeight: "100vh",
      background: "#04040a",
      color: "#fff",
      fontFamily: "'Courier New', monospace",
      padding: "0 0 60px",
    }}>
      <style>{`
        @keyframes fadeSlideIn { from { opacity:0; transform:translateY(12px); } to { opacity:1; transform:translateY(0); } }
        @keyframes pulseRing { 0%,100%{box-shadow:0 0 0 0 currentColor} 50%{box-shadow:0 0 0 6px transparent} }
        @keyframes flowPulse { 0%{opacity:0.4;transform:scale(0.95)} 100%{opacity:1;transform:scale(1.05)} }
        @keyframes shimmer { 0%{background-position:200% center} 100%{background-position:-200% center} }
        @keyframes connectorFlow { 0%{stroke-dashoffset:20} 100%{stroke-dashoffset:0} }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 3px; }
        ::-webkit-scrollbar-thumb { background: #1e1e3a; border-radius: 2px; }
      `}</style>

      {/* ── Header ── */}
      <div style={{
        background: "linear-gradient(180deg, #07071a 0%, #04040a 100%)",
        borderBottom: "1px solid #0f0f2a",
        padding: "20px 20px 0",
      }}>
        <div style={{ maxWidth: 700, margin: "0 auto" }}>
          {/* Breadcrumb */}
          <div style={{ fontSize: 9, color: "#2d2d5a", letterSpacing: 4, marginBottom: 14 }}>
            HUMANLAYERAI LLC &nbsp;/&nbsp; ROCKFORGE™ &nbsp;/&nbsp; PAYMENT SETUP GUIDE
          </div>

          {/* Title block */}
          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
            <div>
              <h1 style={{
                margin: 0, fontSize: 26, fontWeight: 900, letterSpacing: 1, lineHeight: 1.1,
                background: "linear-gradient(135deg, #fff 30%, #6366f1 70%, #a855f7)",
                WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
              }}>Activate Stripe Payments</h1>
              <div style={{ fontSize: 12, color: "#3d3d6a", marginTop: 6, letterSpacing: 1 }}>
                6-step visual guide · ~30 minutes total · No coding required
              </div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 10, color: "#3d3d6a", marginBottom: 4 }}>SETUP PROGRESS</div>
              <div style={{ fontSize: 22, fontWeight: 900, color: progress === 100 ? "#10b981" : "#6366f1" }}>
                {Math.round(progress)}%
              </div>
            </div>
          </div>

          {/* Progress bar */}
          <div style={{ marginTop: 16, marginBottom: 0, height: 3, background: "#0f0f2a", borderRadius: 2, overflow: "hidden" }}>
            <div style={{
              height: "100%", borderRadius: 2,
              width: `${progress}%`,
              background: "linear-gradient(90deg, #6366f1, #a855f7, #f97316)",
              transition: "width 0.6s ease",
            }} />
          </div>

          {/* Step tabs */}
          <div style={{ display: "flex", gap: 0, marginTop: 16, overflowX: "auto", paddingBottom: 0 }}>
            {STEPS.map((s, i) => {
              const done = completedSteps.has(i);
              const active = activeStep === i;
              return (
                <div key={i} onClick={() => setActiveStep(i)} style={{
                  padding: "10px 14px", cursor: "pointer", whiteSpace: "nowrap",
                  borderBottom: active ? `2px solid ${s.color}` : "2px solid transparent",
                  color: active ? s.color : done ? "#3d4d6a" : "#2a2a4a",
                  fontSize: 10, letterSpacing: 1, fontWeight: active ? 800 : 400,
                  transition: "all 0.2s",
                  display: "flex", alignItems: "center", gap: 5,
                }}>
                  <span style={{
                    width: 16, height: 16, borderRadius: "50%", display: "inline-flex",
                    alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 900,
                    background: done ? "#10b981" : active ? s.color : "#1a1a3a",
                    color: done || active ? "#000" : "#3d3d6a",
                    flexShrink: 0,
                  }}>{done ? "✓" : i + 1}</span>
                  {s.phase}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 700, margin: "0 auto", padding: "28px 20px" }}>

        {/* ── Money Flow Diagram ── */}
        <div style={{
          background: "#07071a",
          border: "1px solid #12122a",
          borderRadius: 16, padding: "20px 16px", marginBottom: 24,
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 3 }}>HOW MONEY FLOWS — VISUAL DIAGRAM</div>
            <button onClick={() => setFlowActive(true)} disabled={flowActive} style={{
              padding: "5px 14px", borderRadius: 20, border: "none",
              background: flowActive ? "#1a1a3a" : "linear-gradient(135deg, #6366f1, #a855f7)",
              color: "#fff", fontSize: 10, cursor: "pointer", fontFamily: "monospace", fontWeight: 700,
            }}>▶ Animate Flow</button>
          </div>

          {/* Flow nodes */}
          <div style={{ display: "flex", alignItems: "center", overflowX: "auto", gap: 0, paddingBottom: 4 }}>
            {FLOW_NODES.map((node, i) => {
              const isActive = flowStep === i;
              const isPast = flowStep > i;
              return (
                <div key={i} style={{ display: "flex", alignItems: "center", flexShrink: 0 }}>
                  <div style={{
                    display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
                    animation: isActive ? "flowPulse 0.4s ease-in-out" : "none",
                  }}>
                    <div style={{
                      width: 52, height: 52, borderRadius: "50%",
                      background: isPast || isActive ? `${node.color}22` : "#0d0d1a",
                      border: `2px solid ${isPast || isActive ? node.color : "#1a1a3a"}`,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 22,
                      boxShadow: isActive ? `0 0 24px ${node.color}88` : isPast ? `0 0 8px ${node.color}44` : "none",
                      transition: "all 0.4s",
                    }}>{node.icon}</div>
                    <div style={{
                      fontSize: 8, color: isPast || isActive ? node.color : "#2a2a4a",
                      textAlign: "center", letterSpacing: 0.5, lineHeight: 1.4,
                      whiteSpace: "pre-line", maxWidth: 64,
                      transition: "color 0.4s",
                    }}>{node.label}</div>
                  </div>
                  {i < FLOW_NODES.length - 1 && (
                    <div style={{ display: "flex", alignItems: "center", margin: "0 4px", marginBottom: 20 }}>
                      <div style={{
                        width: 28, height: 2,
                        background: flowStep > i ? `linear-gradient(90deg, ${FLOW_NODES[i].color}, ${FLOW_NODES[i+1].color})` : "#1a1a3a",
                        transition: "background 0.4s",
                        borderRadius: 1,
                      }} />
                      <div style={{
                        width: 0, height: 0,
                        borderTop: "4px solid transparent",
                        borderBottom: "4px solid transparent",
                        borderLeft: `6px solid ${flowStep > i ? FLOW_NODES[i+1].color : "#1a1a3a"}`,
                        transition: "border-left-color 0.4s",
                      }} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Revenue callout */}
          <div style={{ display: "flex", gap: 8, marginTop: 16, flexWrap: "wrap" }}>
            {[
              { label: "Band Member", price: "$4.99/mo", keep: "~$4.54", color: "#0ea5e9" },
              { label: "Rockstar Pro", price: "$9.99/mo", keep: "~$9.40", color: "#f97316" },
              { label: "Stripe Fee", price: "2.9% + 30¢", keep: "per charge", color: "#3d3d6a" },
            ].map((r, i) => (
              <div key={i} style={{
                flex: 1, minWidth: 120, padding: "10px 12px", borderRadius: 10,
                background: "#0d0d1a", border: `1px solid ${r.color}33`,
              }}>
                <div style={{ fontSize: 9, color: r.color, letterSpacing: 1, marginBottom: 4 }}>{r.label}</div>
                <div style={{ fontSize: 14, fontWeight: 900, color: "#fff" }}>{r.price}</div>
                <div style={{ fontSize: 9, color: "#3d3d6a", marginTop: 2 }}>You keep: {r.keep}</div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Active Step Card ── */}
        <div style={{
          background: "#07071a",
          border: `1px solid ${step.color}44`,
          borderRadius: 16,
          boxShadow: `0 0 40px ${step.glow}`,
          overflow: "hidden",
          animation: animIn ? "fadeSlideIn 0.3s ease" : "none",
        }}>
          {/* Step accent bar */}
          <div style={{ height: 3, background: `linear-gradient(90deg, transparent, ${step.color}, transparent)` }} />

          <div style={{ padding: "24px 24px 20px" }}>
            {/* Step header */}
            <div style={{ display: "flex", alignItems: "flex-start", gap: 16, marginBottom: 24 }}>
              <div style={{
                width: 56, height: 56, borderRadius: 14, flexShrink: 0,
                background: `${step.color}18`,
                border: `1px solid ${step.color}44`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 26,
              }}>{step.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                  <span style={{ fontSize: 9, background: step.color, color: "#000", padding: "2px 8px", borderRadius: 10, fontWeight: 900, letterSpacing: 1 }}>STEP {step.id} OF {STEPS.length}</span>
                  <span style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 1 }}>⏱ {step.time}</span>
                </div>
                <div style={{ fontSize: 18, fontWeight: 900, color: "#fff", marginBottom: 4 }}>{step.title}</div>
                <div style={{ fontSize: 10, color: step.color, letterSpacing: 1 }}>🌐 {step.url}</div>
              </div>
            </div>

            {/* Sub-steps */}
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 20 }}>
              {step.substeps.map((sub, i) => (
                <div key={i} style={{
                  display: "flex", alignItems: "flex-start", gap: 12, padding: "10px 14px",
                  background: "#0d0d1a", borderRadius: 10,
                  border: "1px solid #12122a",
                  animation: `fadeSlideIn 0.3s ease ${i * 0.06}s both`,
                }}>
                  <span style={{ fontSize: 16, flexShrink: 0, marginTop: 1 }}>{sub.icon}</span>
                  <div style={{ fontSize: 12, lineHeight: 1.6, color: "#8888aa" }}>
                    {sub.text}{" "}
                    <span style={{
                      color: step.color, fontWeight: 800,
                      background: `${step.color}15`, padding: "1px 6px", borderRadius: 4,
                    }}>{sub.highlight}</span>
                    {sub.after && <span> {sub.after}</span>}
                  </div>
                </div>
              ))}
            </div>

            {/* Code snippet (step 5) */}
            {step.codeSnippet && (
              <div style={{ marginBottom: 20 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                  <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 2 }}>CODE — FIND & REPLACE IN ROCKFORGE.JSX</div>
                  <button onClick={copyCode} style={{
                    padding: "4px 12px", borderRadius: 8, border: "none",
                    background: copied ? "#10b981" : "#1a1a3a",
                    color: "#fff", fontSize: 10, cursor: "pointer", fontFamily: "monospace",
                    transition: "background 0.2s",
                  }}>{copied ? "✓ Copied!" : "Copy"}</button>
                </div>
                <pre style={{
                  background: "#030308", border: "1px solid #12122a", borderRadius: 10,
                  padding: "14px 16px", fontSize: 10, color: "#8888cc", lineHeight: 1.8,
                  overflow: "auto", margin: 0,
                  fontFamily: "'Courier New', monospace",
                }}>
                  {CODE_SNIPPET.split("\n").map((line, i) => {
                    if (line.includes("PASTE_HERE")) {
                      const [before, after] = line.split("PASTE_HERE");
                      return <div key={i}>{before}<span style={{ color: "#f97316", background: "#f9731622", padding: "0 3px", borderRadius: 3 }}>YOUR_STRIPE_LINK</span>{after}</div>;
                    }
                    if (line.includes("const STRIPE_LINKS")) return <div key={i} style={{ color: "#6366f1" }}>{line}</div>;
                    if (line.startsWith("//")) return <div key={i} style={{ color: "#3d3d6a" }}>{line}</div>;
                    return <div key={i}>{line}</div>;
                  })}
                </pre>
              </div>
            )}

            {/* Tip box */}
            <div style={{
              padding: "12px 16px", borderRadius: 10,
              background: `${step.color}0d`,
              border: `1px solid ${step.color}33`,
              marginBottom: 20,
              display: "flex", gap: 10, alignItems: "flex-start",
            }}>
              <span style={{ fontSize: 14, flexShrink: 0 }}>💡</span>
              <div style={{ fontSize: 11, color: "#8888aa", lineHeight: 1.7 }}>
                <span style={{ color: step.tipColor, fontWeight: 700 }}>Pro tip: </span>
                {step.tip}
              </div>
            </div>

            {/* Action buttons */}
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setActiveStep(Math.max(0, activeStep - 1))} disabled={activeStep === 0} style={{
                padding: "11px 20px", borderRadius: 10, border: "1px solid #1a1a3a",
                background: "transparent", color: activeStep === 0 ? "#2a2a4a" : "#8888aa",
                cursor: activeStep === 0 ? "default" : "pointer", fontSize: 12, fontFamily: "monospace",
              }}>← Back</button>
              <button onClick={markDone} style={{
                flex: 1, padding: "12px 0", borderRadius: 10, border: "none",
                background: completedSteps.has(activeStep)
                  ? "#10b981"
                  : `linear-gradient(135deg, ${step.color}, ${step.color}cc)`,
                color: "#fff", fontSize: 13, fontWeight: 900,
                cursor: "pointer", fontFamily: "monospace", letterSpacing: 1,
                transition: "all 0.2s",
              }}>
                {completedSteps.has(activeStep)
                  ? "✓ Step Complete"
                  : activeStep === STEPS.length - 1
                  ? "🚀 Mark Complete & Go Live!"
                  : `✓ Done → Next Step`}
              </button>
            </div>
          </div>
        </div>

        {/* ── All Steps Overview ── */}
        <div style={{ marginTop: 20 }}>
          <div style={{ fontSize: 9, color: "#2a2a4a", letterSpacing: 3, marginBottom: 12 }}>ALL STEPS OVERVIEW</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {STEPS.map((s, i) => {
              const done = completedSteps.has(i);
              const active = activeStep === i;
              return (
                <div key={i} onClick={() => setActiveStep(i)} style={{
                  display: "flex", alignItems: "center", gap: 12, padding: "10px 14px",
                  borderRadius: 10, cursor: "pointer",
                  background: active ? `${s.color}0f` : "#07071a",
                  border: `1px solid ${active ? s.color + "44" : done ? "#10b98133" : "#0f0f2a"}`,
                  transition: "all 0.2s",
                }}>
                  <div style={{
                    width: 24, height: 24, borderRadius: "50%", flexShrink: 0,
                    background: done ? "#10b981" : active ? s.color : "#0d0d1a",
                    border: `1px solid ${done ? "#10b981" : active ? s.color : "#1a1a3a"}`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: done ? 10 : 11, fontWeight: 900, color: done || active ? "#000" : "#3d3d6a",
                  }}>{done ? "✓" : i + 1}</div>
                  <span style={{ fontSize: 13 }}>{s.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, color: active ? "#fff" : done ? "#4d6d5a" : "#3d3d6a", fontWeight: active ? 700 : 400 }}>{s.title}</div>
                  </div>
                  <div style={{ fontSize: 9, color: "#2a2a4a" }}>{s.time}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ── Completion banner ── */}
        {completedSteps.size === STEPS.length && (
          <div style={{
            marginTop: 24, padding: "24px 20px", borderRadius: 16, textAlign: "center",
            background: "linear-gradient(135deg, #052210, #0a3a1a)",
            border: "1px solid #10b98166",
            boxShadow: "0 0 40px #10b98133",
            animation: "fadeSlideIn 0.5s ease",
          }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>🎉</div>
            <div style={{ fontSize: 20, fontWeight: 900, color: "#10b981", marginBottom: 6 }}>Payments Are Live!</div>
            <div style={{ fontSize: 12, color: "#3d7a5a", lineHeight: 1.7 }}>
              RockForge is now taking real payments for HumanLayerAI LLC.<br />
              Monitor earnings at <span style={{ color: "#10b981" }}>dashboard.stripe.com</span>
            </div>
            <div style={{ marginTop: 16, fontSize: 11, color: "#2a5a3a" }}>Questions? Contact: HumanLayerAI.ops@gmail.com</div>
          </div>
        )}
      </div>
    </div>
  );
}
