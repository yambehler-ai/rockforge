import { useState } from "react";

const PLATFORMS = [
  { id: "twitter", label: "Twitter / X", icon: "🐦", color: "#1DA1F2", charLimit: 280 },
  { id: "instagram", label: "Instagram", icon: "📸", color: "#E1306C", charLimit: 2200 },
  { id: "tiktok", label: "TikTok", icon: "🎵", color: "#010101", charLimit: 2200 },
  { id: "linkedin", label: "LinkedIn", icon: "💼", color: "#0A66C2", charLimit: 3000 },
  { id: "reddit", label: "Reddit", icon: "🤖", color: "#FF4500", charLimit: 40000 },
  { id: "facebook", label: "Facebook", icon: "📘", color: "#1877F2", charLimit: 63206 },
  { id: "discord", label: "Discord", icon: "💬", color: "#5865F2", charLimit: 2000 },
  { id: "producthunt", label: "Product Hunt", icon: "🚀", color: "#DA552F", charLimit: 260 },
];

const POST_CATEGORIES = [
  { id: "launch", label: "🚀 Launch", desc: "Announce RockForge to the world" },
  { id: "feature", label: "🎸 Feature Highlight", desc: "Spotlight a specific game mode" },
  { id: "promo", label: "💎 Promo / Offer", desc: "Drive signups with urgency" },
  { id: "community", label: "🏆 Community", desc: "Engage existing players" },
  { id: "behind", label: "🧠 Behind the Scenes", desc: "Build brand credibility" },
];

const POSTS = {
  twitter: {
    launch: `🎸 Introducing RockForge — the music game studio you've been waiting for.

Guitar Hero ✅ Drums ✅ Piano ✅ Karaoke ✅ AI Lyrics ✅

All in your browser. No download. No install. Just play.

🆓 Free to start → rockforge.io

#RockForge #MusicGame #IndieGame #WebGame #AI`,

    feature: `🥁 The RockForge Drum Machine hits different.

8 live pads + a full step sequencer. Record your pattern, set your BPM, and loop it forever.

No drum kit required. Just your keyboard.

Try it free → rockforge.io 🎵

#Drums #BeatMaker #MusicProduction #RockForge`,

    promo: `🔥 RockForge Rockstar Pro = $9.99/month

✨ Unlimited AI-generated lyrics
🎵 Unlimited track saves
🎸 All 5 instruments unlocked
👑 VIP Discord access

Start FREE. Upgrade when ready.

rockforge.io 💎 #MusicGame #AI #RockForge`,

    community: `📢 Shoutout to everyone already rocking on RockForge 🎸

Who has the highest Guitar Hero streak? Drop your score below 👇

Current record: 142 combo streak 🏆

Can YOU beat it? → rockforge.io

#RockForge #GuitarHero #MusicGame #Leaderboard`,

    behind: `🧠 Built RockForge entirely in the browser.

No Unity. No Unreal. Just web tech + Claude AI + a whole lot of passion.

Guitar Hero highway, drum sequencer, piano, karaoke mic scoring, and AI lyrics — all from one tab.

HumanLayerAI LLC 🚀 rockforge.io

#BuildInPublic #IndieGame #WebDev #AI`,
  },

  instagram: {
    launch: `🎸 ROCKFORGE IS HERE 🎸

The music game studio you didn't know you needed — and now you can't live without.

✅ Guitar Hero-style 5-lane highway
✅ 8-pad drum machine + step sequencer  
✅ Full piano keyboard with chord library
✅ Karaoke with real mic scoring
✅ AI-powered lyric generator
✅ Music creation studio

ALL IN YOUR BROWSER. No download. No install.

🆓 Start completely free at rockforge.io

Tag a friend who needs this in their life 👇

.
.
.
#RockForge #MusicGame #GuitarHero #DrumMachine #Piano #Karaoke #AIMusic #IndieGame #WebGame #MusicStudio #BrowserGame #HumanLayerAI #GameDev #MusicProduction #NewLaunch #FreeGame #MusicCreator #BeatMaker #SongWriter #ArtificialIntelligence`,

    feature: `🎤 KARAOKE MODE IS WILD 🎤

RockForge doesn't just scroll lyrics — it actually listens to you sing through your microphone and scores your performance in real time.

✨ Real-time frequency analysis
🎯 Live scoring as you sing
📊 Visual mic level display
🎵 Multiple songs to choose from

Whether you're a shower singer or a stage performer — this is your moment.

🆓 Try it free → rockforge.io

Drop a 🎤 if you're going to try karaoke mode!

.
.
.
#Karaoke #SingAlong #MusicGame #RockForge #VoiceRecognition #SingKaraoke #KaraokeNight #Music #Fun #BrowserGame`,

    promo: `💎 ROCKSTAR PRO — $9.99/month 💎

The ultimate music game experience:

👑 Unlimited AI lyric generation
🎵 Unlimited track saves  
🎸 All 5 instruments unlocked
🥁 Advanced drum sequencer
🎹 Full piano + chord library
🎤 Karaoke mic scoring
✨ Early access to new modes
🏆 VIP Discord community
📧 Priority support

Start FREE. Upgrade when you're ready. Cancel anytime.

Link in bio → rockforge.io

.
.
.
#RockForge #MusicGame #Subscribe #MusicStudio #AIMusic #GuitarHero #Piano #Karaoke #Membership #Gaming`,

    community: `🏆 THE ROCKFORGE LEADERBOARD IS LIVE 🏆

Who's topping the charts this week?

Current top scores:
🥇 NeonRider — 98,450 pts (Guitar Hero)
🥈 BeatQueen — 87,200 pts (Drums)  
🥉 KeyMaster — 76,800 pts (Piano)

Think you can beat them? 

Submit your score at rockforge.io and claim your spot 👑

Drop your score in the comments 👇

.
.
.
#RockForge #Leaderboard #GamingCommunity #MusicGame #GuitarHero #CompetitiveGaming #HighScore #Gaming`,

    behind: `🧠 MEET THE TEAM BEHIND ROCKFORGE

HumanLayerAI LLC is a technology & media company built around one belief:

Human creativity + AI intelligence = something extraordinary.

RockForge™ is our flagship product — a music game studio that lives entirely in your browser.

We built it because we believe:
🎸 Music should be fun for everyone
🧠 AI should amplify creativity, not replace it
🌍 Great tools shouldn't require a download

We're just getting started. More modes. More AI. More music.

Follow along 👉 rockforge.io

📧 HumanLayerAI.ops@gmail.com

.
.
.
#HumanLayerAI #BuildInPublic #StartupLife #IndieGame #AIStartup #MusicTech #GameDev #Founder #CEO #Entrepreneurship`,
  },

  tiktok: {
    launch: `🎸 POV: You just found the best browser game of 2025

RockForge = Guitar Hero + Drums + Piano + Karaoke + AI Music Studio

All in one tab. FREE to play.

Go to rockforge.io and try it RIGHT NOW 🔥

#RockForge #GuitarHero #MusicGame #FreeGame #BrowserGame #fyp #foryou #gaming #music #viral`,

    feature: `🥁 I made a beat on RockForge and it SLAPS

8-pad drum machine + step sequencer in your BROWSER

No download. No setup. Just vibes.

Try it free → rockforge.io

#RockForge #DrumMachine #BeatMaker #MusicProduction #fyp #foryoupage #music #beats`,

    promo: `POV: You unlocked Rockstar Pro on RockForge 👑

✨ Unlimited AI lyrics (Claude writes your songs)
🎸 All 5 instruments
🏆 Leaderboard VIP status

Only $9.99/month — less than one Spotify family plan

Start FREE at rockforge.io 🔥

#RockForge #MusicGame #AI #Subscribe #fyp #gaming #music`,

    community: `🏆 Calling all RockForge players

What's YOUR best Guitar Hero streak?

Mine: 67 combo 😤

Drop yours below 👇 and visit rockforge.io to climb the leaderboard

#RockForge #GuitarHero #GamingChallenge #MusicGame #fyp #gaming #challenge`,

    behind: `🧠 I built a music game studio in the browser

Guitar Hero + Drums + Piano + Karaoke + AI Lyrics

One tab. No download. Free to play.

Built by HumanLayerAI LLC 🚀

rockforge.io — go try it

#BuildInPublic #IndieGame #StartupLife #HumanLayerAI #MusicGame #fyp #gaming`,
  },

  linkedin: {
    launch: `🎸 Excited to announce the launch of RockForge™ — a browser-based music game studio built by HumanLayerAI LLC.

RockForge combines the best elements of Guitar Hero, Rock Band, karaoke performance, and AI-powered music creation — all running natively in a web browser with no download required.

Here's what we built:
• 🎸 Guitar Hero-style 5-lane note highway
• 🥁 8-pad drum machine with step sequencer
• 🎹 Full piano keyboard with chord library
• 🎤 Karaoke mode with live microphone scoring
• 🎚️ Music creation studio with BPM, genre, and track saving
• ✨ AI lyric generator powered by Claude

We offer three membership tiers — Free, Band Member ($4.99/mo), and Rockstar Pro ($9.99/mo) — making professional music gaming tools accessible to everyone.

This is the first product from HumanLayerAI LLC, and we're just getting started.

🌐 Try it free: rockforge.io
📧 Contact: HumanLayerAI.ops@gmail.com

I'd love your feedback, connections, and support as we grow this platform. 

#Launch #MusicTech #GameDev #AI #IndieGame #StartupLife #HumanLayerAI #WebDevelopment #Innovation`,

    behind: `🧠 What we learned building RockForge — a music game studio that runs entirely in the browser.

At HumanLayerAI LLC, we set out to answer one question: Can you build a full music game experience without any native app installation?

The answer was yes — but it required rethinking everything.

Key insights from the build:

1. Web Audio API is more powerful than most developers realize. We built a complete drum synthesizer, piano oscillator, and karaoke microphone analyzer entirely in JavaScript.

2. AI-generated content changes the game. Integrating Claude for lyric generation means every user gets personalized, genre-appropriate song lyrics instantly.

3. Freemium works best with clear value tiers. Our Free → Band Member ($4.99) → Rockstar Pro ($9.99) structure gives users a genuine reason to upgrade.

4. Browser games have a massive untapped market. No App Store. No friction. Just a link.

RockForge is live at rockforge.io — I'd love your thoughts.

📧 HumanLayerAI.ops@gmail.com

#BuildInPublic #ProductLaunch #MusicTech #AI #GameDev #WebDevelopment #StartupLessons #HumanLayerAI`,
  },

  reddit: {
    launch: `**I built a browser-based music game studio — Guitar Hero + Drums + Piano + Karaoke + AI Lyrics, all in one tab [rockforge.io]**

Hey r/indiegaming,

I've been working on RockForge for a while and just launched it publicly. It's a browser-based music game studio that combines several instruments and game modes into one experience.

**What's included:**

- 🎸 **Guitar Hero mode** — 5-lane scrolling highway, color-coded frets, combo streak scoring. Press A/S/D/F/J or tap the buttons.
- 🥁 **Drum Machine** — 8 live pads (Hi-Hat, Snare, Kick, Toms, Crash, Ride, Cowbell) + an 8-step sequencer you can record patterns into at any BPM
- 🎹 **Piano** — Full keyboard with black keys, chord library (C, G, Am, F, D, Em), and note history display
- 🎤 **Karaoke** — Scrolling lyrics, microphone input, real-time scoring based on your singing via Web Audio API
- 🎚️ **Music Studio** — Build chord progressions, set BPM and genre, write lyrics, save tracks
- ✨ **AI Lyric Generator** — Uses Claude AI to generate song lyrics based on your title, genre, and chord progression

**Pricing:**
- Free tier — Guitar Hero, Drums, Piano, 3 songs
- Band Member ($4.99/mo) — all instruments, karaoke, AI lyrics (15/mo)
- Rockstar Pro ($9.99/mo) — unlimited everything + VIP support

**No download. No install. Works in any browser.**

Built by HumanLayerAI LLC. Feedback welcome — especially on the drum sequencer and karaoke scoring, which I'd love to improve.

Link: **rockforge.io**

Contact: HumanLayerAI.ops@gmail.com`,

    community: `**RockForge Leaderboard Challenge — What's your highest Guitar Hero streak? [rockforge.io]**

Hey everyone,

The RockForge global leaderboard just went live and I want to see what you've all got.

Current top score: **98,450 points** by NeonRider with a 142 combo streak on Guitar Hero.

**Rules:**
1. Go to rockforge.io
2. Play Guitar Hero mode (keys: A S D F J)
3. Submit your score on the leaderboard
4. Post your result here

Top 3 scorers this week get a free Rockstar Pro upgrade. 👑

Good luck — and let me know if you have any feedback on the game modes while you're at it.

— HumanLayerAI LLC`,
  },

  discord: {
    launch: `🎸 **RockForge is LIVE** — the music game studio you've been waiting for

Guitar Hero highway 🎸 | Drum Machine 🥁 | Piano 🎹 | Karaoke 🎤 | AI Music Studio ✨

All in your browser. FREE to start.

👉 **rockforge.io**

Drop a 🔥 if you're going to try it!`,

    promo: `💎 **Rockstar Pro — $9.99/month**

Unlock everything on RockForge:
✨ Unlimited AI lyrics
🎵 Unlimited track saves  
🎸 All 5 instruments
🏆 Leaderboard VIP status

Start free → upgrade anytime
**rockforge.io**

Use code **DISCORD10** at checkout for 10% off 🎉`,

    community: `🏆 **LEADERBOARD CHALLENGE** 🏆

Who can get the highest streak in Guitar Hero mode?

Current record: **142 combo** by NeonRider

Rules:
> 1. Go to rockforge.io
> 2. Play Guitar Hero (keys: A S D F J)
> 3. Submit your score
> 4. Post your score here

Top score wins a free month of Rockstar Pro 👑

GO GO GO 🎸`,
  },

  producthunt: {
    launch: `RockForge — Guitar Hero + Drums + Piano + Karaoke + AI Lyrics in your browser. No download. Free to start. Built by HumanLayerAI LLC. 🎸`,
    feature: `The karaoke mode on RockForge actually listens to you sing and scores your performance in real time. Try it free at rockforge.io 🎤`,
    promo: `RockForge Rockstar Pro: $9.99/mo for unlimited AI lyrics, all 5 instruments, and leaderboard VIP. Start free → rockforge.io 💎`,
    community: `Who has the highest Guitar Hero streak on RockForge? Current record: 142 combo. Can you beat it? rockforge.io 🏆`,
    behind: `Built RockForge — a full music game studio in the browser — using Web Audio API + Claude AI. No download required. HumanLayerAI LLC 🧠`,
  },
};

export default function SocialMediaKit() {
  const [platform, setPlatform] = useState("twitter");
  const [category, setCategory] = useState("launch");
  const [copied, setCopied] = useState(false);
  const [customized, setCustomized] = useState("");
  const [editMode, setEditMode] = useState(false);

  const currentPlatform = PLATFORMS.find(p => p.id === platform);
  const rawPost = POSTS[platform]?.[category] || POSTS[platform]?.launch || "";
  const displayPost = editMode ? customized : rawPost;
  const charCount = displayPost.length;
  const overLimit = currentPlatform && charCount > currentPlatform.charLimit;

  const handleCopy = () => {
    navigator.clipboard?.writeText(displayPost);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const startEdit = () => {
    setCustomized(rawPost);
    setEditMode(true);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#09090f", color: "#fff", fontFamily: "'Courier New', monospace" }}>
      <style>{`
        @keyframes fadeUp { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 3px; }
        ::-webkit-scrollbar-thumb { background: #1e1e3a; }
        textarea:focus { outline: none; border-color: #6366f1 !important; }
        input:focus { outline: none; }
      `}</style>

      {/* Header */}
      <div style={{ background: "linear-gradient(180deg, #0f0f1f, #09090f)", borderBottom: "1px solid #12122a", padding: "20px 20px 16px" }}>
        <div style={{ maxWidth: 800, margin: "0 auto" }}>
          <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 4, marginBottom: 8 }}>HUMANLAYERAI LLC · ROCKFORGE™</div>
          <h1 style={{ fontSize: 24, fontWeight: 900, background: "linear-gradient(135deg, #fff, #6366f1)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", marginBottom: 4 }}>
            📣 Social Media Post Kit
          </h1>
          <div style={{ fontSize: 11, color: "#3d3d6a" }}>Ready-to-copy captions for every platform · 8 platforms · 5 post types</div>
        </div>
      </div>

      <div style={{ maxWidth: 800, margin: "0 auto", padding: "24px 20px" }}>

        {/* Platform selector */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 3, marginBottom: 10 }}>SELECT PLATFORM</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {PLATFORMS.map(p => (
              <div key={p.id} onClick={() => { setPlatform(p.id); setEditMode(false); }} style={{
                padding: "8px 14px", borderRadius: 20, cursor: "pointer",
                background: platform === p.id ? p.color : "#0f0f1f",
                border: `1px solid ${platform === p.id ? p.color : "#1e1e3a"}`,
                color: platform === p.id ? "#fff" : "#555",
                fontSize: 11, fontWeight: platform === p.id ? 700 : 400,
                display: "flex", alignItems: "center", gap: 6, transition: "all 0.2s",
              }}>
                <span>{p.icon}</span> {p.label}
              </div>
            ))}
          </div>
        </div>

        {/* Category selector */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 3, marginBottom: 10 }}>POST TYPE</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {POST_CATEGORIES.map(c => (
              <div key={c.id} onClick={() => { setCategory(c.id); setEditMode(false); }} style={{
                padding: "8px 14px", borderRadius: 10, cursor: "pointer",
                background: category === c.id ? "#1e1e3a" : "#0f0f1f",
                border: `1px solid ${category === c.id ? "#6366f1" : "#1e1e3a"}`,
                color: category === c.id ? "#fff" : "#555",
                fontSize: 11, transition: "all 0.2s",
              }}>
                <div style={{ fontWeight: category === c.id ? 700 : 400 }}>{c.label}</div>
                <div style={{ fontSize: 9, color: "#3d3d6a", marginTop: 2 }}>{c.desc}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Post preview */}
        <div style={{ background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, overflow: "hidden", animation: "fadeUp 0.3s ease" }}>
          {/* Platform header */}
          <div style={{ padding: "14px 20px", background: `${currentPlatform?.color}11`, borderBottom: "1px solid #1e1e3a", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 20 }}>{currentPlatform?.icon}</span>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#fff" }}>{currentPlatform?.label}</div>
                <div style={{ fontSize: 9, color: "#3d3d6a" }}>Character limit: {currentPlatform?.charLimit.toLocaleString()}</div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <div style={{ fontSize: 10, color: overLimit ? "#ef4444" : "#3d3d6a", fontFamily: "monospace" }}>
                {charCount} / {currentPlatform?.charLimit.toLocaleString()}
              </div>
              <div style={{ width: 60, height: 4, background: "#1e1e3a", borderRadius: 2, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${Math.min(100, (charCount / currentPlatform?.charLimit) * 100)}%`, background: overLimit ? "#ef4444" : "#6366f1", borderRadius: 2, transition: "width 0.3s" }} />
              </div>
            </div>
          </div>

          {/* Post body */}
          <div style={{ padding: "20px" }}>
            {editMode ? (
              <textarea value={customized} onChange={e => setCustomized(e.target.value)} style={{
                width: "100%", minHeight: 300, background: "#07071a", border: "1px solid #6366f1",
                borderRadius: 10, padding: "14px 16px", color: "#e2e8f0",
                fontFamily: "'Courier New', monospace", fontSize: 13, lineHeight: 1.8,
                resize: "vertical",
              }} />
            ) : (
              <pre style={{
                whiteSpace: "pre-wrap", wordBreak: "break-word",
                fontSize: 13, lineHeight: 1.8, color: "#c4c4d4",
                fontFamily: "'Courier New', monospace", margin: 0,
                maxHeight: 400, overflowY: "auto",
              }}>{displayPost}</pre>
            )}
          </div>

          {/* Actions */}
          <div style={{ padding: "0 20px 20px", display: "flex", gap: 10, flexWrap: "wrap" }}>
            <button onClick={handleCopy} style={{
              flex: 2, padding: "12px 0", borderRadius: 10, border: "none",
              background: copied ? "#10b981" : `linear-gradient(135deg, ${currentPlatform?.color}, ${currentPlatform?.color}cc)`,
              color: "#fff", fontSize: 13, fontWeight: 900, cursor: "pointer",
              fontFamily: "monospace", letterSpacing: 1, transition: "all 0.2s",
            }}>{copied ? "✓ Copied to Clipboard!" : `Copy for ${currentPlatform?.label}`}</button>
            <button onClick={editMode ? () => setEditMode(false) : startEdit} style={{
              flex: 1, padding: "12px 0", borderRadius: 10,
              border: "1px solid #1e1e3a", background: "transparent",
              color: "#888", fontSize: 12, cursor: "pointer", fontFamily: "monospace",
            }}>{editMode ? "← Original" : "✏️ Customize"}</button>
          </div>
        </div>

        {/* Quick copy all */}
        <div style={{ marginTop: 24, background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "20px" }}>
          <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 3, marginBottom: 16 }}>📋 QUICK REFERENCE — ALL LAUNCH POSTS</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {PLATFORMS.map(p => {
              const post = POSTS[p.id]?.launch || "";
              const preview = post.slice(0, 80) + (post.length > 80 ? "..." : "");
              return (
                <div key={p.id} style={{ display: "flex", gap: 12, alignItems: "center", padding: "10px 14px", background: "#07071a", borderRadius: 10, border: "1px solid #12122a" }}>
                  <span style={{ fontSize: 18, flexShrink: 0 }}>{p.icon}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: "#888", marginBottom: 2 }}>{p.label}</div>
                    <div style={{ fontSize: 10, color: "#3d3d6a", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{preview}</div>
                  </div>
                  <button onClick={() => { setPlatform(p.id); setCategory("launch"); setEditMode(false); window.scrollTo({ top: 0, behavior: "smooth" }); }} style={{ padding: "5px 12px", borderRadius: 8, border: `1px solid ${p.color}44`, background: "transparent", color: p.color, fontSize: 10, cursor: "pointer", flexShrink: 0, fontFamily: "monospace" }}>View →</button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Hashtag bank */}
        <div style={{ marginTop: 20, background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "20px" }}>
          <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 3, marginBottom: 14 }}>#️⃣ HASHTAG BANK — COPY & MIX</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {["#RockForge","#MusicGame","#GuitarHero","#DrumMachine","#Piano","#Karaoke","#AIMusic","#IndieGame","#WebGame","#MusicStudio","#BrowserGame","#HumanLayerAI","#GameDev","#MusicProduction","#AILyrics","#BeatMaker","#SongWriter","#MusicCreator","#FreeGame","#fyp","#foryou","#gaming","#music","#viral","#BuildInPublic","#StartupLife","#IndieGameDev","#WebDev"].map((tag, i) => (
              <div key={i} onClick={() => { navigator.clipboard?.writeText(tag); }} style={{
                padding: "4px 10px", borderRadius: 20, background: "#07071a",
                border: "1px solid #1e1e3a", color: "#6366f1", fontSize: 10,
                cursor: "pointer", transition: "all 0.15s",
              }}
                onMouseEnter={e => { e.currentTarget.style.background = "#6366f122"; e.currentTarget.style.borderColor = "#6366f1"; }}
                onMouseLeave={e => { e.currentTarget.style.background = "#07071a"; e.currentTarget.style.borderColor = "#1e1e3a"; }}>
                {tag}
              </div>
            ))}
          </div>
          <div style={{ fontSize: 9, color: "#2d2d4a", marginTop: 10 }}>Click any hashtag to copy it individually</div>
        </div>

        {/* Posting schedule */}
        <div style={{ marginTop: 20, background: "#0f0f1f", border: "1px solid #1e1e3a", borderRadius: 16, padding: "20px" }}>
          <div style={{ fontSize: 9, color: "#3d3d6a", letterSpacing: 3, marginBottom: 14 }}>📅 RECOMMENDED POSTING SCHEDULE</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {[
              { day: "Day 1 — Launch Day", tasks: ["Twitter/X: Launch post", "LinkedIn: Professional launch announcement", "Reddit: r/indiegaming + r/WeAreTheMusicMakers", "Product Hunt: Submit listing"], color: "#f97316" },
              { day: "Day 2–3 — Feature Push", tasks: ["Instagram: Feature highlight (Guitar Hero mode)", "TikTok: Record yourself playing + voiceover", "Discord: Share in music/gaming servers", "Twitter: Drum machine feature post"], color: "#a855f7" },
              { day: "Day 4–7 — Community", tasks: ["Twitter: Leaderboard challenge post", "Instagram: Community shoutout", "Discord: Challenge + prize announcement", "Reddit: AMA or feedback thread"], color: "#06b6d4" },
              { day: "Week 2+ — Sustain", tasks: ["2–3 posts per week across platforms", "Respond to every comment within 24hrs", "Share user scores and highlights", "Post behind-the-scenes updates"], color: "#22c55e" },
            ].map((phase, i) => (
              <div key={i} style={{ padding: "12px 16px", borderRadius: 10, background: "#07071a", border: `1px solid ${phase.color}22` }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: phase.color, marginBottom: 8 }}>{phase.day}</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {phase.tasks.map((t, j) => (
                    <div key={j} style={{ padding: "3px 10px", borderRadius: 20, background: `${phase.color}11`, border: `1px solid ${phase.color}33`, color: "#8888aa", fontSize: 10 }}>✓ {t}</div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
