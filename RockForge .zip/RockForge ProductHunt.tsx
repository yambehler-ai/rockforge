import { useState, useEffect } from "react";

const UPVOTES_KEY = "rockforge_ph_upvotes";

const MAKERS = [
  { name: "HumanLayerAI LLC", role: "CEO & Founder", avatar: "🧠", bio: "Building intelligent, human-centered digital experiences. RockForge is our flagship music gaming platform." },
];

const FEATURES = [
  { icon: "🎸", title: "Guitar Hero Highway", desc: "5-lane scrolling note highway with combo multipliers and real-time scoring." },
  { icon: "🥁", title: "8-Pad Drum Machine", desc: "Live drum kit + step sequencer. Record and loop patterns at any BPM." },
  { icon: "🎹", title: "Full Piano Keyboard", desc: "Playable piano with black keys, chord library, and note history." },
  { icon: "🎤", title: "Karaoke + Mic Scoring", desc: "Real-time microphone analysis scores your singing performance." },
  { icon: "🎚️", title: "Music Creation Studio", desc: "Build chord progressions, set BPM, write lyrics, save your tracks." },
  { icon: "✨", title: "AI Lyric Generator", desc: "Claude AI writes original lyrics tuned to your genre, title, and chords." },
];

const COMMENTS = [
  { user: "ProductHunter42", avatar: "🦊", time: "just now", text: "This is insane — Guitar Hero in the browser with AI lyrics? Instant upvote. 🔥" },
  { user: "MusicMakerPro", avatar: "🎵", time: "2m ago", text: "The karaoke mic scoring is actually impressive. Built this in the browser? Wild." },
  { user: "IndieDevDaily", avatar: "💻", time: "5m ago", text: "Love seeing music + AI combined like this. The studio mode alone is worth it." },
  { user: "GamingWeekly", avatar: "🎮", time: "8m ago", text: "My kids are going to absolutely demolish this. Bookmarked for tonight." },
];

const GALLERY = [
  { label: "Guitar Hero Mode", emoji: "🎸", color: "#22c55e", desc: "5-lane note highway with color-coded frets" },
  { label: "Drum Sequencer", emoji: "🥁", color: "#ec4899", desc: "8-pad kit + 8-step pattern sequencer" },
  { label: "Piano Keyboard", emoji: "🎹", color: "#3b82f6", desc: "Full octave with black keys + chord library" },
  { label: "AI Studio", emoji: "✨", color: "#f97316", desc: "AI-powered lyric generator + track builder" },
];

export default function ProductHuntPage() {
  const [upvotes, setUpvotes] = useState(247);
  const [hasVoted, setHasVoted] = useState(false);
  const [activeGallery, setActiveGallery] = useState(0);
  const [comment, setComment] = useState("");
  const [comments, setComments] = useState(COMMENTS);
  const [showShare, setShowShare] = useState(false);
  const [copied, setCopied] = useState(false);
  const [animIn, setAnimIn] = useState(false);

  useEffect(() => {
    setTimeout(() => setAnimIn(true), 100);
    try {
      const v = localStorage.getItem(UPVOTES_KEY);
      if (v) { setUpvotes(parseInt(v)); setHasVoted(true); }
    } catch {}
  }, []);

  const handleUpvote = () => {
    if (hasVoted) return;
    const newCount = upvotes + 1;
    setUpvotes(newCount);
    setHasVoted(true);
    try { localStorage.setItem(UPVOTES_KEY, newCount); } catch {}
  };

  const handleComment = () => {
    if (!comment.trim()) return;
    setComments(prev => [{ user: "You", avatar: "⭐", time: "just now", text: comment }, ...prev]);
    setComment("");
  };

  const copyLink = () => {
    navigator.clipboard?.writeText("https://rockforge.io");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#fafafa", fontFamily: "'Trebuchet MS', sans-serif", color: "#111" }}>
      <style>{`
        @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        @keyframes upvotePop { 0%{transform:scale(1)} 40%{transform:scale(1.3)} 100%{transform:scale(1)} }
        @keyframes shimmer { 0%{background-position:200% center} 100%{background-position:-200% center} }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: #ddd; border-radius: 2px; }
      `}</style>

      {/* PH-style nav */}
      <nav style={{ background: "#fff", borderBottom: "1px solid #eee", padding: "12px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg, #f97316, #facc15)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🎸</div>
          <div>
            <div style={{ fontWeight: 900, fontSize: 15, color: "#111" }}>RockForge</div>
            <div style={{ fontSize: 10, color: "#888" }}>by HumanLayerAI LLC</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={() => setShowShare(true)} style={{ padding: "8px 16px", borderRadius: 8, border: "1px solid #eee", background: "#fff", color: "#555", fontSize: 12, cursor: "pointer", fontWeight: 600 }}>↗ Share</button>
          <a href="https://rockforge.io" target="_blank" rel="noreferrer" style={{ padding: "8px 16px", borderRadius: 8, border: "none", background: "linear-gradient(135deg, #f97316, #facc15)", color: "#000", fontSize: 12, cursor: "pointer", fontWeight: 800, textDecoration: "none" }}>Visit Site →</a>
        </div>
      </nav>

      <div style={{ maxWidth: 860, margin: "0 auto", padding: "32px 20px" }}>

        {/* Hero card */}
        <div style={{ background: "#fff", borderRadius: 20, border: "1px solid #eee", overflow: "hidden", marginBottom: 24, animation: animIn ? "fadeUp 0.5s ease" : "none", boxShadow: "0 4px 24px rgba(0,0,0,0.06)" }}>
          {/* Gradient banner */}
          <div style={{ height: 120, background: "linear-gradient(135deg, #030308 0%, #1a0d2e 50%, #030308 100%)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative", overflow: "hidden" }}>
            {["🎸","🥁","🎹","🎤","🎚️","✨"].map((e, i) => (
              <div key={i} style={{ position: "absolute", fontSize: 28, opacity: 0.15, left: `${8 + i * 16}%`, top: i % 2 === 0 ? "20%" : "50%" }}>{e}</div>
            ))}
            <div style={{ fontSize: 48, position: "relative", zIndex: 1 }}>🎸</div>
          </div>

          <div style={{ padding: "24px 28px" }}>
            <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
              <div style={{ flex: 1 }}>
                {/* Badge row */}
                <div style={{ display: "flex", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
                  {["🏆 #1 Product of the Day", "🎮 Gaming", "🎵 Music", "✨ AI"].map((b, i) => (
                    <span key={i} style={{ padding: "3px 10px", borderRadius: 20, background: i === 0 ? "#fff3cd" : "#f5f5f5", color: i === 0 ? "#b45309" : "#666", fontSize: 10, fontWeight: 600, border: i === 0 ? "1px solid #fbbf24" : "1px solid #eee" }}>{b}</span>
                  ))}
                </div>

                <h1 style={{ fontSize: 28, fontWeight: 900, color: "#111", marginBottom: 8, lineHeight: 1.1 }}>RockForge — Music Game Studio</h1>
                <p style={{ fontSize: 14, color: "#555", lineHeight: 1.7, maxWidth: 540 }}>
                  Guitar Hero + Rock Band + Karaoke + AI Music Creation — all in your browser. No download. No install. Just play, create, and perform.
                </p>

                <div style={{ display: "flex", gap: 8, marginTop: 16, flexWrap: "wrap" }}>
                  <a href="https://rockforge.io" style={{ padding: "10px 22px", borderRadius: 10, background: "linear-gradient(135deg, #f97316, #facc15)", color: "#000", fontWeight: 800, fontSize: 13, textDecoration: "none" }}>🎸 Play Free</a>
                  <a href="https://rockforge.io/pricing" style={{ padding: "10px 22px", borderRadius: 10, border: "1px solid #eee", background: "#fff", color: "#333", fontWeight: 700, fontSize: 13, textDecoration: "none" }}>💎 View Plans</a>
                </div>
              </div>

              {/* Upvote button */}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <button onClick={handleUpvote} style={{
                  width: 72, height: 72, borderRadius: 16,
                  border: hasVoted ? "2px solid #f97316" : "2px solid #eee",
                  background: hasVoted ? "linear-gradient(135deg, #fff3e0, #fff)" : "#fff",
                  cursor: hasVoted ? "default" : "pointer",
                  display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 2,
                  boxShadow: hasVoted ? "0 0 20px #f9731633" : "0 2px 8px rgba(0,0,0,0.06)",
                  animation: hasVoted ? "upvotePop 0.4s ease" : "none",
                  transition: "all 0.2s",
                }}>
                  <div style={{ fontSize: 22 }}>{hasVoted ? "🔶" : "▲"}</div>
                  <div style={{ fontSize: 16, fontWeight: 900, color: hasVoted ? "#f97316" : "#111" }}>{upvotes}</div>
                </button>
                <div style={{ fontSize: 9, color: "#aaa", textAlign: "center" }}>{hasVoted ? "Upvoted!" : "Upvote"}</div>
              </div>
            </div>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 20, alignItems: "start" }}>
          <div>
            {/* Gallery */}
            <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #eee", overflow: "hidden", marginBottom: 20, boxShadow: "0 2px 12px rgba(0,0,0,0.04)" }}>
              <div style={{ display: "flex", gap: 0, borderBottom: "1px solid #eee" }}>
                {GALLERY.map((g, i) => (
                  <div key={i} onClick={() => setActiveGallery(i)} style={{ flex: 1, padding: "10px 6px", textAlign: "center", cursor: "pointer", borderBottom: activeGallery === i ? `2px solid ${g.color}` : "2px solid transparent", background: activeGallery === i ? `${g.color}08` : "transparent", transition: "all 0.2s" }}>
                    <div style={{ fontSize: 18 }}>{g.emoji}</div>
                    <div style={{ fontSize: 9, color: activeGallery === i ? g.color : "#aaa", fontWeight: activeGallery === i ? 700 : 400, marginTop: 2 }}>{g.label}</div>
                  </div>
                ))}
              </div>
              <div style={{ height: 200, background: `linear-gradient(135deg, ${GALLERY[activeGallery].color}11, #fff)`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12, transition: "background 0.3s" }}>
                <div style={{ fontSize: 64 }}>{GALLERY[activeGallery].emoji}</div>
                <div style={{ fontWeight: 800, color: "#111", fontSize: 16 }}>{GALLERY[activeGallery].label}</div>
                <div style={{ fontSize: 12, color: "#888" }}>{GALLERY[activeGallery].desc}</div>
              </div>
            </div>

            {/* About */}
            <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #eee", padding: "24px", marginBottom: 20, boxShadow: "0 2px 12px rgba(0,0,0,0.04)" }}>
              <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 16, color: "#111" }}>About RockForge</h2>
              <p style={{ fontSize: 13, color: "#555", lineHeight: 1.8, marginBottom: 16 }}>
                <strong>RockForge</strong> is the browser-based music game studio that combines the best of Guitar Hero, Rock Band, karaoke, and AI music creation — all in one place. Built by <strong>HumanLayerAI LLC</strong>, it runs entirely in your browser with no download required.
              </p>
              <p style={{ fontSize: 13, color: "#555", lineHeight: 1.8, marginBottom: 16 }}>
                Whether you want to hit notes on a Guitar Hero highway, build drum patterns on an 8-pad sequencer, play a full piano keyboard, sing karaoke with real mic scoring, or create original songs with AI-generated lyrics — RockForge does it all.
              </p>
              <p style={{ fontSize: 13, color: "#555", lineHeight: 1.8 }}>
                Membership plans start at <strong>free</strong>, with Band Member ($4.99/mo) and Rockstar Pro ($9.99/mo) tiers for unlimited creation and AI features.
              </p>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 20 }}>
                {FEATURES.map((f, i) => (
                  <div key={i} style={{ padding: "12px", borderRadius: 10, background: "#fafafa", border: "1px solid #eee", display: "flex", gap: 10, alignItems: "flex-start" }}>
                    <span style={{ fontSize: 20 }}>{f.icon}</span>
                    <div>
                      <div style={{ fontSize: 12, fontWeight: 700, color: "#111", marginBottom: 2 }}>{f.title}</div>
                      <div style={{ fontSize: 10, color: "#888", lineHeight: 1.5 }}>{f.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Comments */}
            <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #eee", padding: "24px", boxShadow: "0 2px 12px rgba(0,0,0,0.04)" }}>
              <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 16, color: "#111" }}>Discussion ({comments.length})</h2>
              <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
                <input value={comment} onChange={e => setComment(e.target.value)} onKeyDown={e => e.key === "Enter" && handleComment()} placeholder="Leave a comment..." style={{ flex: 1, padding: "10px 14px", borderRadius: 10, border: "1px solid #eee", fontSize: 13, outline: "none", background: "#fafafa" }} />
                <button onClick={handleComment} style={{ padding: "10px 18px", borderRadius: 10, border: "none", background: "#f97316", color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: 13 }}>Post</button>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {comments.map((c, i) => (
                  <div key={i} style={{ display: "flex", gap: 10 }}>
                    <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#f5f5f5", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>{c.avatar}</div>
                    <div>
                      <div style={{ display: "flex", gap: 8, alignItems: "baseline", marginBottom: 4 }}>
                        <span style={{ fontSize: 13, fontWeight: 700, color: "#111" }}>{c.user}</span>
                        <span style={{ fontSize: 10, color: "#aaa" }}>{c.time}</span>
                      </div>
                      <div style={{ fontSize: 13, color: "#555", lineHeight: 1.6 }}>{c.text}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Maker */}
            <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #eee", padding: "20px", boxShadow: "0 2px 12px rgba(0,0,0,0.04)" }}>
              <h3 style={{ fontSize: 12, color: "#aaa", letterSpacing: 2, marginBottom: 14, fontWeight: 600 }}>MAKERS</h3>
              {MAKERS.map((m, i) => (
                <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                  <div style={{ width: 44, height: 44, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #06b6d4)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>{m.avatar}</div>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: "#111" }}>{m.name}</div>
                    <div style={{ fontSize: 10, color: "#f97316", marginBottom: 4 }}>{m.role}</div>
                    <div style={{ fontSize: 11, color: "#888", lineHeight: 1.6 }}>{m.bio}</div>
                    <a href="mailto:HumanLayerAI.ops@gmail.com" style={{ fontSize: 10, color: "#6366f1", textDecoration: "none", display: "block", marginTop: 6 }}>📧 Contact</a>
                  </div>
                </div>
              ))}
            </div>

            {/* Info */}
            <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #eee", padding: "20px", boxShadow: "0 2px 12px rgba(0,0,0,0.04)" }}>
              <h3 style={{ fontSize: 12, color: "#aaa", letterSpacing: 2, marginBottom: 14, fontWeight: 600 }}>DETAILS</h3>
              {[
                { label: "Website", value: "rockforge.io", link: true },
                { label: "Pricing", value: "Free + Paid plans" },
                { label: "Platform", value: "Web (any browser)" },
                { label: "Company", value: "HumanLayerAI LLC" },
                { label: "Contact", value: "HumanLayerAI.ops\n@gmail.com" },
                { label: "Launched", value: new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }) },
              ].map((d, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", paddingBottom: 10, marginBottom: 10, borderBottom: i < 5 ? "1px solid #f5f5f5" : "none" }}>
                  <span style={{ fontSize: 11, color: "#aaa" }}>{d.label}</span>
                  {d.link ? <a href="https://rockforge.io" style={{ fontSize: 11, color: "#6366f1", textDecoration: "none", fontWeight: 600 }}>{d.value} ↗</a> : <span style={{ fontSize: 11, color: "#111", fontWeight: 600, textAlign: "right", whiteSpace: "pre-line" }}>{d.value}</span>}
                </div>
              ))}
            </div>

            {/* Share */}
            <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #eee", padding: "20px", boxShadow: "0 2px 12px rgba(0,0,0,0.04)" }}>
              <h3 style={{ fontSize: 12, color: "#aaa", letterSpacing: 2, marginBottom: 14, fontWeight: 600 }}>SHARE</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {[
                  { label: "🐦 Twitter / X", color: "#1DA1F2", text: "Share on X" },
                  { label: "💼 LinkedIn", color: "#0A66C2", text: "Share on LinkedIn" },
                  { label: "📘 Facebook", color: "#1877F2", text: "Share on Facebook" },
                ].map((s, i) => (
                  <button key={i} style={{ padding: "9px 14px", borderRadius: 8, border: "1px solid #eee", background: "#fafafa", color: "#333", fontSize: 12, cursor: "pointer", fontWeight: 600, textAlign: "left", transition: "all 0.2s" }}
                    onMouseEnter={e => e.currentTarget.style.borderColor = s.color}
                    onMouseLeave={e => e.currentTarget.style.borderColor = "#eee"}>{s.label}</button>
                ))}
                <button onClick={copyLink} style={{ padding: "9px 14px", borderRadius: 8, border: "1px solid #eee", background: copied ? "#f0fdf4" : "#fafafa", color: copied ? "#16a34a" : "#333", fontSize: 12, cursor: "pointer", fontWeight: 600, transition: "all 0.2s" }}>
                  {copied ? "✓ Link Copied!" : "🔗 Copy Link"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Share modal */}
      {showShare && (
        <div style={{ position: "fixed", inset: 0, background: "#00000066", zIndex: 999, display: "flex", alignItems: "center", justifyContent: "center" }} onClick={() => setShowShare(false)}>
          <div style={{ background: "#fff", borderRadius: 20, padding: 28, maxWidth: 360, width: "90%", boxShadow: "0 20px 60px rgba(0,0,0,0.2)" }} onClick={e => e.stopPropagation()}>
            <div style={{ fontSize: 24, textAlign: "center", marginBottom: 12 }}>📣</div>
            <div style={{ fontSize: 18, fontWeight: 800, textAlign: "center", marginBottom: 4 }}>Share RockForge</div>
            <div style={{ fontSize: 12, color: "#888", textAlign: "center", marginBottom: 20 }}>Help us grow the community!</div>
            <div style={{ background: "#f5f5f5", borderRadius: 8, padding: "10px 14px", fontSize: 11, color: "#555", fontFamily: "monospace", marginBottom: 16, wordBreak: "break-all" }}>https://rockforge.io</div>
            <button onClick={copyLink} style={{ width: "100%", padding: "12px 0", borderRadius: 10, border: "none", background: "linear-gradient(135deg, #f97316, #facc15)", color: "#000", fontWeight: 800, cursor: "pointer", fontSize: 13 }}>
              {copied ? "✓ Copied!" : "Copy Link"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
